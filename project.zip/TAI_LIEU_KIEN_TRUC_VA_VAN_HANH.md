# TÀI LIỆU TOÀN DIỆN: CẤU TRÚC, LƯU TRỮ, SƠ ĐỒ VẬN HÀNH VÀ HƯỚNG DẪN TỐI ƯU HỆ THỐNG
## ỨNG DỤNG QUẢN LÝ VẬN HÀNH LƯỚI ĐIỆN PHÂN PHỐI EVN (ANDROID - JETPACK COMPOSE)

---

## MỤC LỤC
1. [TỔNG QUAN KIẾN TRÚC HỆ THỐNG](#1-tổng-quan-kiến-trúc-hệ-thống)
2. [CẤU TRÚC THƯ MỤC VÀ MÃ NGUỒN](#2-cấu-trúc-thư-mục-và-mã-nguồn)
3. [CƠ CHẾ LƯU TRỮ DỮ LIỆU (DATABASE & STORAGE)](#3-cơ-chế-lưu-trữ-dữ-liệu-database--storage)
4. [SƠ ĐỒ VẬN HÀNH & LUỒNG DỮ LIỆU (DATA FLOW)](#4-sơ-đồ-vận-hành--luồng-dữ-liệu-data-flow)
5. [HƯỚNG DẪN CHỈNH SỬA & BỔ SUNG TÍNH NĂNG](#5-hướng-dẫn-chỉnh-sửa--bổ-sung-tính-năng)
6. [CHIẾN LƯỢC ĐIỀU CHỈNH TỐI ƯU HÓA (PERFORMANCE OPTIMIZATION)](#6-chiến-lược-điều-chỉnh-tối-ưu-hóa-performance-optimization)

---

## 1. TỔNG QUAN KIẾN TRÚC HỆ THỐNG

Hệ thống được phát triển theo mô hình chuẩn **MVVM (Model - View - ViewModel)** kết hợp **Clean Architecture** và bộ công cụ hiện đại nhất của Android:
- **UI Framework**: Jetpack Compose kết hợp Material Design 3 (M3). Toàn bộ giao diện là khai báo (Declarative UI), không dùng XML layout truyền thống.
- **State Management**: Sử dụng `StateFlow` và `asStateFlow()` của Kotlin Coroutines để truyền tải trạng thái bất biến (Immutable State) từ ViewModel tới UI.
- **Local Persistence**: Thư viện SQLite ORM **Room Database** phiên bản 2, hỗ trợ luồng dữ liệu phản ứng thời gian thực thông qua `Flow<List<T>>`.
- **Bản đồ GIS**: Tự xây dựng trên Canvas Compose tùy biến 2D phẳng (Vector GIS Renderer), hỗ trợ phóng to/thu nhỏ (Zoom & Pan đa điểm cử chỉ), tính khoảng cách địa lý theo thuật toán Haversine và phép chiếu tọa độ tự động.
- **Engine Xuất Báo Cáo**: Android Native Graphics (`android.graphics.pdf.PdfDocument`), kết xuất bảng biểu, vector màu, phân trang A4 đạt chuẩn hồ sơ quản lý vận hành EVN.

```
┌─────────────────────────────────────────────────────────────┐
│                    TẦNG GIAO DIỆN (UI LAYER)                 │
│  - DashboardScreen       - GridMapScreen (GIS)              │
│  - HomeScreen (Dsách)    - EquipmentDetailScreen            │
│  - DefectsScreen         - SafetyCorridorScreen             │
│  - ReportsScreen (PDF)   - Dialogs (Thêm/Sửa/Lọc)           │
└──────────────────────────────▲──────────────────────────────┘
                               │ StateFlow (UI State) / User Events
┌──────────────────────────────▼──────────────────────────────┐
│                  TẦNG ĐIỀU PHỐI (VIEWMODEL)                 │
│                       GridViewModel                         │
│  - Quản lý trạng thái màn hình, bộ lọc, tìm kiếm            │
│  - Xử lý nghiệp vụ: tính toán hạn bảo dưỡng, cảnh báo GIS   │
└──────────────────────────────▲──────────────────────────────┘
                               │ Kotlin Flow / Suspend Functions
┌──────────────────────────────▼──────────────────────────────┐
│                 TẦNG TRUY XUẤT DỮ LIỆU (REPOSITORY)          │
│                       GridRepository                        │
│  - Trừu tượng hóa truy vấn, làm trung gian giữa Room & VM   │
└──────────────────────────────▲──────────────────────────────┘
                               │ DAO Queries
┌──────────────────────────────▼──────────────────────────────┐
│                    TẦNG LƯU TRỮ CƠ SỞ DỮ LIỆU                │
│                 Room Database (SQLite)                      │
│  - GridEquipment         - PeriodicInspection               │
│  - MaintenanceRecord     - DefectRecord                     │
│  - SafetyCorridorRecord                                     │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. CẤU TRÚC THƯ MỤC VÀ MÃ NGUỒN

Toàn bộ mã nguồn được phân chia theo module chức năng rõ ràng:

```
app/src/main/java/com/example/
│
├── MainActivity.kt                  # Điểm khởi động ứng dụng, thanh điều hướng Scaffold BottomBar
│
├── data/                            # TẦNG DỮ LIỆU (DATA LAYER)
│   ├── db/                          # Cơ sở dữ liệu Room SQLite
│   │   ├── AppDatabase.kt           # Khởi tạo DB, DatabaseCallback, nạp dữ liệu mẫu ban đầu
│   │   ├── Converters.kt            # TypeConverter chuyển đổi Enums và List<String> sang DB
│   │   └── GridDao.kt               # Các hàm truy vấn SQL (CRUD, Flow, Lọc theo loại, trạm)
│   │
│   ├── model/                       # CÁC THỰC THỂ DỮ LIỆU (ENTITIES & ENUMS)
│   │   ├── Enums.kt                 # Thiết bị: Recloser, LBS, DS, LA, FCO, LBFCO; Cấp điện áp; Mức độ khiếm khuyết
│   │   ├── GridEquipment.kt         # Bảng thiết bị chính: mã, tên, vị trí, tọa độ GPS, thông số kỹ thuật
│   │   ├── PeriodicInspection.kt    # Bảng kết quả kiểm tra định kỳ, nhiệt độ hồng ngoại các pha
│   │   ├── MaintenanceRecord.kt     # Bảng lịch sử bảo dưỡng, sửa chữa, phụ tùng thay thế
│   │   ├── DefectRecord.kt          # Bảng theo dõi khiếm khuyết, mức độ nguy hiểm, phương án xử lý
│   │   └── SafetyCorridorRecord.kt  # Bảng vi phạm hành lang tuyến (cây cối, công trình, khoảng cách an toàn)
│   │
│   └── repository/
│       └── GridRepository.kt        # Repository cung cấp dữ liệu qua Kotlin Flow
│
├── ui/                              # TẦNG GIAO DIỆN (PRESENTATION LAYER)
│   ├── theme/                       # Hệ thống màu sắc nhận diện EVN (Theme.kt, Color.kt, Type.kt)
│   ├── viewmodel/
│   │   └── GridViewModel.kt         # Quản lý State toàn cục cho ứng dụng
│   ├── screens/                     # Các màn hình chính
│   │   ├── DashboardScreen.kt       # Dashboard tổng quan, KPI, tỷ lệ an toàn, biểu đồ vòng, cảnh báo gấp
│   │   ├── HomeScreen.kt            # Danh sách thiết bị, tìm kiếm nhanh, lọc theo lộ đường dây, trạng thái
│   │   ├── GridMapScreen.kt         # Bản đồ GIS lưới điện 2D trực quan, đường dây, vùng đệm hành lang
│   │   ├── EquipmentDetailScreen.kt # Chi tiết hồ sơ kỹ thuật, lịch sử bảo dưỡng, nhật ký nhiệt độ của thiết bị
│   │   ├── DefectsScreen.kt         # Danh sách khiếm khuyết, lọc theo cấp độ (Khẩn cấp/Nghiêm trọng/Nhẹ)
│   │   ├── SafetyCorridorScreen.kt  # Giám sát hành lang an toàn lưới điện cao áp/trung áp
│   │   └── ReportsScreen.kt         # Trình tạo, xem trước trang và xuất file PDF
│   └── dialogs/                     # Hộp thoại Thêm/Sửa thiết bị, Thêm phiếu kiểm tra, Thêm khiếm khuyết
│
└── util/                            # TIỆN ÍCH HỆ THỐNG
    ├── GeoCoordinates.kt            # Tính toán khoảng cách địa lý, tọa độ bản đồ GIS
    └── PdfReportGenerator.kt        # Engine xuất file PDF khổ A4 với định dạng chuẩn EVN
```

---

## 3. CƠ CHẾ LƯU TRỮ DỮ LIỆU (DATABASE & STORAGE)

### 3.1. Cơ sở dữ liệu nội bộ (Room SQLite Database)
Tên tệp cơ sở dữ liệu trên thiết bị: `power_grid_management.db`.
Ứng dụng hoạt động **hoàn toàn Offline-First**, không phụ thuộc mạng internet, đảm bảo cán bộ đi rừng núi, trạm biến áp vùng sâu vẫn cập nhật kiểm tra bình thường.

#### 5 Thực thể (Entities) cốt lõi:
1. **`grid_equipments`**:
   - Khóa chính: `id: Long` (Auto-generate)
   - Nhận diện: `code` (Ví dụ: `REC-471-01`), `name`, `type` (`EquipmentType`: RECLOSER, LBS, DS, LA, FCO, LBFCO).
   - Tọa độ địa lý: `latitude`, `longitude` (WGS84).
   - Tuyến & Vị trí: `lineName` (Đường dây 471, 473,...), `substationName`, `poleNumber` (Số cột).
   - Thông số kỹ thuật chuyên ngành: `ratedVoltage` (22kV, 35kV), `ratedCurrent` (630A, 800A), `breakingCurrent` (12.5kA, 16kA), `sf6Pressure` (Áp lực khí SF6 bar), `fuseRating` (Dòng chì FCO Ampe), `transformerCapacity` (kVA), `groundResistance` (Điện trở tiếp địa $\Omega$).
   - Thời gian bảo dưỡng: `installationDate`, `lastMaintenanceDate`, `nextMaintenanceDate`, `nextInspectionDate`, `maintenanceIntervalDays`.

2. **`periodic_inspections`**:
   - `equipmentId`: Khóa ngoại tham chiếu thiết bị.
   - Đo nhiệt hồng ngoại: `phaseATemp`, `phaseBTemp`, `phaseCTemp`, `ambientTemp`, `temperatureDelta` ($\Delta T$ cảnh báo phát nhiệt tiếp xúc).
   - Cách điện: `insulationCondition` (Bình thường / Nứt rạn / Phóng điện bề mặt).
   - Tủ điều khiển RTU: `batteryVoltage` (Ắc quy 24V), `scadaCommunicationOk`.

3. **`maintenance_records`**:
   - Ghi lại các đợt đại tu, tiểu tu, thay dầu/khí SF6, thay sứ cách điện, nạp ga, vệ sinh hotline.
   - Chi tiết: `maintenanceType`, `performer`, `partsReplaced`, `outcome` (Đạt/Không đạt nghiệm thu).

4. **`defect_records`**:
   - Khiếm khuyết: `severity` (CRITICAL - Khẩn cấp, MAJOR - Nghiêm trọng, MINOR - Nhỏ).
   - Phương án: `actionPlan` (Xử lý ngay, cắt điện xử lý, theo dõi).
   - Tiến độ: `status` (PENDING, IN_PROGRESS, RESOLVED).

5. **`safety_corridor_records`**:
   - Quản lý nguy cơ hành lang: `hazardType` (CÂY XANH TRONG HÀNH LANG, CÔNG TRÌNH XÂY DỰNG, MÁI TÔN/BIỂN BÁNG).
   - `measuredDistance`: Khoảng cách thực đo tới dây dẫn (m).
   - `safeDistanceRequired`: Khoảng cách tối thiểu theo Nghị định 14/2014/NĐ-CP (ví dụ: 2m cho 22kV bọc, 3m cho 22kV trần).

---

## 4. SƠ ĐỒ VẬN HÀNH & LUỒNG DỮ LIỆU (DATA FLOW)

### 4.1. Khởi tạo và Tự động nạp dữ liệu mẫu (Seeding)
Khi ứng dụng được cài đặt lần đầu tiên:
1. `AppDatabase.getDatabase()` được gọi trong `MainActivity`.
2. `DatabaseCallback.onCreate()` kích hoạt luồng phụ (`Dispatchers.IO`).
3. Hệ thống nạp sẵn danh mục thiết bị lưới điện phân phối thực tế (Recloser Entec/Nulec, LBS Jin-Kwang, DS 3 pha ngoài trời, Chống sét van LA Cooper, FCO Tuấn Ân bảo vệ TBA 250kVA, 400kVA, vi phạm cây cao,...) để cán bộ có thể kiểm thử ngay.

### 4.2. Luồng phản ứng thời gian thực (Reactive Data Flow)
```
[Thao tác người dùng] (VD: Cán bộ cập nhật kết quả đo nhiệt 85°C pha A)
        │
        ▼
[Dialog / UI Event] -> gọi viewModel.insertInspection(inspection)
        │
        ▼
[Room Database] -> Ghi dữ liệu vào bảng SQLite
        │
        ▼
[Room Invalidation Tracker] -> Tự động kích hoạt Flow<List<GridEquipment>>
        │
        ▼
[GridViewModel] -> StateFlow phát ra danh sách mới
        │
        ▼
[DashboardScreen / GridMapScreen / HomeScreen] -> Tự động Recompose cập nhật UI:
  - Thiết bị tự động chuyển trạng thái màu Đỏ (Cảnh báo nguy hiểm)
  - Biểu đồ Dashboard tự động tăng số lượng khiếm khuyết
  - GIS Map hiển thị chấm đỏ nhấp nháy tại vị trí cột đó
```

---

## 5. HƯỚNG DẪN CHỈNH SỬA & BỔ SUNG TÍNH NĂNG

### 5.1. Thêm một Chủng loại thiết bị mới
- **Bước 1**: Mở `data/model/Enums.kt`. Thêm vào enum `EquipmentType`:
  ```kotlin
  enum class EquipmentType(val code: String, val displayName: String) {
      REC("REC", "Recloser - Máy cắt tự đóng lại"),
      LBS("LBS", "Cầu dao phụ tải"),
      DS("DS", "Cầu dao cách ly"),
      LA("LA", "Chống sét van"),
      FCO("FCO", "Cầu chì tự rơi"),
      LBFCO("LBFCO", "Cầu chì tự rơi có tải"),
      RMU("RMU", "Tủ máy cắt trung thế đóng vỏ kim loại") // THÊM MỚI TẠI ĐÂY
  }
  ```
- **Bước 2**: Trong `GridMapScreen.kt` hoặc `DashboardScreen.kt`, bổ sung màu sắc đại diện cho loại thiết bị mới trong câu lệnh `when (equipment.type)`.

### 5.2. Thêm một thuộc tính kỹ thuật mới vào thiết bị
- **Bước 1**: Mở `data/model/GridEquipment.kt`, thêm trường:
  ```kotlin
  val manufacturer: String = "EVN Standard", // Hãng sản xuất
  ```
- **Bước 2**: Tăng phiên bản cơ sở dữ liệu trong `AppDatabase.kt`:
  ```kotlin
  @Database(..., version = 3, exportSchema = false) // Tăng từ 2 lên 3
  ```
  *(Do có `.fallbackToDestructiveMigration()`, Room sẽ tự động tái cấu trúc bảng an toàn).*

### 5.3. Chỉnh sửa mẫu Báo cáo PDF theo biểu mẫu riêng của Công ty Điện Lực
- Mở file `util/PdfReportGenerator.kt`:
  - Thay đổi tiêu đề Công ty Điện lực tại hàm `drawText("TỔNG CÔNG TY ĐIỆN LỰC...", x, y, paint)`.
  - Thay đổi màu viền, thêm các trường kiểm tra nghiệm thu hoặc logo tại phần Header.

---

## 6. CHIẾN LƯỢC ĐIỀU CHỈNH TỐI ƯU HÓA (PERFORMANCE OPTIMIZATION)

Để ứng dụng vận hành mượt mà khi dữ liệu lên tới hàng chục nghìn cột điện và thiết bị:

1. **Tối ưu Bản đồ GIS Canvas (`GridMapScreen.kt`)**:
   - Sử dụng cơ chế **Spatial Viewport Culling**: Chỉ vẽ các điểm thiết bị nằm trong khung nhìn hiển thị hiện tại (`canvasBounds.contains(point)`), loại bỏ các điểm ngoài màn hình để giữ tốc độ khung hình ổn định 60-120 FPS.
   - Nhóm các trạm lân cận thành cụm (Clustering) khi thu nhỏ bản đồ ở mức zoom xa.

2. **Tối ưu Cơ sở dữ liệu Room**:
   - Đã đánh chỉ mục (Index) trên các cột thường xuyên lọc:
     ```kotlin
     @Entity(
         tableName = "grid_equipments",
         indices = [Index("code"), Index("type"), Index("status"), Index("lineName")]
     )
     ```
   - Sử dụng truy vấn phân trang qua `Paging 3` nếu số lượng bản ghi kiểm tra lịch sử vượt quá 5.000 dòng.

3. **Tối ưu Tiết kiệm Pin & Bộ nhớ ngoài hiện trường**:
   - Tắt tính năng tự động tìm nạp GPS liên tục khi cán bộ không mở tab Bản đồ GIS.
   - Tất cả màu sắc tuân thủ Material 3 Dark/Light tương thích tốt với màn hình OLED giúp kéo dài thời lượng pin khi thao tác ngoài trời nắng.
