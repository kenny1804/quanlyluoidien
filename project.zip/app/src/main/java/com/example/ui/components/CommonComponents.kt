package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CorridorStatus
import com.example.data.model.DefectSeverity
import com.example.data.model.DefectStatus
import com.example.data.model.EquipmentStatus
import com.example.data.model.EquipmentType
import com.example.data.model.HazardRiskLevel
import com.example.data.model.HazardType
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GridAmber
import com.example.ui.theme.SpcNavy
import com.example.ui.theme.StatusDangerRed
import com.example.ui.theme.StatusInfoBlue
import com.example.ui.theme.StatusNormalGreen
import com.example.ui.theme.StatusWarningAmber
import com.example.ui.theme.SubstationCyan
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatTimestamp(timestamp: Long): String {
    if (timestamp <= 0L) return "Chưa có"
    val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    return sdf.format(Date(timestamp))
}

fun formatDateTime(timestamp: Long): String {
    if (timestamp <= 0L) return "Chưa có"
    val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    return sdf.format(Date(timestamp))
}

@Composable
fun EquipmentTypeBadge(type: EquipmentType, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (type) {
        EquipmentType.RECLOSER -> Triple(ElectricBlue, Color.White, SpcNavy)
        EquipmentType.LBS -> Triple(SubstationCyan, Color.White, Color(0xFF004D40))
        EquipmentType.DS -> Triple(Color(0xFF37474F), Color.White, Color(0xFF212121))
        EquipmentType.LA -> Triple(Color(0xFFD97706), Color.White, Color(0xFF92400E))
        EquipmentType.FCO -> Triple(Color(0xFF6A1B9A), Color.White, Color(0xFF4A148C))
        EquipmentType.LBFCO -> Triple(Color(0xFF00695C), Color.White, Color(0xFF004D40))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = type.shortName,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold
        )
    }
}

@Composable
fun EquipmentStatusBadge(status: EquipmentStatus, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (status) {
        EquipmentStatus.OPERATIONAL -> Triple(Color(0xFFDCFCE7), Color(0xFF052E16), Color(0xFF16A34A))
        EquipmentStatus.WARNING -> Triple(Color(0xFFFEF3C7), Color(0xFF451A03), Color(0xFFD97706))
        EquipmentStatus.DEFECT -> Triple(Color(0xFFFEE2E2), Color(0xFF450A0A), Color(0xFFDC2626))
        EquipmentStatus.MAINTENANCE -> Triple(Color(0xFFE0F2FE), Color(0xFF082F49), Color(0xFF0284C7))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = status.label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DefectSeverityBadge(severity: DefectSeverity, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (severity) {
        DefectSeverity.CRITICAL -> Triple(Color(0xFFFEE2E2), Color(0xFF450A0A), Color(0xFFDC2626))
        DefectSeverity.MAJOR -> Triple(Color(0xFFFFEDD5), Color(0xFF7C2D12), Color(0xFFEA580C))
        DefectSeverity.MINOR -> Triple(Color(0xFFE0F2FE), Color(0xFF082F49), Color(0xFF0284C7))
        DefectSeverity.MONITOR -> Triple(Color(0xFFF1F5F9), Color(0xFF0F172A), Color(0xFF64748B))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = severity.label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DefectStatusBadge(status: DefectStatus, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (status) {
        DefectStatus.PENDING -> Triple(Color(0xFFFEE2E2), Color(0xFF450A0A), Color(0xFFDC2626))
        DefectStatus.IN_PROGRESS -> Triple(Color(0xFFFEF3C7), Color(0xFF451A03), Color(0xFFD97706))
        DefectStatus.RESOLVED -> Triple(Color(0xFFDCFCE7), Color(0xFF052E16), Color(0xFF16A34A))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = status.label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun HazardTypeBadge(type: HazardType, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (type) {
        HazardType.TREE -> Triple(Color(0xFFDCFCE7), Color(0xFF052E16), Color(0xFF16A34A))
        HazardType.HOUSE_BUILDING -> Triple(Color(0xFFEDE7F6), Color(0xFF3B0764), Color(0xFF7C3AED))
        HazardType.EQUIPMENT_OTHER -> Triple(Color(0xFFFEF3C7), Color(0xFF451A03), Color(0xFFD97706))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = type.label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun CorridorStatusBadge(status: CorridorStatus, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (status) {
        CorridorStatus.VIOLATION_EXISTING -> Triple(Color(0xFFFEE2E2), Color(0xFF450A0A), Color(0xFFDC2626))
        CorridorStatus.PROCESSING -> Triple(Color(0xFFFEF3C7), Color(0xFF451A03), Color(0xFFD97706))
        CorridorStatus.RESOLVED -> Triple(Color(0xFFDCFCE7), Color(0xFF052E16), Color(0xFF16A34A))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = status.label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun HazardStatusBadge(status: CorridorStatus, modifier: Modifier = Modifier) {
    CorridorStatusBadge(status = status, modifier = modifier)
}

@Composable
fun HazardRiskBadge(risk: HazardRiskLevel, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (risk) {
        HazardRiskLevel.HIGH -> Triple(Color(0xFFFEE2E2), Color(0xFF450A0A), Color(0xFFDC2626))
        HazardRiskLevel.MEDIUM -> Triple(Color(0xFFFEF3C7), Color(0xFF451A03), Color(0xFFD97706))
        HazardRiskLevel.LOW -> Triple(Color(0xFFDCFCE7), Color(0xFF052E16), Color(0xFF16A34A))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = risk.label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
