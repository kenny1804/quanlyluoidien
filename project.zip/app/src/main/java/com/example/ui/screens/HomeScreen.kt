package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.FlashOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.EquipmentStatus
import com.example.data.model.EquipmentType
import com.example.data.model.GridEquipment
import com.example.ui.components.EquipmentStatusBadge
import com.example.ui.components.EquipmentTypeBadge
import com.example.ui.components.formatTimestamp
import com.example.ui.dialogs.AddEquipmentDialog
import com.example.ui.dialogs.AddInspectionDialog
import com.example.ui.dialogs.InspectorSettingsDialog
import com.example.ui.dialogs.PdfReportDialog
import com.example.ui.dialogs.ReplaceFuseDialog
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GridAmber
import com.example.ui.theme.SpcBackgroundLight
import com.example.ui.theme.SpcNavy
import com.example.ui.theme.SpcYellow
import com.example.ui.theme.StatusDangerRed
import com.example.ui.theme.StatusNormalGreen
import com.example.ui.theme.StatusWarningAmber
import com.example.ui.theme.SubstationCyan
import com.example.ui.viewmodel.GridViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: GridViewModel,
    onNavigateToDetail: (Long) -> Unit,
    onNavigateToQrScanner: () -> Unit = {},
    onNavigateToTasks: () -> Unit = {},
    onNavigateToCorridor: () -> Unit = {},
    onNavigateToDefects: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val equipments by viewModel.filteredEquipments.collectAsStateWithLifecycle()
    val stats by viewModel.gridStats.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedType by viewModel.selectedType.collectAsStateWithLifecycle()
    val alertFilter by viewModel.alertFilter.collectAsStateWithLifecycle()
    val selectedArea by viewModel.selectedArea.collectAsStateWithLifecycle()
    val maintenanceRecords by viewModel.maintenanceRecords.collectAsStateWithLifecycle()
    val inspections by viewModel.inspections.collectAsStateWithLifecycle()
    val defects by viewModel.defects.collectAsStateWithLifecycle()
    val corridors by viewModel.corridorRecords.collectAsStateWithLifecycle()

    var showAddEquipmentDialog by remember { mutableStateOf(false) }
    var showInspectorSettingsDialog by remember { mutableStateOf(false) }
    var showPdfReportDialog by remember { mutableStateOf(false) }
    var inspectionEquipment by remember { mutableStateOf<GridEquipment?>(null) }
    var replaceFuseEquipment by remember { mutableStateOf<GridEquipment?>(null) }

    // Bulk Update State
    var isBulkMode by remember { mutableStateOf(false) }
    var selectedEquipmentIds by remember { mutableStateOf(setOf<Long>()) }
    var showBulkStatusDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    if (isBulkMode) {
                        Column {
                            Text(
                                "Đã chọn ${selectedEquipmentIds.size} thiết bị",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                "Chế độ Cập nhật Hàng loạt",
                                style = MaterialTheme.typography.labelSmall,
                                color = SpcYellow,
                                letterSpacing = 0.5.sp
                            )
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(SpcYellow),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.ElectricBolt,
                                    contentDescription = "EVN Logo",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    "Quản Lý Thiết Bị Lưới Điện",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    if (selectedArea != null) "Khu vực: Tuyến $selectedArea • PCAG" else "EVNSPC • CÔNG TY ĐIỆN LỰC AN GIANG",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.85f),
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    }
                },
                actions = {
                    if (isBulkMode) {
                        IconButton(
                            onClick = {
                                val allIds = equipments.map { it.id }.toSet()
                                selectedEquipmentIds = if (selectedEquipmentIds.size == allIds.size) emptySet() else allIds
                            },
                            modifier = Modifier.testTag("home_select_all_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.SelectAll,
                                contentDescription = "Chọn tất cả",
                                tint = SpcYellow
                            )
                        }
                        IconButton(
                            onClick = {
                                isBulkMode = false
                                selectedEquipmentIds = emptySet()
                            },
                            modifier = Modifier.testTag("home_cancel_bulk_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Hủy chọn",
                                tint = Color.White
                            )
                        }
                    } else {
                        IconButton(
                            onClick = {
                                isBulkMode = true
                                selectedEquipmentIds = emptySet()
                            },
                            modifier = Modifier.testTag("home_bulk_mode_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Checklist,
                                contentDescription = "Cập nhật hàng loạt",
                                tint = SpcYellow
                            )
                        }
                        IconButton(
                            onClick = onNavigateToQrScanner,
                            modifier = Modifier.testTag("home_qr_scanner_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = "Quét mã QR thiết bị",
                                tint = SpcYellow
                            )
                        }
                        IconButton(
                            onClick = { showPdfReportDialog = true },
                            modifier = Modifier.testTag("home_pdf_report_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = "Xuất báo cáo PDF",
                                tint = Color.White
                            )
                        }
                        IconButton(
                            onClick = { showInspectorSettingsDialog = true },
                            modifier = Modifier.testTag("home_inspector_settings_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ManageAccounts,
                                contentDescription = "Cán bộ & Dữ liệu",
                                tint = Color.White
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SpcNavy,
                    titleContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            if (isBulkMode) {
                if (selectedEquipmentIds.isNotEmpty()) {
                    FloatingActionButton(
                        onClick = { showBulkStatusDialog = true },
                        containerColor = SpcYellow,
                        contentColor = SpcNavy,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("bulk_update_status_fab")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Build, contentDescription = null, tint = SpcNavy)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Đổi Trạng Thái (${selectedEquipmentIds.size})",
                                fontWeight = FontWeight.Bold,
                                color = SpcNavy
                            )
                        }
                    }
                }
            } else {
                FloatingActionButton(
                    onClick = { showAddEquipmentDialog = true },
                    containerColor = SpcYellow,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("add_equipment_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Thêm thiết bị mới")
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. Metric Stat Dashboard Banner
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatCard(
                            title = "Tổng T/bị",
                            value = "${stats.totalEquipments}",
                            accentColor = SpcNavy,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "Quá hạn K/tra",
                            value = "${stats.overdueInspections}",
                            accentColor = if (stats.overdueInspections > 0) StatusDangerRed else StatusNormalGreen,
                            isAlert = stats.overdueInspections > 0,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                viewModel.alertFilter.value = if (alertFilter == "OVERDUE") "ALL" else "OVERDUE"
                            }
                        )
                        StatCard(
                            title = "Khiếm khuyết",
                            value = "${stats.activeDefects}",
                            accentColor = if (stats.activeDefects > 0) StatusWarningAmber else StatusNormalGreen,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                viewModel.alertFilter.value = if (alertFilter == "DEFECTS") "ALL" else "DEFECTS"
                            }
                        )
                        StatCard(
                            title = "V/phạm H/lang",
                            value = "${stats.activeCorridorHazards}",
                            accentColor = SubstationCyan,
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToCorridor
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Quick navigation shortcuts for Tasks & Field Reporting
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateToTasks() }
                                .testTag("home_quick_tasks_btn"),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFCC80))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .background(Color(0xFFEF6C00), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Outlined.Assignment, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text("Việc giao (${stats.activeAssignedTasks})", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                                    Text("Ký & Gửi QLVH", fontSize = 9.5.sp, color = Color(0xFF8D6E63))
                                }
                            }
                        }

                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onNavigateToDefects() }
                                .testTag("home_quick_defects_btn"),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFCDD2))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .background(Color(0xFFC62828), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text("Sổ Khiếm khuyết", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                                    Text("Ký & Xuất PDF", fontSize = 9.5.sp, color = Color(0xFF8D6E63))
                                }
                            }
                        }
                    }
                }
            }

            // 1.5 Area filter indicator if active
            if (selectedArea != null) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .background(ElectricBlue.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.FilterList, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Đang xem khu vực: Tuyến $selectedArea", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ElectricBlue)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { viewModel.setAreaFilter(null) }
                                .padding(4.dp)
                        ) {
                            Text("Xem tất cả tuyến ✕", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            }

            // 2. Search Input
            item {
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.searchQuery.value = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_equipment_input"),
                        placeholder = { Text("Tìm mã (REC-471), cột, tuyến, chì (15K)...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Xóa tìm kiếm")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surface,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                }
            }

            // 3. Equipment Type Quick Filter Chips (Recloser, LBS, DS, LA, FCO, LBFCO)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedType == null,
                        onClick = { viewModel.selectedType.value = null },
                        label = { Text("Tất cả (${stats.totalEquipments})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SpcNavy,
                            selectedLabelColor = Color.White
                        )
                    )
                    EquipmentType.entries.forEach { type ->
                        val count = when (type) {
                            EquipmentType.RECLOSER -> stats.recloserCount
                            EquipmentType.LBS -> stats.lbsCount
                            EquipmentType.DS -> stats.dsCount
                            EquipmentType.LA -> stats.laCount
                            EquipmentType.FCO -> stats.fcoCount
                            EquipmentType.LBFCO -> stats.lbfcoCount
                        }
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { viewModel.selectedType.value = type },
                            label = { Text("${type.displayName} ($count)") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SpcNavy,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            // 4. Alert Filter Pills (Overdue warning bar)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (stats.overdueInspections > 0) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (alertFilter == "OVERDUE") StatusDangerRed else Color(0xFFFFEBEE))
                                .clickable {
                                    viewModel.alertFilter.value = if (alertFilter == "OVERDUE") "ALL" else "OVERDUE"
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = if (alertFilter == "OVERDUE") Color.White else StatusDangerRed,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Quá hạn (${stats.overdueInspections})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (alertFilter == "OVERDUE") Color.White else StatusDangerRed
                                )
                            }
                        }
                    }

                    if (stats.dueSoonInspections > 0) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (alertFilter == "DUE_SOON") StatusWarningAmber else Color(0xFFFFF3E0))
                                .clickable {
                                    viewModel.alertFilter.value = if (alertFilter == "DUE_SOON") "ALL" else "DUE_SOON"
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Sắp đến hạn (${stats.dueSoonInspections})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (alertFilter == "DUE_SOON") Color.White else StatusWarningAmber
                                )
                            }
                        }
                    }

                    if (alertFilter != "ALL") {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { viewModel.alertFilter.value = "ALL" }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("Bỏ lọc cảnh báo ✕", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            // 5. Equipment List
            if (equipments.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.FilterList,
                                contentDescription = null,
                                modifier = Modifier.size(44.dp),
                                tint = MaterialTheme.colorScheme.outline
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                if (stats.totalEquipments == 0) "Dữ liệu lưới điện đang trống (Đã làm trắng)" else "Không tìm thấy thiết bị phù hợp",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                if (stats.totalEquipments == 0)
                                    "Bạn có thể bắt đầu tạo thiết bị mới theo khu vực quản lý của mình hoặc nạp lại dữ liệu mẫu SPC."
                                else
                                    "Thử xóa tìm kiếm hoặc chuyển sang khu vực quản lý khác.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { showAddEquipmentDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = GridAmber)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Thêm Thiết Bị", fontSize = 12.sp)
                                }
                                if (stats.totalEquipments == 0) {
                                    Button(
                                        onClick = { viewModel.restoreSampleData() },
                                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                                    ) {
                                        Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Nạp Mẫu SPC", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                items(equipments, key = { it.id }) { equipment ->
                    val isSelected = selectedEquipmentIds.contains(equipment.id)
                    EquipmentItemCard(
                        equipment = equipment,
                        isBulkMode = isBulkMode,
                        isSelected = isSelected,
                        onToggleSelect = {
                            selectedEquipmentIds = if (isSelected) {
                                selectedEquipmentIds - equipment.id
                            } else {
                                selectedEquipmentIds + equipment.id
                            }
                        },
                        onClick = {
                            if (isBulkMode) {
                                selectedEquipmentIds = if (isSelected) {
                                    selectedEquipmentIds - equipment.id
                                } else {
                                    selectedEquipmentIds + equipment.id
                                }
                            } else {
                                onNavigateToDetail(equipment.id)
                            }
                        },
                        onQuickInspection = { inspectionEquipment = equipment },
                        onQuickReplaceFuse = { replaceFuseEquipment = equipment }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(70.dp)) }
        }
    }

    // Dialog cập nhật trạng thái hàng loạt
    if (showBulkStatusDialog && selectedEquipmentIds.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { showBulkStatusDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Build,
                    contentDescription = null,
                    tint = SpcYellow,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Đổi Trạng Thái Hàng Loạt",
                    fontWeight = FontWeight.Bold,
                    color = SpcNavy
                )
            },
            text = {
                Column {
                    Text(
                        text = "Chọn trạng thái mới để áp dụng đồng loạt cho ${selectedEquipmentIds.size} thiết bị đã chọn:",
                        fontSize = 13.sp,
                        color = Color(0xFF334155)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    EquipmentStatus.entries.forEach { status ->
                        Button(
                            onClick = {
                                viewModel.updateEquipmentBulkStatus(selectedEquipmentIds, status)
                                showBulkStatusDialog = false
                                isBulkMode = false
                                selectedEquipmentIds = emptySet()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = when (status) {
                                    EquipmentStatus.OPERATIONAL -> StatusNormalGreen
                                    EquipmentStatus.WARNING -> StatusWarningAmber
                                    EquipmentStatus.DEFECT -> StatusDangerRed
                                    EquipmentStatus.MAINTENANCE -> SpcNavy
                                }
                            )
                        ) {
                            Text(
                                "Chuyển thành: ${status.label}",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                Button(
                    onClick = { showBulkStatusDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                ) {
                    Text("Đóng")
                }
            }
        )
    }

    // Dialogs
    if (showInspectorSettingsDialog) {
        InspectorSettingsDialog(
            viewModel = viewModel,
            onOpenPdfReport = {
                showInspectorSettingsDialog = false
                showPdfReportDialog = true
            },
            onDismiss = { showInspectorSettingsDialog = false }
        )
    }

    if (showPdfReportDialog) {
        PdfReportDialog(
            equipments = equipments,
            maintenanceRecords = maintenanceRecords,
            inspections = inspections,
            defects = defects,
            corridors = corridors,
            onDismiss = { showPdfReportDialog = false }
        )
    }

    if (showAddEquipmentDialog) {
        AddEquipmentDialog(
            onDismiss = { showAddEquipmentDialog = false },
            onSave = {
                viewModel.saveEquipment(it)
                showAddEquipmentDialog = false
            }
        )
    }

    inspectionEquipment?.let { eq ->
        AddInspectionDialog(
            equipment = eq,
            onDismiss = { inspectionEquipment = null },
            onSave = {
                viewModel.addInspection(it)
                inspectionEquipment = null
            }
        )
    }

    replaceFuseEquipment?.let { eq ->
        ReplaceFuseDialog(
            equipment = eq,
            onDismiss = { replaceFuseEquipment = null },
            onConfirm = { fType, fRating, notes ->
                viewModel.replaceFuse(eq.id, fType, fRating, notes)
                replaceFuseEquipment = null
            }
        )
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    accentColor: Color,
    modifier: Modifier = Modifier,
    isAlert: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = modifier
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isAlert) Color(0xFFFEE2E2) else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isAlert) 1.5.dp else 1.dp,
            color = if (isAlert) StatusDangerRed else Color(0xFFE2E8F0)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontSize = 19.sp,
                fontWeight = FontWeight.ExtraBold,
                color = accentColor
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (isAlert) StatusDangerRed else Color(0xFF64748B),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun EquipmentItemCard(
    equipment: GridEquipment,
    onClick: () -> Unit,
    onQuickInspection: () -> Unit,
    onQuickReplaceFuse: () -> Unit,
    modifier: Modifier = Modifier,
    isBulkMode: Boolean = false,
    isSelected: Boolean = false,
    onToggleSelect: () -> Unit = {}
) {
    val now = System.currentTimeMillis()
    val oneDayMs = 24 * 3600 * 1000L
    val isOverdue = equipment.nextInspectionDate in 1 until now
    val daysUntilDue = ((equipment.nextInspectionDate - now) / oneDayMs).toInt()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clickable { onClick() }
            .testTag("equipment_card_${equipment.code}"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) SpcYellow.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) SpcYellow else Color(0xFFE2E8F0)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Checkbox (if bulk mode) + Code + Type badge + Status badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isBulkMode) {
                        Checkbox(
                            checked = isSelected,
                            onCheckedChange = { onToggleSelect() },
                            colors = CheckboxDefaults.colors(
                                checkedColor = SpcNavy,
                                checkmarkColor = Color.White
                            ),
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    EquipmentTypeBadge(type = equipment.type)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = equipment.code,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SpcNavy
                    )
                }
                EquipmentStatusBadge(status = equipment.status)
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Name
            Text(
                text = equipment.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1E293B),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Location: Line & Pole
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${equipment.lineName} • Cột ${equipment.poleNumber}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B)
                )
            }

            // Specific details: Fuse link info for FCO/LBFCO
            if (equipment.type == EquipmentType.FCO || equipment.type == EquipmentType.LBFCO) {
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFFF8FAFC))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⚡ Dây chì: ${if (equipment.fuseRating.isNotBlank()) equipment.fuseRating else "Chưa cài"} (${equipment.fuseType}) ${if (equipment.protectedCapacity.isNotBlank()) "• TBA ${equipment.protectedCapacity}" else ""}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = "Thay: ${if (equipment.fuseReplacedDate.isNotBlank()) equipment.fuseReplacedDate else "Chưa có"}",
                            fontSize = 10.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }

            // Controller & Telemetry for Recloser / LBS / LA
            if (equipment.type == EquipmentType.RECLOSER || equipment.type == EquipmentType.LBS) {
                if (equipment.controllerType.isNotBlank() || equipment.sf6Pressure.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFF8FAFC))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "🎛️ Bộ điều khiển: ${equipment.controllerType} ${if (equipment.sf6Pressure.isNotBlank()) "• Áp lực SF6: ${equipment.sf6Pressure}" else ""}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF334155),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Inspection Due & Quick Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Next inspection pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            when {
                                isOverdue -> Color(0xFFFEE2E2)
                                daysUntilDue in 0..7 -> Color(0xFFFEF3C7)
                                else -> Color(0xFFF1F5F9)
                            }
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = when {
                            isOverdue -> "⚠️ Quá hạn kiểm tra (${formatTimestamp(equipment.nextInspectionDate)})"
                            daysUntilDue in 0..7 -> "⏳ Sắp đến hạn ($daysUntilDue ngày)"
                            else -> "K/tra định kỳ: ${formatTimestamp(equipment.nextInspectionDate)}"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = when {
                            isOverdue -> StatusDangerRed
                            daysUntilDue in 0..7 -> StatusWarningAmber
                            else -> Color(0xFF475569)
                        }
                    )
                }

                // Quick Action buttons
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (equipment.type == EquipmentType.FCO || equipment.type == EquipmentType.LBFCO) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(SpcYellow.copy(alpha = 0.12f))
                                .clickable { onQuickReplaceFuse() }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                "Thay chì",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SpcYellow
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(SpcNavy.copy(alpha = 0.1f))
                            .clickable { onQuickInspection() }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            "+ Ghi K/Tra",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SpcNavy
                        )
                    }
                }
            }
        }
    }
}
