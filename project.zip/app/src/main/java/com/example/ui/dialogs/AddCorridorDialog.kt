package com.example.ui.dialogs

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.CorridorStatus
import com.example.data.model.HazardRiskLevel
import com.example.data.model.HazardType
import com.example.data.model.SafetyCorridorRecord
import com.example.ui.theme.ElectricBlue
import com.example.util.CameraPhotoHelper

@Composable
fun AddCorridorDialog(
    onDismiss: () -> Unit,
    onSave: (SafetyCorridorRecord) -> Unit
) {
    val context = LocalContext.current
    var lineName by remember { mutableStateOf("Đường dây 471 E1.1") }
    var spanLocation by remember { mutableStateOf("Khoảng cột ") }
    var hazardType by remember { mutableStateOf(HazardType.TREE) }
    var description by remember { mutableStateOf("") }
    var currentDistance by remember { mutableStateOf("1.2 m (Quy định >= 2.0 m)") }
    var riskLevel by remember { mutableStateOf(HazardRiskLevel.HIGH) }
    var photoBase64 by remember { mutableStateOf<String?>(null) }
    var capturedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            capturedBitmap = bitmap
            photoBase64 = CameraPhotoHelper.bitmapToBase64(bitmap)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch()
        } else {
            Toast.makeText(context, "Cần cấp quyền máy ảnh để chụp ảnh hiện trường!", Toast.LENGTH_SHORT).show()
        }
    }

    var typeDropdownExpanded by remember { mutableStateOf(false) }
    var riskDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Ghi Nhận Vi Phạm Hành Lang An Toàn", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Loại vi phạm (Cây xanh, Nhà cửa, Thiết bị khác)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { typeDropdownExpanded = true },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Đối tượng vi phạm hành lang", style = MaterialTheme.typography.labelSmall)
                        Text(
                            text = hazardType.label,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        DropdownMenu(
                            expanded = typeDropdownExpanded,
                            onDismissRequest = { typeDropdownExpanded = false }
                        ) {
                            HazardType.entries.forEach { entry ->
                                DropdownMenuItem(
                                    text = { Text(entry.label) },
                                    onClick = {
                                        hazardType = entry
                                        typeDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Mức độ nguy cơ
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { riskDropdownExpanded = true },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Mức độ nguy cơ", style = MaterialTheme.typography.labelSmall)
                        Text(
                            text = riskLevel.label,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (riskLevel == HazardRiskLevel.HIGH) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                        )
                        DropdownMenu(
                            expanded = riskDropdownExpanded,
                            onDismissRequest = { riskDropdownExpanded = false }
                        ) {
                            HazardRiskLevel.entries.forEach { entry ->
                                DropdownMenuItem(
                                    text = { Text(entry.label) },
                                    onClick = {
                                        riskLevel = entry
                                        riskDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = lineName,
                        onValueChange = { lineName = it },
                        label = { Text("Tuyến đường dây") },
                        modifier = Modifier.weight(1.2f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = spanLocation,
                        onValueChange = { spanLocation = it },
                        label = { Text("Vị trí khoảng cột") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = currentDistance,
                    onValueChange = { currentDistance = it },
                    label = { Text("Khoảng cách đo thực tế tới dây pha") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Mô tả vi phạm (chi tiết cây xanh/nhà cửa/mái tôn)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("corridor_desc_input"),
                    minLines = 2
                )

                // Chụp ảnh hiện trường vi phạm hành lang
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Ảnh chụp hiện trường",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Button(
                                onClick = {
                                    val hasPermission = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.CAMERA
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (hasPermission) {
                                        cameraLauncher.launch()
                                    } else {
                                        permissionLauncher.launch(Manifest.permission.CAMERA)
                                    }
                                },
                                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                                modifier = Modifier.testTag("corridor_camera_btn")
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = "Chụp ảnh", modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (photoBase64 == null) "Chụp ảnh" else "Chụp lại", fontSize = 12.sp)
                            }
                        }

                        if (capturedBitmap != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black)
                            ) {
                                Image(
                                    bitmap = capturedBitmap!!.asImageBitmap(),
                                    contentDescription = "Ảnh hiện trường",
                                    modifier = Modifier.fillMaxWidth().height(180.dp),
                                    contentScale = ContentScale.Crop
                                )
                                IconButton(
                                    onClick = {
                                        capturedBitmap = null
                                        photoBase64 = null
                                    },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(50))
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Xóa ảnh", tint = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (description.isNotBlank() && spanLocation.isNotBlank()) {
                        val corridor = SafetyCorridorRecord(
                            lineName = lineName,
                            spanLocation = spanLocation,
                            hazardType = hazardType,
                            description = description,
                            currentDistance = currentDistance,
                            riskLevel = riskLevel,
                            discoveredDate = System.currentTimeMillis(),
                            status = CorridorStatus.VIOLATION_EXISTING,
                            photoBase64 = photoBase64
                        )
                        onSave(corridor)
                    }
                },
                modifier = Modifier.testTag("save_corridor_btn")
            ) {
                Text("Lưu vi phạm")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}
