package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DefectRecord
import com.example.data.model.DefectSeverity
import com.example.data.model.DefectStatus
import com.example.ui.components.DefectSeverityBadge
import com.example.ui.components.DefectStatusBadge
import com.example.ui.components.formatDateTime
import com.example.ui.components.formatTimestamp
import com.example.ui.dialogs.AddDefectDialog
import com.example.ui.dialogs.DefectPdfReportDialog
import com.example.ui.dialogs.ResolveDefectDialog
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GridAmber
import com.example.ui.theme.SpcNavy
import com.example.ui.theme.StatusDangerRed
import com.example.ui.theme.StatusNormalGreen
import com.example.ui.theme.StatusWarningAmber
import com.example.ui.viewmodel.GridViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DefectsScreen(
    viewModel: GridViewModel,
    modifier: Modifier = Modifier
) {
    val defects by viewModel.allDefects.collectAsStateWithLifecycle()
    val equipments by viewModel.allEquipments.collectAsStateWithLifecycle()

    var statusFilter by remember { mutableStateOf<DefectStatus?>(null) } // null = Tất cả
    var severityFilter by remember { mutableStateOf<DefectSeverity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var resolvingDefect by remember { mutableStateOf<DefectRecord?>(null) }
    var reportingDefect by remember { mutableStateOf<DefectRecord?>(null) }

    val filteredDefects = defects.filter { d ->
        val matchStatus = statusFilter == null || d.status == statusFilter
        val matchSeverity = severityFilter == null || d.severity == severityFilter
        matchStatus && matchSeverity
    }

    val activeCount = defects.count { it.status != DefectStatus.RESOLVED }
    val criticalCount = defects.count { it.status != DefectStatus.RESOLVED && it.severity == DefectSeverity.CRITICAL }
    val resolvedCount = defects.count { it.status == DefectStatus.RESOLVED }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "Quản Lý Khiếm Khuyết Lưới Điện",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            "Khiếm khuyết đang có & Thực hiện đã khắc phục",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SpcNavy)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = StatusDangerRed,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_defect_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Báo khiếm khuyết")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Stats Row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$activeCount", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = StatusDangerRed)
                            Text("Đang có", fontSize = 11.sp, color = StatusDangerRed)
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$criticalCount", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = StatusWarningAmber)
                            Text("Khẩn cấp", fontSize = 11.sp, color = StatusWarningAmber)
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$resolvedCount", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = StatusNormalGreen)
                            Text("Đã khắc phục", fontSize = 11.sp, color = StatusNormalGreen)
                        }
                    }
                }
            }

            // Filter Chips by Status
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = statusFilter == null,
                        onClick = { statusFilter = null },
                        label = { Text("Tất cả (${defects.size})") }
                    )
                    FilterChip(
                        selected = statusFilter == DefectStatus.PENDING,
                        onClick = { statusFilter = DefectStatus.PENDING },
                        label = { Text("Đang tồn tại") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StatusDangerRed,
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = statusFilter == DefectStatus.IN_PROGRESS,
                        onClick = { statusFilter = DefectStatus.IN_PROGRESS },
                        label = { Text("Đang khắc phục") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StatusWarningAmber,
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = statusFilter == DefectStatus.RESOLVED,
                        onClick = { statusFilter = DefectStatus.RESOLVED },
                        label = { Text("Đã khắc phục") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StatusNormalGreen,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            // Defects List
            if (filteredDefects.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Không có khiếm khuyết nào trong mục này", color = MaterialTheme.colorScheme.outline)
                    }
                }
            } else {
                items(filteredDefects, key = { it.id }) { defect ->
                    DefectItemCard(
                        defect = defect,
                        onResolve = { resolvingDefect = defect },
                        onReportPdf = { reportingDefect = defect }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(70.dp)) }
        }
    }

    if (showAddDialog) {
        AddDefectDialog(
            equipmentList = equipments,
            onDismiss = { showAddDialog = false },
            onSave = {
                viewModel.saveDefect(it)
                showAddDialog = false
            }
        )
    }

    resolvingDefect?.let { d ->
        ResolveDefectDialog(
            defect = d,
            onDismiss = { resolvingDefect = null },
            onConfirm = { by, notes ->
                viewModel.resolveDefect(d.id, by, notes)
                resolvingDefect = null
            }
        )
    }

    reportingDefect?.let { d ->
        DefectPdfReportDialog(
            defect = d,
            onDismiss = { reportingDefect = null }
        )
    }
}

@Composable
fun DefectItemCard(
    defect: DefectRecord,
    onResolve: () -> Unit,
    onReportPdf: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Severity & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                DefectSeverityBadge(defect.severity)
                DefectStatusBadge(defect.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Title & Equipment
            Text(
                text = defect.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            if (defect.equipmentCode != null) {
                Text(
                    text = "Thiết bị: ${defect.equipmentCode} • Hạng mục: ${defect.category}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ElectricBlue,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Description
            Text(
                text = defect.description,
                style = MaterialTheme.typography.bodyMedium
            )

            // Action plan
            if (defect.actionPlan.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFFFFF8E1))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "🛠️ Phương án: ${defect.actionPlan}",
                        fontSize = 12.sp,
                        color = Color(0xFFE65100),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Ảnh chụp hiện trường nếu có
            if (!defect.photoBase64.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                val photoBitmap = remember(defect.photoBase64) {
                    com.example.util.CameraPhotoHelper.base64ToBitmap(defect.photoBase64)
                }
                if (photoBitmap != null) {
                    androidx.compose.foundation.Image(
                        bitmap = photoBitmap.asImageBitmap(),
                        contentDescription = "Ảnh hiện trường khiếm khuyết",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                    )
                }
            }

            // Reporter & Date
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Phát hiện: ${defect.reportedBy} • ${formatDateTime(defect.reportedDate)}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Resolution details if resolved, or button to resolve if pending
            if (defect.status == DefectStatus.RESOLVED) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFE8F5E9))
                        .padding(10.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = StatusNormalGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ĐÃ KHẮC PHỤC THÀNH CÔNG", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = StatusNormalGreen)
                        }
                        if (defect.resolvedDate != null) {
                            Text("Ngày hoàn thành: ${formatDateTime(defect.resolvedDate)}", fontSize = 11.sp)
                        }
                        if (defect.resolvedBy != null) {
                            Text("Đơn vị thực hiện: ${defect.resolvedBy}", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        }
                        if (defect.resolutionNotes != null) {
                            Text("Biên bản: ${defect.resolutionNotes}", fontSize = 11.sp)
                        }
                    }
                }
            }

            // Action buttons
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onReportPdf,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("report_defect_pdf_btn_${defect.id}"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ký & Báo Cáo QLVH", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                if (defect.status != DefectStatus.RESOLVED) {
                    Button(
                        onClick = onResolve,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("resolve_defect_btn_${defect.id}"),
                        colors = ButtonDefaults.buttonColors(containerColor = StatusNormalGreen),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("✓ Đã khắc phục", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
