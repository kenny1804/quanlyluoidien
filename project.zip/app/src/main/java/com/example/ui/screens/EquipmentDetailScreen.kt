package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DefectRecord
import com.example.data.model.EquipmentStatus
import com.example.data.model.EquipmentType
import com.example.data.model.GridEquipment
import com.example.data.model.MaintenanceRecord
import com.example.data.model.PeriodicInspection
import com.example.data.model.SafetyCorridorRecord
import com.example.ui.components.DefectSeverityBadge
import com.example.ui.components.DefectStatusBadge
import com.example.ui.components.EquipmentStatusBadge
import com.example.ui.components.EquipmentTypeBadge
import com.example.ui.components.HazardRiskBadge
import com.example.ui.components.HazardStatusBadge
import com.example.ui.components.formatDateTime
import com.example.ui.components.formatTimestamp
import com.example.ui.dialogs.AddDefectDialog
import com.example.ui.dialogs.AddEquipmentDialog
import com.example.ui.dialogs.AddInspectionDialog
import com.example.ui.dialogs.AddMaintenanceDialog
import com.example.ui.dialogs.PdfReportDialog
import com.example.ui.dialogs.ReplaceFuseDialog
import com.example.ui.theme.SpcNavy
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GridAmber
import com.example.ui.theme.StatusDangerRed
import com.example.ui.theme.StatusNormalGreen
import com.example.ui.theme.StatusWarningAmber
import com.example.ui.viewmodel.GridViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EquipmentDetailScreen(
    viewModel: GridViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val equipment by viewModel.selectedEquipment.collectAsStateWithLifecycle()
    val inspections by viewModel.selectedEquipmentInspections.collectAsStateWithLifecycle()
    val maintenanceList by viewModel.selectedEquipmentMaintenance.collectAsStateWithLifecycle()
    val defects by viewModel.selectedEquipmentDefects.collectAsStateWithLifecycle()
    val corridorRecords by viewModel.corridorRecords.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showAddInspectionDialog by remember { mutableStateOf(false) }
    var showAddMaintenanceDialog by remember { mutableStateOf(false) }
    var showAddDefectDialog by remember { mutableStateOf(false) }
    var showReplaceFuseDialog by remember { mutableStateOf(false) }
    var showPdfDialog by remember { mutableStateOf(false) }

    val eq = equipment
    if (eq == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Không tìm thấy thông tin thiết bị")
        }
        return
    }

    val relatedCorridors = remember(corridorRecords, eq) {
        corridorRecords.filter {
            it.lineName.contains(eq.lineName, ignoreCase = true) || eq.lineName.contains(it.lineName, ignoreCase = true)
        }
    }

    val now = System.currentTimeMillis()
    val isOverdue = eq.nextInspectionDate in 1 until now

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(eq.code, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(eq.type.displayName, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.8f))
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { showPdfDialog = true }) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "Xuất PDF", tint = Color.White)
                    }
                    IconButton(onClick = { showEditDialog = true }) {
                        Icon(Icons.Default.Edit, contentDescription = "Sửa", tint = Color.White)
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Xóa", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SpcNavy)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header summary card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            EquipmentTypeBadge(eq.type)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(eq.code, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        }
                        EquipmentStatusBadge(eq.status)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(eq.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    Text("${eq.lineName} • ${eq.poleNumber} • ${eq.substation}", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF475569))

                    Spacer(modifier = Modifier.height(10.dp))

                    // Alert pill for next inspection
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isOverdue) Color(0xFFFFEBEE) else Color(0xFFF1F5F9))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Lịch kiểm tra định kỳ (${eq.inspectionIntervalDays} ngày/lần)", fontSize = 11.sp, color = Color(0xFF475569))
                            Text(
                                text = if (isOverdue) "⚠️ QUÁ HẠN: ${formatTimestamp(eq.nextInspectionDate)}" else "Đến hạn: ${formatTimestamp(eq.nextInspectionDate)}",
                                fontWeight = FontWeight.Bold,
                                color = if (isOverdue) StatusDangerRed else StatusNormalGreen,
                                fontSize = 13.sp
                            )
                        }
                        Button(
                            onClick = { showAddInspectionDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SpcNavy),
                            modifier = Modifier.testTag("add_inspection_action_btn")
                        ) {
                            Text("+ Ghi kiểm tra", fontSize = 12.sp)
                        }
                    }
                }
            }

            // Primary Tabs
            PrimaryTabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Thông Số") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Kiểm Tra (${inspections.size})") }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Bảo Dưỡng (${maintenanceList.size})") }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Khiếm Khuyết (${defects.size})") }
                )
                Tab(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    text = { Text("Hành Lang (${relatedCorridors.size})") }
                )
            }

            // Tab contents
            when (selectedTab) {
                0 -> SpecsTabContent(
                    equipment = eq,
                    onReplaceFuse = { showReplaceFuseDialog = true }
                )
                1 -> InspectionsTabContent(
                    inspections = inspections,
                    onAddInspection = { showAddInspectionDialog = true }
                )
                2 -> MaintenanceTabContent(
                    maintenanceList = maintenanceList,
                    onAddMaintenance = { showAddMaintenanceDialog = true }
                )
                3 -> DefectsTabContent(
                    defects = defects,
                    onAddDefect = { showAddDefectDialog = true }
                )
                4 -> CorridorsTabContent(
                    corridors = relatedCorridors
                )
            }
        }
    }

    // Dialogs
    if (showEditDialog) {
        AddEquipmentDialog(
            initialEquipment = eq,
            onDismiss = { showEditDialog = false },
            onSave = {
                viewModel.saveEquipment(it)
                showEditDialog = false
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Xác nhận xóa thiết bị") },
            text = { Text("Bạn có chắc chắn muốn xóa thiết bị ${eq.code} (${eq.name}) khỏi hệ thống?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteEquipment(eq)
                        showDeleteConfirm = false
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed)
                ) {
                    Text("Xóa thiết bị")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteConfirm = false }) {
                    Text("Hủy")
                }
            }
        )
    }

    if (showAddInspectionDialog) {
        AddInspectionDialog(
            equipment = eq,
            onDismiss = { showAddInspectionDialog = false },
            onSave = {
                viewModel.addInspection(it)
                showAddInspectionDialog = false
            }
        )
    }

    if (showAddMaintenanceDialog) {
        AddMaintenanceDialog(
            equipment = eq,
            onDismiss = { showAddMaintenanceDialog = false },
            onSave = {
                viewModel.addMaintenance(it)
                showAddMaintenanceDialog = false
            }
        )
    }

    if (showAddDefectDialog) {
        AddDefectDialog(
            equipmentList = listOf(eq),
            preselectedEquipment = eq,
            onDismiss = { showAddDefectDialog = false },
            onSave = {
                viewModel.saveDefect(it)
                showAddDefectDialog = false
            }
        )
    }

    if (showReplaceFuseDialog) {
        ReplaceFuseDialog(
            equipment = eq,
            onDismiss = { showReplaceFuseDialog = false },
            onConfirm = { fType, fRating, notes ->
                viewModel.replaceFuse(eq.id, fType, fRating, notes)
                showReplaceFuseDialog = false
            }
        )
    }

    if (showPdfDialog) {
        PdfReportDialog(
            equipments = listOf(eq),
            maintenanceRecords = maintenanceList,
            inspections = inspections,
            defects = defects,
            corridors = corridorRecords,
            preSelectedEquipmentId = eq.id,
            onDismiss = { showPdfDialog = false }
        )
    }
}

@Composable
fun SpecsTabContent(
    equipment: GridEquipment,
    onReplaceFuse: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Thông số dây chì & TBA bảo vệ (FCO / LBFCO)
        if (equipment.type == EquipmentType.FCO || equipment.type == EquipmentType.LBFCO) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF3E5F5))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "⚡ Thông Số Dây Chì & Máy Biến Áp",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF4A148C)
                            )
                            Button(
                                onClick = onReplaceFuse,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6A1B9A))
                            ) {
                                Text("Thay chì mới", fontSize = 11.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        SpecRow("Trị số chì định mức:", if (equipment.fuseRating.isNotBlank()) equipment.fuseRating else "Chưa cài đặt")
                        SpecRow("Chủng loại dây chì:", equipment.fuseType)
                        SpecRow("Dung lượng TBA bảo vệ:", if (equipment.protectedCapacity.isNotBlank()) equipment.protectedCapacity else "N/A")
                        SpecRow("Ngày thay chì gần nhất:", if (equipment.fuseReplacedDate.isNotBlank()) equipment.fuseReplacedDate else "Chưa ghi nhận")
                    }
                }
            }
        }

        // Thông số đặc thù Recloser / LBS / LA
        if (equipment.type == EquipmentType.RECLOSER || equipment.type == EquipmentType.LBS || equipment.type == EquipmentType.LA) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F7FA))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            "🎛️ Giám Sát Điều Khiển & Telemetry",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF006064)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        if (equipment.controllerType.isNotBlank()) {
                            SpecRow("Tủ điều khiển / Rơle:", equipment.controllerType)
                        }
                        if (equipment.protectionSettings.isNotBlank()) {
                            SpecRow("Chỉnh định bảo vệ:", equipment.protectionSettings)
                        }
                        if (equipment.sf6Pressure.isNotBlank()) {
                            SpecRow("Áp lực khí SF6:", equipment.sf6Pressure)
                        }
                        if (equipment.surgeCounter > 0 || equipment.type == EquipmentType.LA || equipment.type == EquipmentType.RECLOSER) {
                            SpecRow(
                                if (equipment.type == EquipmentType.LA) "Số lần đếm sét:" else "Số lần đóng cắt / nhảy:",
                                "${equipment.surgeCounter} lần"
                            )
                        }
                    }
                }
            }
        }

        // Thông số kỹ thuật điện
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Thông Số Kỹ Thuật Điện", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    SpecRow("Điện áp định mức (Un):", equipment.ratedVoltage)
                    SpecRow("Dòng điện định mức (In):", equipment.ratedCurrent)
                    SpecRow("Dòng cắt ngắn mạch (Icn):", equipment.breakingCapacity)
                    SpecRow("Điện trở tiếp địa (Rtd):", equipment.groundingResistance)
                    SpecRow("Hãng sản xuất:", equipment.manufacturer)
                    SpecRow("Model / Kiểu loại:", equipment.model)
                    SpecRow("Ngày đưa vào vận hành:", equipment.installationDate)
                }
            }
        }

        // Lịch bảo dưỡng & kiểm tra
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Lịch Trình Kiểm Tra & Bảo Dưỡng", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    SpecRow("Chu kỳ kiểm tra:", "${equipment.inspectionIntervalDays} ngày")
                    SpecRow("Lần kiểm tra gần nhất:", formatTimestamp(equipment.lastInspectionDate))
                    SpecRow("Đến hạn kiểm tra:", formatTimestamp(equipment.nextInspectionDate))
                    SpecRow("Chu kỳ bảo dưỡng:", "${equipment.maintenanceIntervalDays} ngày")
                    SpecRow("Lần bảo dưỡng gần nhất:", formatTimestamp(equipment.lastMaintenanceDate))
                    SpecRow("Đến hạn bảo dưỡng:", formatTimestamp(equipment.nextMaintenanceDate))
                }
            }
        }

        if (equipment.notes.isNotBlank()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Ghi Chú Kỹ Thuật", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(equipment.notes, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(40.dp)) }
    }
}

@Composable
fun SpecRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF334155))
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = Color(0xFF0F172A))
    }
}

@Composable
fun InspectionsTabContent(
    inspections: List<PeriodicInspection>,
    onAddInspection: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Nhật Ký Kiểm Tra Định Kỳ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Button(onClick = onAddInspection) {
                    Text("+ Thêm phiếu")
                }
            }
        }

        if (inspections.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Chưa có phiếu kiểm tra định kỳ nào", color = MaterialTheme.colorScheme.outline)
                }
            }
        } else {
            items(inspections, key = { it.id }) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                item.inspectionType,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyLarge,
                                color = ElectricBlue
                            )
                            Text(
                                formatDateTime(item.inspectionDate),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text("Người kiểm tra: ${item.inspectorName}", style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        if (item.temperatureJoints.isNotBlank()) {
                            Text("🌡️ Nhiệt độ mối nối: ${item.temperatureJoints}", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                        if (item.insulatorCondition.isNotBlank()) {
                            Text("🛡️ Sứ cách điện: ${item.insulatorCondition}", fontSize = 12.sp)
                        }
                        if (item.groundingCondition.isNotBlank()) {
                            Text("⏚ Tiếp địa: ${item.groundingCondition}", fontSize = 12.sp)
                        }
                        if (item.sf6OrOilStatus.isNotBlank()) {
                            Text("⚙️ Khí SF6/Dầu: ${item.sf6OrOilStatus}", fontSize = 12.sp)
                        }
                        Text(
                            "Kết quả: ${item.resultStatus}",
                            fontWeight = FontWeight.Bold,
                            color = if (item.resultStatus.contains("Đạt", ignoreCase = true)) StatusNormalGreen else StatusDangerRed,
                            fontSize = 12.sp
                        )
                        if (item.notes.isNotBlank()) {
                            Text("Ghi chú: ${item.notes}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(40.dp)) }
    }
}

@Composable
fun MaintenanceTabContent(
    maintenanceList: List<MaintenanceRecord>,
    onAddMaintenance: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Lịch Sử Bảo Dưỡng & Sửa Chữa", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Button(onClick = onAddMaintenance) {
                    Text("+ Ghi bảo dưỡng")
                }
            }
        }

        if (maintenanceList.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Chưa có bản ghi bảo dưỡng nào", color = MaterialTheme.colorScheme.outline)
                }
            }
        } else {
            items(maintenanceList, key = { it.id }) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(item.maintenanceType, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge, color = GridAmber)
                            Text(formatDateTime(item.maintenanceDate), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("Đơn vị thực hiện: ${item.workUnit}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Nội dung: ${item.content}", style = MaterialTheme.typography.bodyMedium)
                        if (item.partsReplaced.isNotBlank()) {
                            Text("Vật tư thay thế: ${item.partsReplaced}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        }
                        Text("Nghiệm thu: ${item.outcome}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = StatusNormalGreen)
                        if (item.supervisor.isNotBlank()) {
                            Text("Giám sát: ${item.supervisor}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(40.dp)) }
    }
}

@Composable
fun DefectsTabContent(
    defects: List<com.example.data.model.DefectRecord>,
    onAddDefect: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Khiếm Khuyết Của Thiết Bị", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Button(onClick = onAddDefect) {
                    Text("+ Báo khiếm khuyết")
                }
            }
        }

        if (defects.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Thiết bị này không có khiếm khuyết nào", color = MaterialTheme.colorScheme.outline)
                }
            }
        } else {
            items(defects, key = { it.id }) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            DefectSeverityBadge(item.severity)
                            DefectStatusBadge(item.status)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(item.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text(item.description, style = MaterialTheme.typography.bodySmall)
                        if (item.actionPlan.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Phương án: ${item.actionPlan}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                        }
                        if (item.resolutionNotes != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Đã khắc phục: ${item.resolutionNotes}", fontSize = 11.sp, color = StatusNormalGreen, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(40.dp)) }
    }
}

@Composable
fun CorridorsTabContent(
    corridors: List<SafetyCorridorRecord>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                "Hành Lang An Toàn Lưới Điện (Cây Xanh, Nhà Cửa)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
        }

        if (corridors.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Không có điểm vi phạm hành lang an toàn nào trên xuất tuyến này", color = Color(0xFF64748B))
                }
            }
        } else {
            items(corridors, key = { it.id }) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            HazardRiskBadge(item.riskLevel)
                            HazardStatusBadge(item.status)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "${item.hazardType.label} • ${item.spanLocation}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            item.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF334155)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Khoảng cách hiện tại: ${item.currentDistance}",
                                fontSize = 11.sp,
                                color = Color(0xFF475569),
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                "Phát hiện: ${formatTimestamp(item.discoveredDate)}",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                        if (!item.clearanceActionTaken.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Biện pháp: ${item.clearanceActionTaken}",
                                fontSize = 11.sp,
                                color = Color(0xFF15803D),
                                fontWeight = FontWeight.Medium
                            )
                        }
                        if (!item.clearedBy.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                "Đơn vị xử lý: ${item.clearedBy}",
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(40.dp)) }
    }
}
