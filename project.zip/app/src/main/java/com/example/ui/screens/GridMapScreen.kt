package com.example.ui.screens

import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Forest
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationSearching
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.SslErrorHandler
import android.net.http.SslError
import android.view.ViewGroup
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.model.CorridorStatus
import com.example.data.model.EquipmentStatus
import com.example.data.model.EquipmentType
import com.example.data.model.GridEquipment
import com.example.data.model.HazardType
import com.example.data.model.SafetyCorridorRecord
import com.example.ui.dialogs.EditSubstationDialog
import com.example.ui.dialogs.ManageSubstationsDialog
import com.example.ui.dialogs.PdfReportDialog
import com.example.ui.viewmodel.GridViewModel
import com.example.util.GeoCoordinates
import com.example.util.SubstationLocation
import kotlin.math.hypot

enum class MapFilter(val displayName: String) {
    ALL("Tất cả"),
    SWITCHES("Recloser & LBS"),
    FUSES("Cầu chì FCO / LBFCO"),
    ALERTS("⚠️ Cảnh báo / Khiếm khuyết"),
    CORRIDORS("🚨 Vi phạm hành lang")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GridMapScreen(
    viewModel: GridViewModel,
    onNavigateToEquipment: (Long) -> Unit,
    onNavigateToCorridor: () -> Unit
) {
    val equipments by viewModel.equipments.collectAsStateWithLifecycle()
    val corridorRecords by viewModel.corridorRecords.collectAsStateWithLifecycle()
    val maintenanceRecords by viewModel.maintenanceRecords.collectAsStateWithLifecycle()
    val inspections by viewModel.inspections.collectAsStateWithLifecycle()
    val defects by viewModel.defects.collectAsStateWithLifecycle()
    val substations by viewModel.substations.collectAsStateWithLifecycle()

    val context = LocalContext.current

    var selectedFilter by remember { mutableStateOf(MapFilter.ALL) }
    var selectedEquipment by remember { mutableStateOf<GridEquipment?>(null) }
    var selectedCorridor by remember { mutableStateOf<SafetyCorridorRecord?>(null) }
    var selectedSubstation by remember { mutableStateOf<SubstationLocation?>(null) }
    var showPdfDialog by remember { mutableStateOf(false) }
    var showLegendDialog by remember { mutableStateOf(false) }
    var showManageSubstationsDialog by remember { mutableStateOf(false) }
    var substationToEdit by remember { mutableStateOf<SubstationLocation?>(null) }

    // Helper: update substation coordinates using device GPS
    fun updateSubstationWithCurrentGps(sub: SubstationLocation) {
        if (sub.isLocked) {
            Toast.makeText(context, "Trạm '${sub.name}' đang bị khóa, không thể cập nhật tọa độ!", Toast.LENGTH_SHORT).show()
            return
        }
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (hasFine || hasCoarse) {
            try {
                val gpsLoc = locationManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                val netLoc = locationManager?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                val bestLoc = gpsLoc ?: netLoc

                if (bestLoc != null) {
                    viewModel.updateSubstationCoordinates(sub.id, bestLoc.latitude, bestLoc.longitude)
                    Toast.makeText(
                        context,
                        "Đã cập nhật tọa độ GPS thực tế cho ${sub.name}: ${String.format(java.util.Locale.US, "%.5f, %.5f", bestLoc.latitude, bestLoc.longitude)}",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Toast.makeText(context, "Chưa lấy được tín hiệu GPS. Vui lòng bật vị trí thiết bị.", Toast.LENGTH_SHORT).show()
                }
            } catch (e: SecurityException) {
                Toast.makeText(context, "Không có quyền truy cập vị trí: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Ứng dụng chưa được cấp quyền Vị trí GPS.", Toast.LENGTH_SHORT).show()
        }
    }

    // Permission launcher for GPS update
    var pendingGpsSubstation by remember { mutableStateOf<SubstationLocation?>(null) }
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val granted = perms[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            pendingGpsSubstation?.let { updateSubstationWithCurrentGps(it) }
        } else {
            Toast.makeText(context, "Cần cấp quyền vị trí để lấy tọa độ thực tế của trạm!", Toast.LENGTH_SHORT).show()
        }
        pendingGpsSubstation = null
    }

    // Map Transform state (Zoom & Pan for Canvas mode)
    var zoomScale by remember { mutableFloatStateOf(1.0f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }

    // Paint dùng để vẽ nhãn text trên Canvas GIS. Tạo MỘT LẦN bằng remember thay vì
    // `android.graphics.Paint()` mới trong mỗi vòng lặp vẽ (trước đây là mỗi trạm/hành lang/
    // thiết bị x mỗi frame khi pan/zoom) — chỉ đổi màu/cỡ chữ trước mỗi lần drawText để tránh
    // cấp phát object liên tục gây áp lực GC và giật khi thao tác bản đồ.
    val mapLabelPaint = remember {
        android.graphics.Paint().apply {
            isFakeBoldText = true
            textAlign = android.graphics.Paint.Align.CENTER
        }
    }

    // Map View Mode: TRUE = Bản đồ thực địa OSM/GIS (Leaflet Tile-based giống Web), FALSE = Sơ đồ số GIS Canvas
    var isOsmMapMode by remember { mutableStateOf(true) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    // Zoom level & Layer states
    var currentOsmZoom by remember { mutableIntStateOf(13) }
    var currentOsmLayer by remember { mutableStateOf("Street Map") }
    var currentMapTheme by remember { mutableStateOf("normal") } // "normal", "dark", "high-contrast"
    var showTypeFilterDialog by remember { mutableStateOf(false) }
    var typeFilterMap by remember {
        mutableStateOf(
            mapOf(
                "RECLOSER" to true,
                "LBS" to true,
                "DS" to true,
                "LA" to true,
                "FCO" to true,
                "LBFCO" to true
            )
        )
    }
    var proximityAlertMessage by remember { mutableStateOf<String?>(null) }

    // Chuyển đổi Dark Mode / High Contrast cho bản đồ thực địa
    fun cycleMapTheme() {
        if (isOsmMapMode) {
            webViewRef?.evaluateJavascript("cycleMapTheme();") { res ->
                val theme = res?.replace("\"", "") ?: "normal"
                currentMapTheme = theme
                val msg = when (theme) {
                    "dark" -> "Đã kích hoạt chế độ Ban đêm (Dark Mode) cho bản đồ"
                    "high-contrast" -> "Đã kích hoạt chế độ Tương phản cao (High Contrast) cho bản đồ"
                    else -> "Đã chuyển về chế độ Hiển thị tiêu chuẩn (Normal)"
                }
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Chế độ hiển thị áp dụng cho Bản đồ Thực địa!", Toast.LENGTH_SHORT).show()
        }
    }

    // Hàm xử lý 'Return to Home': Ưu tiên vị trí GPS nếu nằm trong ranh giới địa lý, nếu ngoài thì về trung tâm
    fun executeReturnToHome() {
        if (isOsmMapMode) {
            val fineGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            val coarseGranted = ContextCompat.checkSelfPermission(
                context, Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

            if (fineGranted || coarseGranted) {
                val locManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
                val loc = locManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: locManager?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)

                if (loc != null) {
                    val inBounds = loc.latitude in 10.0..11.2 && loc.longitude in 104.5..106.0
                    if (inBounds) {
                        webViewRef?.evaluateJavascript(
                            "setUserGpsLocation(${loc.latitude}, ${loc.longitude});",
                            null
                        )
                        Toast.makeText(
                            context,
                            "🏠 Đã định vị về vị trí GPS: ${String.format(java.util.Locale.US, "%.5f, %.5f", loc.latitude, loc.longitude)}",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        webViewRef?.evaluateJavascript("returnToHome();", null)
                        Toast.makeText(
                            context,
                            "Vị trí GPS ngoài ranh giới bản đồ (An Giang). Đã trở về trung tâm bản đồ!",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    webViewRef?.evaluateJavascript("returnToHome();", null)
                    Toast.makeText(context, "Đã trở về trung tâm bản đồ!", Toast.LENGTH_SHORT).show()
                }
            } else {
                webViewRef?.evaluateJavascript("returnToHome();", null)
                Toast.makeText(context, "Đã trở về trung tâm bản đồ!", Toast.LENGTH_SHORT).show()
            }
        } else {
            zoomScale = 1.0f
            panOffset = Offset.Zero
            Toast.makeText(context, "Đã đặt lại sơ đồ về trung tâm!", Toast.LENGTH_SHORT).show()
        }
    }

    // Hàm chuyển đổi xoay vòng lớp bản đồ: Google Maps Đường xá -> Vệ tinh -> Địa hình -> OSM
    fun cycleMapLayer() {
        if (isOsmMapMode) {
            webViewRef?.evaluateJavascript("toggleNextLayer();") { result ->
                val cleaned = result?.replace("\"", "") ?: ""
                currentOsmLayer = when (cleaned) {
                    "satellite" -> "Google Maps Vệ Tinh"
                    "terrain" -> "Google Maps Địa Hình"
                    "osm" -> "OpenStreetMap"
                    else -> "Google Maps Đường Xá"
                }
                Toast.makeText(context, "Lớp bản đồ: $currentOsmLayer", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Tính năng lớp bản đồ chỉ áp dụng cho Bản đồ Thực địa GIS!", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (isOsmMapMode) "Bản Đồ Lưới Điện GIS Thực Địa" else "Sơ Đồ Phân Bố Lưới Điện",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = Color.White
                        )
                        Text(
                            text = if (isOsmMapMode) "Nền Google Maps đường xá/vệ tinh • Trạm 110kV & 22kV" else "Sơ đồ GIS vector kỹ thuật số",
                            fontSize = 11.sp,
                            color = Color(0xFFB0BEC5)
                        )
                    }
                },
                actions = {
                    // Nút chuyển đổi giữa Bản đồ OSM và Sơ đồ Canvas
                    IconButton(
                        onClick = { isOsmMapMode = !isOsmMapMode },
                        modifier = Modifier.testTag("toggle_map_mode_button")
                    ) {
                        Icon(
                            if (isOsmMapMode) Icons.Filled.Layers else Icons.Filled.Map,
                            contentDescription = if (isOsmMapMode) "Chuyển sang Sơ đồ Canvas" else "Chuyển sang Bản đồ OSM",
                            tint = if (isOsmMapMode) Color(0xFF81D4FA) else Color.White
                        )
                    }
                    // Nút Quản lý trạm 110kV
                    IconButton(
                        onClick = { showManageSubstationsDialog = true },
                        modifier = Modifier.testTag("manage_substations_button")
                    ) {
                        Icon(
                            Icons.Default.FlashOn,
                            contentDescription = "Quản lý trạm 110kV",
                            tint = Color(0xFFFFD600)
                        )
                    }
                    IconButton(
                        onClick = { showLegendDialog = !showLegendDialog },
                        modifier = Modifier.testTag("map_legend_button")
                    ) {
                        Icon(Icons.Default.Info, contentDescription = "Chú giải", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF003366))
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF1F5F9))
        ) {
            if (isOsmMapMode) {
                // 1. Chế độ BẢN ĐỒ THỰC ĐỊA OSM TILE LAYER (giống hệt web index.html)
                AndroidView(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("osm_leaflet_webview"),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                allowFileAccess = true
                                allowContentAccess = true
                                allowFileAccessFromFileURLs = true
                                allowUniversalAccessFromFileURLs = true
                                loadWithOverviewMode = true
                                useWideViewPort = true
                                cacheMode = WebSettings.LOAD_DEFAULT
                                setSupportZoom(true)
                                builtInZoomControls = true
                                displayZoomControls = false
                                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            }
                            setBackgroundColor(android.graphics.Color.WHITE)

                            webChromeClient = object : WebChromeClient() {
                                override fun onConsoleMessage(msg: android.webkit.ConsoleMessage?): Boolean {
                                    android.util.Log.d("LeafletWebView", "[${msg?.messageLevel()}] ${msg?.message()} (line ${msg?.lineNumber()})")
                                    return true
                                }
                            }
                            webViewClient = object : WebViewClient() {
                                override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                                    handler?.proceed()
                                }
                                override fun onReceivedError(view: WebView?, request: android.webkit.WebResourceRequest?, error: android.webkit.WebResourceError?) {
                                    super.onReceivedError(view, request, error)
                                    android.util.Log.e("LeafletWebView", "Resource error on ${request?.url}: ${error?.description}")
                                }
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    val dataJson = buildGridDataJson(substations, equipments, corridorRecords)
                                    val b64 = android.util.Base64.encodeToString(dataJson.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
                                    view?.evaluateJavascript("if (typeof renderGridDataBase64 === 'function') { renderGridDataBase64('$b64'); } else if (typeof renderGridData === 'function') { renderGridData($dataJson); }", null)
                                }
                            }

                            addJavascriptInterface(object {
                                @JavascriptInterface
                                fun getInitialData(): String {
                                    return buildGridDataJson(substations, equipments, corridorRecords)
                                }

                                @JavascriptInterface
                                fun onSubstationSelected(subId: Long) {
                                    val sub = substations.find { it.id == subId }
                                    if (sub != null) {
                                        selectedSubstation = sub
                                        selectedEquipment = null
                                        selectedCorridor = null
                                    }
                                }

                                @JavascriptInterface
                                fun onEquipmentSelected(eqId: Long) {
                                    val eq = equipments.find { it.id == eqId }
                                    if (eq != null) {
                                        selectedEquipment = eq
                                        selectedSubstation = null
                                        selectedCorridor = null
                                    }
                                }

                                @JavascriptInterface
                                fun onCorridorSelected(corridorId: Long) {
                                    val cor = corridorRecords.find { it.id == corridorId }
                                    if (cor != null) {
                                        selectedCorridor = cor
                                        selectedEquipment = null
                                        selectedSubstation = null
                                    }
                                }

                                @JavascriptInterface
                                fun onCoordinateSelected(lat: Double, lng: Double) {
                                    // Chạm chọn tọa độ trên bản đồ
                                }

                                @JavascriptInterface
                                fun onZoomChanged(newZoom: Int) {
                                    currentOsmZoom = newZoom
                                }

                                @JavascriptInterface
                                fun onMapThemeChanged(theme: String) {
                                    currentMapTheme = theme
                                }

                                @JavascriptInterface
                                fun onProximityAlertTriggered(equipId: Long, equipCode: String, distance: Double) {
                                    val formattedDist = String.format(java.util.Locale.US, "%.1f", distance)
                                    proximityAlertMessage = "Cảnh báo bán kính: Bạn đang cách thiết bị $equipCode ${formattedDist}m (< 10m)!"
                                }

                                @JavascriptInterface
                                fun onPowerLineCreated(lineJson: String) {
                                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                                        Toast.makeText(context, "Đã tạo & lưu tuyến đường dây mới trực tiếp từ bản đồ!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }, "AndroidBridge")

                            loadUrl("file:///android_asset/map.html")
                            webViewRef = this
                        }
                    },
                    update = { view ->
                        webViewRef = view
                        val dataJson = buildGridDataJson(substations, equipments, corridorRecords)
                        val b64 = android.util.Base64.encodeToString(dataJson.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
                        view.evaluateJavascript("if (typeof renderGridDataBase64 === 'function') { renderGridDataBase64('$b64'); } else if (typeof renderGridData === 'function') { renderGridData($dataJson); }", null)
                    }
                )
            } else {
                // 2. Chế độ SƠ ĐỒ VECTOR CANVAS
                // Lọc danh sách thiết bị theo bộ lọc đang chọn CHỈ MỘT LẦN khi `equipments` hoặc
                // `selectedFilter` thay đổi, thay vì tính lại filter() mỗi frame vẽ lại bên trong
                // Canvas draw scope (draw scope chạy lại liên tục khi pan/zoom ở 60fps).
                val filteredEquipments = remember(equipments, selectedFilter) {
                    equipments.filter { eq ->
                        when (selectedFilter) {
                            MapFilter.ALL -> true
                            MapFilter.SWITCHES -> eq.type == EquipmentType.RECLOSER || eq.type == EquipmentType.LBS || eq.type == EquipmentType.DS
                            MapFilter.FUSES -> eq.type == EquipmentType.FCO || eq.type == EquipmentType.LBFCO || eq.type == EquipmentType.LA
                            MapFilter.ALERTS -> eq.status == EquipmentStatus.WARNING || eq.status == EquipmentStatus.DEFECT
                            MapFilter.CORRIDORS -> false
                        }
                    }
                }
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("grid_map_canvas")
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                zoomScale = (zoomScale * zoom).coerceIn(0.6f, 3.5f)
                                panOffset += pan
                            }
                        }
                        .pointerInput(equipments, corridorRecords, substations, zoomScale, panOffset) {
                            detectTapGestures { tapOffset ->
                                val width = size.width.toFloat()
                            val height = size.height.toFloat()

                            // 1. Check Substation markers click (hit test within 32dp)
                            var clickedSub: SubstationLocation? = null
                            val subHitRadius = 32.dp.toPx()
                            for (sub in substations) {
                                val screenPos = geoToScreen(sub.latitude, sub.longitude, width, height, zoomScale, panOffset)
                                val dist = hypot(tapOffset.x - screenPos.x, tapOffset.y - screenPos.y)
                                if (dist <= subHitRadius) {
                                    clickedSub = sub
                                    break
                                }
                            }

                            if (clickedSub != null) {
                                selectedSubstation = clickedSub
                                selectedEquipment = null
                                selectedCorridor = null
                                return@detectTapGestures
                            }

                            // 2. Check equipment markers click (hit test within 28dp)
                            var clickedEq: GridEquipment? = null
                            val hitRadius = 28.dp.toPx()

                            for (eq in equipments) {
                                val coords = GeoCoordinates.getEquipmentCoordinates(eq)
                                val screenPos = geoToScreen(coords.first, coords.second, width, height, zoomScale, panOffset)
                                val dist = hypot(tapOffset.x - screenPos.x, tapOffset.y - screenPos.y)
                                if (dist <= hitRadius) {
                                    clickedEq = eq
                                    break
                                }
                            }

                            if (clickedEq != null) {
                                selectedEquipment = clickedEq
                                selectedCorridor = null
                                selectedSubstation = null
                                return@detectTapGestures
                            }

                            // 3. Check corridor hazards click
                            var clickedCorridor: SafetyCorridorRecord? = null
                            for (corridor in corridorRecords) {
                                val coords = GeoCoordinates.getCorridorCoordinates(corridor)
                                val screenPos = geoToScreen(coords.first, coords.second, width, height, zoomScale, panOffset)
                                val dist = hypot(tapOffset.x - screenPos.x, tapOffset.y - screenPos.y)
                                if (dist <= hitRadius + 10.dp.toPx()) {
                                    clickedCorridor = corridor
                                    break
                                }
                            }

                            if (clickedCorridor != null) {
                                selectedCorridor = clickedCorridor
                                selectedEquipment = null
                                selectedSubstation = null
                                return@detectTapGestures
                            }

                            // Tapped empty space -> clear selection
                            selectedEquipment = null
                            selectedCorridor = null
                            selectedSubstation = null
                        }
                    }
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                // 1. Draw GIS Background Grid & Coordinates
                drawGisGrid(canvasWidth, canvasHeight, zoomScale, panOffset)

                // 2. Draw Substations & Feeder Transmission Lines
                GeoCoordinates.feederLines.forEach { line ->
                    val path = Path()
                    line.waypoints.forEachIndexed { idx, point ->
                        val screen = geoToScreen(point.first, point.second, canvasWidth, canvasHeight, zoomScale, panOffset)
                        if (idx == 0) path.moveTo(screen.x, screen.y) else path.lineTo(screen.x, screen.y)
                    }

                    // Feeder corridor glow
                    drawPath(
                        path = path,
                        color = Color(line.colorHex).copy(alpha = 0.25f),
                        style = Stroke(width = 12.dp.toPx() * zoomScale.coerceIn(0.8f, 1.8f), cap = StrokeCap.Round)
                    )

                    // Feeder distribution wire
                    drawPath(
                        path = path,
                        color = Color(line.colorHex),
                        style = Stroke(width = 3.5.dp.toPx() * zoomScale.coerceIn(0.8f, 1.8f), cap = StrokeCap.Round)
                    )

                    // Feeder Waypoint Poles
                    line.waypoints.forEach { point ->
                        val screen = geoToScreen(point.first, point.second, canvasWidth, canvasHeight, zoomScale, panOffset)
                        drawCircle(
                            color = Color.White,
                            radius = 4.dp.toPx() * zoomScale.coerceIn(0.8f, 1.5f),
                            center = screen
                        )
                        drawCircle(
                            color = Color(line.colorHex),
                            radius = 4.dp.toPx() * zoomScale.coerceIn(0.8f, 1.5f),
                            center = screen,
                            style = Stroke(width = 1.5.dp.toPx())
                        )
                    }
                }

                // 3. Draw Substation Hubs (TBA 110kV) - Using dynamic substations list
                substations.forEach { sub ->
                    val screen = geoToScreen(sub.latitude, sub.longitude, canvasWidth, canvasHeight, zoomScale, panOffset)
                    val isSelected = selectedSubstation?.id == sub.id

                    // Outer pulse ring if selected or locked
                    val outerColor = if (sub.isLocked) Color(0xFFF59E0B) else Color(0xFF003366)
                    val outerRadius = (if (isSelected) 30.dp else 24.dp).toPx() * zoomScale.coerceIn(0.8f, 1.5f)
                    drawCircle(
                        color = outerColor.copy(alpha = if (isSelected) 0.35f else 0.20f),
                        radius = outerRadius,
                        center = screen
                    )

                    // Main substation circle
                    drawCircle(
                        color = if (sub.isLocked) Color(0xFFB45309) else Color(0xFF003366),
                        radius = 16.dp.toPx() * zoomScale.coerceIn(0.8f, 1.5f),
                        center = screen
                    )

                    // Center indicator (gold for open, orange-amber if locked)
                    drawCircle(
                        color = if (sub.isLocked) Color(0xFFFFE082) else Color(0xFFFFD600),
                        radius = 8.dp.toPx() * zoomScale.coerceIn(0.8f, 1.5f),
                        center = screen
                    )

                    // Substation label with lock indicator
                    drawContext.canvas.nativeCanvas.apply {
                        mapLabelPaint.color = if (sub.isLocked) android.graphics.Color.rgb(180, 83, 9) else android.graphics.Color.rgb(0, 51, 102)
                        mapLabelPaint.textSize = (11.sp.toPx() * zoomScale.coerceIn(0.9f, 1.3f))
                        val lockPrefix = if (sub.isLocked) "🔒 " else ""
                        drawText("$lockPrefix${sub.name} (${sub.voltage})", screen.x, screen.y - 24.dp.toPx() * zoomScale.coerceIn(0.8f, 1.4f), mapLabelPaint)
                    }
                }

                // 4. Draw Safety Corridor Infringement Zones (Vùng vi phạm hành lang an toàn)
                val showCorridors = selectedFilter == MapFilter.ALL || selectedFilter == MapFilter.CORRIDORS || selectedFilter == MapFilter.ALERTS
                if (showCorridors) {
                    corridorRecords.forEach { corridor ->
                        val coords = GeoCoordinates.getCorridorCoordinates(corridor)
                        val screen = geoToScreen(coords.first, coords.second, canvasWidth, canvasHeight, zoomScale, panOffset)
                        val isSelected = selectedCorridor?.id == corridor.id

                        val zoneColor = when (corridor.status) {
                            CorridorStatus.VIOLATION_EXISTING -> Color(0xFFD32F2F) // Red danger
                            CorridorStatus.PROCESSING -> Color(0xFFF57C00) // Orange warning
                            CorridorStatus.RESOLVED -> Color(0xFF388E3C) // Green resolved
                        }

                        // Danger zone circle with dashed border
                        val zoneRadius = (if (isSelected) 36.dp else 28.dp).toPx() * zoomScale.coerceIn(0.8f, 1.5f)
                        drawCircle(
                            color = zoneColor.copy(alpha = if (isSelected) 0.35f else 0.20f),
                            radius = zoneRadius,
                            center = screen
                        )
                        drawCircle(
                            color = zoneColor,
                            radius = zoneRadius,
                            center = screen,
                            style = Stroke(
                                width = 2.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                            )
                        )

                        // Center hazard marker
                        drawCircle(
                            color = zoneColor,
                            radius = 12.dp.toPx() * zoomScale.coerceIn(0.8f, 1.4f),
                            center = screen
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 12.dp.toPx() * zoomScale.coerceIn(0.8f, 1.4f),
                            center = screen,
                            style = Stroke(width = 2.dp.toPx())
                        )

                        // Hazard label text
                        drawContext.canvas.nativeCanvas.apply {
                            mapLabelPaint.color = android.graphics.Color.rgb(211, 47, 47)
                            mapLabelPaint.textSize = (10.sp.toPx() * zoomScale.coerceIn(0.8f, 1.2f))
                            val hazardName = when (corridor.hazardType) {
                                HazardType.TREE -> "🌲 Cây xanh"
                                HazardType.HOUSE_BUILDING -> "🏢 Nhà cửa"
                                HazardType.EQUIPMENT_OTHER -> "⚠️ Mái tôn/vật thể"
                            }
                            drawText("$hazardName (${corridor.spanLocation})", screen.x, screen.y + zoneRadius + 14.dp.toPx(), mapLabelPaint)
                        }
                    }
                }

                // 5. Draw Equipment Markers (Phân bố thiết bị lưới điện)
                // (filteredEquipments đã được tính sẵn bên ngoài draw scope ở trên)
                filteredEquipments.forEach { eq ->
                    val coords = GeoCoordinates.getEquipmentCoordinates(eq)
                    val screen = geoToScreen(coords.first, coords.second, canvasWidth, canvasHeight, zoomScale, panOffset)
                    val isSelected = selectedEquipment?.id == eq.id

                    val markerColor = when (eq.status) {
                        EquipmentStatus.OPERATIONAL -> Color(0xFF2E7D32)
                        EquipmentStatus.WARNING -> Color(0xFFF57C00)
                        EquipmentStatus.DEFECT -> Color(0xFFD32F2F)
                        else -> Color(0xFF1976D2)
                    }

                    // Selection highlight glow
                    if (isSelected) {
                        drawCircle(
                            color = markerColor.copy(alpha = 0.35f),
                            radius = 28.dp.toPx() * zoomScale.coerceIn(0.8f, 1.6f),
                            center = screen
                        )
                        drawCircle(
                            color = Color(0xFF003366),
                            radius = 24.dp.toPx() * zoomScale.coerceIn(0.8f, 1.6f),
                            center = screen,
                            style = Stroke(width = 2.5.dp.toPx())
                        )
                    }

                    // Base marker outer ring
                    val markerRadius = (if (isSelected) 18.dp else 15.dp).toPx() * zoomScale.coerceIn(0.8f, 1.5f)
                    drawCircle(
                        color = Color.White,
                        radius = markerRadius,
                        center = screen
                    )
                    drawCircle(
                        color = markerColor,
                        radius = markerRadius,
                        center = screen,
                        style = Stroke(width = 3.dp.toPx())
                    )

                    // Inner color circle
                    drawCircle(
                        color = markerColor,
                        radius = markerRadius * 0.65f,
                        center = screen
                    )

                    // Code label below marker
                    drawContext.canvas.nativeCanvas.apply {
                        mapLabelPaint.color = android.graphics.Color.rgb(15, 23, 42)
                        mapLabelPaint.textSize = (10.sp.toPx() * zoomScale.coerceIn(0.8f, 1.2f))
                        drawText(eq.code, screen.x, screen.y - markerRadius - 4.dp.toPx(), mapLabelPaint)
                    }
                }
            }
            }

            // Top Layer Filters Bar
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(MapFilter.entries) { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = {
                            Text(
                                text = filter.displayName,
                                fontSize = 12.sp,
                                fontWeight = if (selectedFilter == filter) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF003366),
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("filter_${filter.name.lowercase()}")
                    )
                }
            }

            // Floating Map Controls
            Column(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 56.dp, end = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Nút chuyển đổi Lớp bản đồ (Street Map -> Satellite View -> Terrain Map)
                FloatingControlBtn(
                    icon = Icons.Default.Layers,
                    contentDesc = "Chuyển đổi lớp bản đồ (Street / Satellite / Terrain)",
                    testTag = "layer_toggle_button",
                    onClick = {
                        cycleMapLayer()
                    }
                )

                // Nút Return to Home: Định vị vị trí hiện tại của cán bộ nếu trong ranh giới, hoặc về trung tâm bản đồ
                FloatingControlBtn(
                    icon = Icons.Default.Home,
                    contentDesc = "Về vị trí ban đầu (Return to Home)",
                    testTag = "return_to_home_button",
                    onClick = {
                        executeReturnToHome()
                    }
                )

                if (isOsmMapMode) {
                    // Nút Dark Mode / High Contrast cho bản đồ
                    FloatingControlBtn(
                        icon = Icons.Default.Nightlight,
                        contentDesc = "Chế độ Ban đêm / Tương phản cao cho bản đồ",
                        testTag = "dark_mode_map_button",
                        onClick = {
                            cycleMapTheme()
                        }
                    )

                    // Nút Bộ lọc loại thiết bị (Recloser, LBS, FCO, v.v.)
                    FloatingControlBtn(
                        icon = Icons.Default.Tune,
                        contentDesc = "Lọc loại thiết bị trên bản đồ",
                        testTag = "equipment_type_filter_button",
                        onClick = {
                            showTypeFilterDialog = true
                        }
                    )

                    // Định vị vị trí hiện tại của cán bộ qua GPS
                    FloatingControlBtn(
                        icon = Icons.Default.MyLocation,
                        contentDesc = "Định vị hiện trường GPS",
                        testTag = "locate_gps_button",
                        onClick = {
                            val fineGranted = ContextCompat.checkSelfPermission(
                                context, Manifest.permission.ACCESS_FINE_LOCATION
                            ) == PackageManager.PERMISSION_GRANTED
                            val coarseGranted = ContextCompat.checkSelfPermission(
                                context, Manifest.permission.ACCESS_COARSE_LOCATION
                            ) == PackageManager.PERMISSION_GRANTED

                            if (fineGranted || coarseGranted) {
                                val locManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
                                val loc = locManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                                    ?: locManager?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                                if (loc != null) {
                                    webViewRef?.evaluateJavascript("setUserGpsLocation(${loc.latitude}, ${loc.longitude});", null)
                                    Toast.makeText(context, "Đã định vị: ${String.format(java.util.Locale.US, "%.5f, %.5f", loc.latitude, loc.longitude)}", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Đang chờ tín hiệu GPS vệ tinh...", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                locationPermissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            }
                        }
                    )
                } else {
                    // Zoom In
                    FloatingControlBtn(
                        icon = Icons.Default.Add,
                        contentDesc = "Phóng to",
                        testTag = "zoom_in_button",
                        onClick = { zoomScale = (zoomScale * 1.3f).coerceAtMost(3.5f) }
                    )
                    // Zoom Out
                    FloatingControlBtn(
                        icon = Icons.Default.Remove,
                        contentDesc = "Thu nhỏ",
                        testTag = "zoom_out_button",
                        onClick = { zoomScale = (zoomScale / 1.3f).coerceAtLeast(0.6f) }
                    )
                    // Recenter
                    FloatingControlBtn(
                        icon = Icons.Default.LocationSearching,
                        contentDesc = "Về trung tâm",
                        testTag = "recenter_canvas_button",
                        onClick = {
                            zoomScale = 1.0f
                            panOffset = Offset.Zero
                        }
                    )
                }
            }

            // Radius Alert (10m) Banner for OPERATIONAL / WARNING equipment
            AnimatedVisibility(
                visible = proximityAlertMessage != null,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 56.dp, start = 12.dp, end = 68.dp)
                    .testTag("proximity_alert_banner")
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFF59E0B)),
                    shape = RoundedCornerShape(10.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Cảnh báo bán kính",
                            tint = Color(0xFFB45309),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = proximityAlertMessage ?: "",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF78350F),
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { proximityAlertMessage = null },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Đóng cảnh báo",
                                tint = Color(0xFF92400E),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // Zoom level indicator in the bottom-right corner of the map view
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 12.dp, bottom = if (selectedEquipment != null || selectedCorridor != null || selectedSubstation != null) 260.dp else 16.dp)
                    .testTag("zoom_level_indicator")
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White.copy(alpha = 0.92f),
                    shadowElevation = 4.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = if (isOsmMapMode) "🔍 Zoom: $currentOsmZoom" else "🔍 Zoom: ${String.format(java.util.Locale.US, "%.1fx", zoomScale)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF003366)
                        )
                    }
                }
            }

            // Bottom Selected Item Inspector Card
            AnimatedVisibility(
                visible = selectedEquipment != null || selectedCorridor != null || selectedSubstation != null,
                enter = slideInVertically { it },
                exit = slideOutVertically { it },
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                // Keep selectedSubstation in sync with latest state
                val currentSelectedSub = selectedSubstation?.let { sel ->
                    substations.find { it.id == sel.id } ?: sel
                }

                currentSelectedSub?.let { sub ->
                    SubstationMapInspectorCard(
                        substation = sub,
                        onClose = { selectedSubstation = null },
                        onEdit = {
                            if (sub.isLocked) {
                                Toast.makeText(context, "Trạm đang bị khóa! Vui lòng mở khóa trước khi chỉnh sửa.", Toast.LENGTH_SHORT).show()
                            } else {
                                substationToEdit = sub
                            }
                        },
                        onToggleLock = {
                            viewModel.toggleLockSubstation(sub.id)
                            Toast.makeText(
                                context,
                                if (sub.isLocked) "Đã mở khóa trạm ${sub.name}" else "Đã khóa trạm ${sub.name}",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        onUpdateGps = {
                            pendingGpsSubstation = sub
                            locationPermissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        }
                    )
                }

                selectedEquipment?.let { eq ->
                    EquipmentMapInspectorCard(
                        equipment = eq,
                        onClose = { selectedEquipment = null },
                        onViewDetail = { onNavigateToEquipment(eq.id) },
                        onExportPdf = { showPdfDialog = true }
                    )
                }

                selectedCorridor?.let { corridor ->
                    CorridorMapInspectorCard(
                        corridor = corridor,
                        onClose = { selectedCorridor = null },
                        onViewCorridors = onNavigateToCorridor
                    )
                }
            }
        }
    }

    // PDF Generator Dialog
    if (showPdfDialog) {
        PdfReportDialog(
            equipments = equipments,
            maintenanceRecords = maintenanceRecords,
            inspections = inspections,
            defects = defects,
            preSelectedEquipmentId = selectedEquipment?.id,
            onDismiss = { showPdfDialog = false }
        )
    }

    // Map Legend Dialog
    if (showLegendDialog) {
        MapLegendDialog(onDismiss = { showLegendDialog = false })
    }

    // Dialog Quản lý danh sách trạm 110kV
    if (showManageSubstationsDialog) {
        ManageSubstationsDialog(
            viewModel = viewModel,
            onDismiss = { showManageSubstationsDialog = false },
            onSelectSubstationToEdit = { sub ->
                substationToEdit = sub
            },
            onAddNewSubstation = {
                substationToEdit = SubstationLocation(
                    id = System.currentTimeMillis(),
                    name = "",
                    code = "",
                    voltage = "110/22kV - 2x63MVA",
                    latitude = 10.3700,
                    longitude = 105.4150,
                    isLocked = false
                )
            }
        )
    }

    // Dialog Lọc Loại Thiết Bị trên Bản đồ (Recloser, LBS, DS, LA, FCO, LBFCO)
    if (showTypeFilterDialog) {
        AlertDialog(
            onDismissRequest = { showTypeFilterDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = Color(0xFF003366),
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Text("Lọc Loại Thiết Bị Trên Bản Đồ", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "Chọn các loại thiết bị hiển thị trên bản đồ để giảm bớt mật độ quan sát:",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    listOf(
                        "RECLOSER" to "Máy cắt tự đóng (Recloser)",
                        "LBS" to "Cầu dao phụ tải (LBS)",
                        "DS" to "Cầu dao cách ly (DS)",
                        "FCO" to "Cầu chì tự rơi (FCO)",
                        "LBFCO" to "Cầu chì tự rơi có tải (LBFCO)",
                        "LA" to "Chống sét van (LA)"
                    ).forEach { (key, label) ->
                        val isChecked = typeFilterMap[key] ?: true
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val newMap = typeFilterMap.toMutableMap()
                                    newMap[key] = !isChecked
                                    typeFilterMap = newMap
                                    webViewRef?.evaluateJavascript(
                                        "setTypeFilterState('$key', ${!isChecked});",
                                        null
                                    )
                                }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checked ->
                                    val newMap = typeFilterMap.toMutableMap()
                                    newMap[key] = checked
                                    typeFilterMap = newMap
                                    webViewRef?.evaluateJavascript(
                                        "setTypeFilterState('$key', $checked);",
                                        null
                                    )
                                },
                                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF003366))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showTypeFilterDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003366))
                ) {
                    Text("Đóng")
                }
            }
        )
    }

    // Dialog Chỉnh sửa / Thêm trạm 110kV
    substationToEdit?.let { sub ->
        EditSubstationDialog(
            substation = sub,
            onDismiss = { substationToEdit = null },
            onSave = { updatedSub ->
                viewModel.saveSubstation(updatedSub)
                substationToEdit = null
                Toast.makeText(context, "Đã lưu thông tin trạm: ${updatedSub.name}", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
fun FloatingControlBtn(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDesc: String,
    testTag: String? = null,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color.White)
            .border(1.dp, Color(0xFFCFD8DC), CircleShape)
            .then(if (testTag != null) Modifier.testTag(testTag) else Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = contentDesc, tint = Color(0xFF003366), modifier = Modifier.size(20.dp))
    }
}

@Composable
fun EquipmentMapInspectorCard(
    equipment: GridEquipment,
    onClose: () -> Unit,
    onViewDetail: () -> Unit,
    onExportPdf: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF003366), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = equipment.code,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .background(Color(0xFFE2E8F0), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = equipment.type.displayName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Đóng")
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = equipment.name,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Vị trí: ${equipment.lineName} - ${equipment.poleNumber}",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
                Text(
                    text = "Điện áp: ${equipment.ratedVoltage} | ${equipment.ratedCurrent}",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            if (equipment.fuseRating.isNotBlank()) {
                Text(
                    text = "Dây chì: ${equipment.fuseType} - ${equipment.fuseRating} (TBA ${equipment.protectedCapacity})",
                    fontSize = 11.sp,
                    color = Color(0xFF00695C),
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onExportPdf,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Xuất PDF TB", fontSize = 12.sp)
                }

                Button(
                    onClick = onViewDetail,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003366)),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Xem Chi Tiết", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun SubstationMapInspectorCard(
    substation: SubstationLocation,
    onClose: () -> Unit,
    onEdit: () -> Unit,
    onToggleLock: () -> Unit,
    onUpdateGps: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (substation.isLocked) Color(0xFFFFFBEB) else Color.White
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            if (substation.isLocked) Color(0xFFF59E0B) else Color(0xFF003366)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Title and Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF003366), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "TRẠM BIẾN ÁP 110KV",
                            color = Color(0xFFFFD600),
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .background(
                                if (substation.isLocked) Color(0xFFFEF3C7) else Color(0xFFDCFCE7),
                                RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (substation.isLocked) "🔒 ĐÃ KHÓA TRẠM" else "🔓 ĐANG MỞ",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (substation.isLocked) Color(0xFFB45309) else Color(0xFF16A34A)
                        )
                    }
                }

                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Đóng")
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = substation.name,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFF003366)
            )

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Mã trạm: ${substation.code.ifBlank { "TBA" }}",
                    fontSize = 12.sp,
                    color = Color.DarkGray
                )
                Text(
                    text = "Cấp điện áp: ${substation.voltage}",
                    fontSize = 12.sp,
                    color = Color.DarkGray
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Tọa độ GPS: ${String.format(java.util.Locale.US, "%.5f", substation.latitude)}, ${String.format(java.util.Locale.US, "%.5f", substation.longitude)}",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF0284C7)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Sửa trạm
                OutlinedButton(
                    onClick = onEdit,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Sửa Tên/Tọa Độ", fontSize = 11.5.sp)
                }

                // Cập nhật GPS máy
                Button(
                    onClick = onUpdateGps,
                    enabled = !substation.isLocked,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                    modifier = Modifier.weight(1.1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Cập Nhật GPS", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                }

                // Khóa trạm
                Button(
                    onClick = onToggleLock,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (substation.isLocked) Color(0xFFF59E0B) else Color(0xFF003366)
                    ),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        if (substation.isLocked) Icons.Default.LockOpen else Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (substation.isLocked) "Mở Khóa" else "Khóa Trạm", fontSize = 11.5.sp)
                }
            }
        }
    }
}

@Composable
fun CorridorMapInspectorCard(
    corridor: SafetyCorridorRecord,
    onClose: () -> Unit,
    onViewCorridors: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFFFB300)),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFFD32F2F), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "VI PHẠM HÀNH LANG AN TOÀN",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = corridor.spanLocation,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFFBF360C)
                    )
                }

                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Đóng")
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = corridor.description,
                fontSize = 12.sp,
                color = Color(0xFF37474F)
            )

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Khoảng cách đo đạc: ${corridor.currentDistance}",
                fontSize = 11.sp,
                color = Color(0xFFD32F2F),
                fontWeight = FontWeight.Bold
            )

            if (corridor.clearanceActionTaken != null) {
                Text(
                    text = "Biện pháp: ${corridor.clearanceActionTaken}",
                    fontSize = 11.sp,
                    color = Color(0xFF00695C)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onViewCorridors,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE65100)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Cập Nhật Biện Pháp Phát Quang / Giải Tỏa", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun MapLegendDialog(onDismiss: () -> Unit) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Chú Giải Bản Đồ Lưới Điện GIS",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFF003366)
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Đóng")
                    }
                }

                Text("1. Tuyến Đường Dây Phân Phối (22kV)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                GeoCoordinates.feederLines.forEach { line ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .width(30.dp)
                                .height(4.dp)
                                .background(Color(line.colorHex), RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(text = "${line.name} (${line.voltage})", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("2. Ký Hiệu Trạng Thái Thiết Bị", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                LegendRow(color = Color(0xFF2E7D32), label = "Vận hành bình thường (Operational)")
                LegendRow(color = Color(0xFFF57C00), label = "Cảnh báo / Sắp đến hạn bảo dưỡng (Warning)")
                LegendRow(color = Color(0xFFD32F2F), label = "Có khiếm khuyết / Quá hạn kiểm tra (Defect)")

                Spacer(modifier = Modifier.height(4.dp))
                Text("3. Vùng Vi Phạm Hành Lang An Toàn", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFD32F2F).copy(alpha = 0.3f))
                            .border(1.5.dp, Color(0xFFD32F2F), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Vùng nguy cơ phóng điện (Cây xanh / Công trình giàn giáo)", fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("4. Trạm Biến Áp 110kV & Tính Năng Khóa Trạm", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF003366))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Trạm 110kV nguồn (chạm để xem, sửa tên/tọa độ, lấy GPS máy)", fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFB45309))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("🔒 Trạm đã khóa (bảo vệ chống xê dịch tọa độ khi cắm mốc)", fontSize = 12.sp)
                }

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003366)),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) {
                    Text("Đã Hiểu")
                }
            }
        }
    }
}

@Composable
fun LegendRow(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(14.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(text = label, fontSize = 12.sp)
    }
}

fun DrawScope.drawGisGrid(width: Float, height: Float, scale: Float, pan: Offset) {
    val gridStep = 60.dp.toPx() * scale.coerceIn(0.7f, 1.8f)
    val startX = (pan.x % gridStep)
    val startY = (pan.y % gridStep)

    var x = startX
    while (x < width) {
        drawLine(
            color = Color(0xFFE2E8F0),
            start = Offset(x, 0f),
            end = Offset(x, height),
            strokeWidth = 1f
        )
        x += gridStep
    }

    var y = startY
    while (y < height) {
        drawLine(
            color = Color(0xFFE2E8F0),
            start = Offset(0f, y),
            end = Offset(width, y),
            strokeWidth = 1f
        )
        y += gridStep
    }
}

fun geoToScreen(
    lat: Double,
    lng: Double,
    screenWidth: Float,
    screenHeight: Float,
    scale: Float,
    pan: Offset
): Offset {
    val normX = (lng - GeoCoordinates.MIN_LNG) / (GeoCoordinates.MAX_LNG - GeoCoordinates.MIN_LNG)
    val normY = 1.0 - (lat - GeoCoordinates.MIN_LAT) / (GeoCoordinates.MAX_LAT - GeoCoordinates.MIN_LAT)

    val basePadding = 40f
    val effectiveWidth = screenWidth - 2 * basePadding
    val effectiveHeight = screenHeight - 2 * basePadding

    val centerX = screenWidth / 2f
    val centerY = screenHeight / 2f

    val rawX = basePadding + normX.toFloat() * effectiveWidth
    val rawY = basePadding + normY.toFloat() * effectiveHeight

    val scaledX = (rawX - centerX) * scale + centerX + pan.x
    val scaledY = (rawY - centerY) * scale + centerY + pan.y

    return Offset(scaledX, scaledY)
}

/**
 * Đóng gói dữ liệu trạm 110kV, thiết bị và hành lang an toàn thành JSON cho map.html
 */
fun buildGridDataJson(
    substations: List<SubstationLocation>,
    equipments: List<GridEquipment>,
    corridors: List<SafetyCorridorRecord>
): String {
    val resultObj = JSONObject()
    
    val subsArray = JSONArray()
    substations.forEach { s ->
        val obj = JSONObject()
        obj.put("id", s.id)
        obj.put("name", s.name)
        obj.put("code", s.code)
        obj.put("voltage", s.voltage)
        obj.put("lat", s.latitude)
        obj.put("lng", s.longitude)
        obj.put("isLocked", s.isLocked)
        subsArray.put(obj)
    }
    
    val equipsArray = JSONArray()
    equipments.forEach { eq ->
        val (lat, lng) = GeoCoordinates.getEquipmentCoordinates(eq)
        val obj = JSONObject()
        obj.put("id", eq.id)
        obj.put("code", eq.code)
        obj.put("name", eq.name)
        obj.put("type", eq.type.name)
        obj.put("line", eq.lineName)
        obj.put("pole", eq.poleNumber)
        obj.put("status", eq.status.name)
        obj.put("lat", lat)
        obj.put("lng", lng)
        equipsArray.put(obj)
    }
    
    val corridorsArray = JSONArray()
    corridors.forEach { c ->
        val (lat, lng) = GeoCoordinates.getCorridorCoordinates(c)
        val obj = JSONObject()
        obj.put("id", c.id)
        obj.put("span", c.spanLocation)
        obj.put("desc", c.description)
        obj.put("distance", c.currentDistance)
        obj.put("status", c.status.name)
        obj.put("lat", lat)
        obj.put("lng", lng)
        corridorsArray.put(obj)
    }
    
    resultObj.put("substations", subsArray)
    resultObj.put("equipments", equipsArray)
    resultObj.put("corridors", corridorsArray)
    
    return resultObj.toString()
}
