package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.GridEquipment
import com.example.ui.components.EquipmentStatusBadge
import com.example.ui.components.EquipmentTypeBadge
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GridAmber
import com.example.ui.theme.SpcNavy
import com.example.ui.theme.SpcYellow
import com.example.ui.theme.StatusNormalGreen
import com.example.ui.viewmodel.GridViewModel
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import java.util.concurrent.Executors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QrScannerScreen(
    viewModel: GridViewModel,
    onNavigateToEquipment: (Long) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val allEquipments by viewModel.allEquipments.collectAsStateWithLifecycle()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    var cameraInstance by remember { mutableStateOf<Camera?>(null) }
    var isTorchOn by remember { mutableStateOf(false) }

    var scannedRawCode by remember { mutableStateOf<String?>(null) }
    var matchedEquipment by remember { mutableStateOf<GridEquipment?>(null) }
    var isNotFound by remember { mutableStateOf(false) }

    var manualCodeInput by remember { mutableStateOf("") }

    // Helper to process QR code result
    fun handleCodeScanned(code: String) {
        val trimmed = code.trim()
        scannedRawCode = trimmed

        // Extract equipment code: handle raw codes like "REC-AG-01", URLs like ".../REC-AG-01", JSON {"code":"REC-AG-01"}
        val candidateCode = extractEquipmentCode(trimmed)

        val found = allEquipments.find { eq ->
            eq.code.equals(candidateCode, ignoreCase = true) ||
            eq.code.equals(trimmed, ignoreCase = true) ||
            eq.poleNumber.equals(trimmed, ignoreCase = true) ||
            trimmed.contains(eq.code, ignoreCase = true)
        }

        if (found != null) {
            matchedEquipment = found
            isNotFound = false
            triggerVibration(context)
        } else {
            matchedEquipment = null
            isNotFound = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "Quét Mã QR Thiết Bị",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                        Text(
                            "Nhận diện nhãn dán hiện trường EVN SPC",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("qr_scanner_back_btn")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Quay lại",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            isTorchOn = !isTorchOn
                            cameraInstance?.cameraControl?.enableTorch(isTorchOn)
                        },
                        modifier = Modifier.testTag("qr_toggle_torch_btn")
                    ) {
                        Icon(
                            if (isTorchOn) Icons.Filled.FlashOn else Icons.Filled.FlashOff,
                            contentDescription = "Bật/Tắt Đèn Flash",
                            tint = if (isTorchOn) SpcYellow else Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SpcNavy
                )
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFF0F172A))
        ) {
            if (hasCameraPermission) {
                // Camera Preview & Analysis
                val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

                AndroidView(
                    factory = { ctx ->
                        val previewView = PreviewView(ctx)
                        val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)

                        cameraProviderFuture.addListener({
                            val cameraProvider = cameraProviderFuture.get()

                            val preview = Preview.Builder().build().also {
                                it.surfaceProvider = previewView.surfaceProvider
                            }

                            val imageAnalysis = ImageAnalysis.Builder()
                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                .build()

                            val multiFormatReader = MultiFormatReader().apply {
                                val hints = mapOf(
                                    DecodeHintType.POSSIBLE_FORMATS to listOf(
                                        BarcodeFormat.QR_CODE,
                                        BarcodeFormat.CODE_128,
                                        BarcodeFormat.DATA_MATRIX
                                    )
                                )
                                setHints(hints)
                            }

                            imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                                if (matchedEquipment == null && !isNotFound) {
                                    val qrCode = decodeQrCode(imageProxy, multiFormatReader)
                                    if (qrCode != null) {
                                        previewView.post {
                                            handleCodeScanned(qrCode)
                                        }
                                    }
                                }
                                imageProxy.close()
                            }

                            try {
                                cameraProvider.unbindAll()
                                val cam = cameraProvider.bindToLifecycle(
                                    lifecycleOwner,
                                    CameraSelector.DEFAULT_BACK_CAMERA,
                                    preview,
                                    imageAnalysis
                                )
                                cameraInstance = cam
                            } catch (exc: Exception) {
                                exc.printStackTrace()
                            }
                        }, ContextCompat.getMainExecutor(ctx))

                        previewView
                    },
                    modifier = Modifier.fillMaxSize()
                )

                DisposableEffect(Unit) {
                    onDispose {
                        // Trước đây chỉ shutdown executor, KHÔNG unbind camera khỏi lifecycleOwner
                        // (thường là Activity trong app single-Activity) — camera preview/analysis
                        // vẫn tiếp tục chạy nền sau khi rời màn hình quét QR (tốn pin, có thể chặn
                        // camera cho màn hình khác), và tác vụ có thể bị gửi tới executor đã shutdown.
                        // Nay hủy bind camera TRƯỚC, rồi mới shutdown executor.
                        try {
                            ProcessCameraProvider.getInstance(context).get().unbindAll()
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                        cameraExecutor.shutdown()
                    }
                }

                // Overlay Viewfinder
                QrScannerOverlay()
            } else {
                // Permission Denied View
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        Icons.Filled.QrCodeScanner,
                        contentDescription = null,
                        tint = SpcYellow,
                        modifier = Modifier.size(72.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        "Cần Quyền Truy Cập Camera",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Ứng dụng cần quyền camera để quét mã QR nhãn dán kỹ thuật trên cột điện và trạm biến áp.",
                        fontSize = 13.sp,
                        color = Color(0xFFCBD5E1),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                        colors = ButtonDefaults.buttonColors(containerColor = SpcNavy),
                        modifier = Modifier.testTag("grant_camera_permission_btn")
                    ) {
                        Text("Cấp Quyền Camera")
                    }
                }
            }

            // Top Instructions
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp),
                color = Color.Black.copy(alpha = 0.75f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF475569))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.QrCode,
                        contentDescription = null,
                        tint = SpcYellow,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        "Hướng camera vào tem QR gắn trên vỏ Recloser, LBS, DS hoặc tủ điều khiển",
                        fontSize = 12.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Bottom Section: Quick Test Samples & Scanned Result Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(Color(0xFF0F172A).copy(alpha = 0.92f))
                    .padding(16.dp)
            ) {
                // Preset Quick Tags for Easy Testing in Emulator
                Text(
                    "Mã thiết bị mẫu (Nhấn để mô phỏng quét nhanh):",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8),
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val sampleCodes = listOf("REC-AG-01", "LBS-AG-02", "DS-AG-01", "LA-AG-03", "FCO-AG-04", "LBFCO-AG-05")
                    items(sampleCodes) { code ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF1E293B))
                                .border(1.dp, Color(0xFF334155), RoundedCornerShape(6.dp))
                                .clickable { handleCodeScanned(code) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("sample_qr_$code")
                        ) {
                            Text(
                                text = code,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = SpcYellow
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Manual search fallback input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = manualCodeInput,
                        onValueChange = { manualCodeInput = it },
                        placeholder = { Text("Nhập thủ công mã cột / thiết bị", fontSize = 12.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = Color(0xFF475569),
                            focusedContainerColor = Color(0xFF1E293B),
                            unfocusedContainerColor = Color(0xFF1E293B)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("manual_qr_input")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (manualCodeInput.isNotBlank()) {
                                handleCodeScanned(manualCodeInput)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(50.dp)
                            .testTag("manual_qr_search_btn")
                    ) {
                        Icon(Icons.Filled.Search, contentDescription = "Tìm kiếm")
                    }
                }

                // Matched Equipment Result Card
                if (matchedEquipment != null) {
                    val eq = matchedEquipment!!
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(2.dp, StatusNormalGreen, RoundedCornerShape(12.dp))
                            .testTag("qr_result_matched_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Filled.CheckCircle,
                                        contentDescription = null,
                                        tint = StatusNormalGreen,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        eq.code,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    EquipmentTypeBadge(type = eq.type)
                                    EquipmentStatusBadge(status = eq.status)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Tuyến: ${eq.lineName} | Vị trí: ${eq.poleNumber}",
                                fontSize = 13.sp,
                                color = Color(0xFFE2E8F0),
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                "Thông số: ${eq.ratedVoltage} - ${eq.ratedCurrent} | Hãng: ${eq.manufacturer}",
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8)
                            )
                            Text(
                                "Lần bảo dưỡng gần nhất: ${formatTimestamp(eq.lastMaintenanceDate)} | Kiểm tra kế tiếp: ${formatTimestamp(eq.nextInspectionDate)}",
                                fontSize = 11.sp,
                                color = Color(0xFFCBD5E1)
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        matchedEquipment = null
                                        scannedRawCode = null
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                                ) {
                                    Text("Quét Lại", fontSize = 12.sp)
                                }
                                Button(
                                    onClick = {
                                        onNavigateToEquipment(eq.id)
                                    },
                                    modifier = Modifier
                                        .weight(2f)
                                        .testTag("open_equipment_from_qr_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                                ) {
                                    Text("Mở Hồ Sơ & Lịch Sử", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else if (isNotFound && scannedRawCode != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.5.dp, Color(0xFFEF4444), RoundedCornerShape(12.dp)),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.Warning,
                                    contentDescription = null,
                                    tint = Color(0xFFEF4444),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    "Không tìm thấy thiết bị: $scannedRawCode",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Mã QR đã quét chưa khớp với thiết bị nào trong cơ sở dữ liệu lưới điện An Giang.",
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    isNotFound = false
                                    scannedRawCode = null
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SpcNavy),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Thử Quét Lại")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QrScannerOverlay() {
    val infiniteTransition = rememberInfiniteTransition(label = "scanner_anim")
    val laserPosition by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_pos"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val scanBoxSize = size.width * 0.65f
        val left = (size.width - scanBoxSize) / 2
        val top = (size.height - scanBoxSize) / 2 - 40.dp.toPx()

        // Outer darkened area
        drawRect(
            color = Color.Black.copy(alpha = 0.5f)
        )

        // Clear center transparent window
        drawRoundRect(
            color = Color.Transparent,
            topLeft = Offset(left, top),
            size = Size(scanBoxSize, scanBoxSize),
            cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx()),
            blendMode = BlendMode.Clear
        )

        // Targeting Corner Accents
        val cornerLength = 32.dp.toPx()
        val cornerStroke = 4.dp.toPx()
        val cornerColor = Color(0xFFE89300)

        // Top-Left
        drawLine(cornerColor, Offset(left, top), Offset(left + cornerLength, top), cornerStroke)
        drawLine(cornerColor, Offset(left, top), Offset(left, top + cornerLength), cornerStroke)

        // Top-Right
        drawLine(cornerColor, Offset(left + scanBoxSize, top), Offset(left + scanBoxSize - cornerLength, top), cornerStroke)
        drawLine(cornerColor, Offset(left + scanBoxSize, top), Offset(left + scanBoxSize, top + cornerLength), cornerStroke)

        // Bottom-Left
        drawLine(cornerColor, Offset(left, top + scanBoxSize), Offset(left + cornerLength, top + scanBoxSize), cornerStroke)
        drawLine(cornerColor, Offset(left, top + scanBoxSize), Offset(left, top + scanBoxSize - cornerLength), cornerStroke)

        // Bottom-Right
        drawLine(cornerColor, Offset(left + scanBoxSize, top + scanBoxSize), Offset(left + scanBoxSize - cornerLength, top + scanBoxSize), cornerStroke)
        drawLine(cornerColor, Offset(left + scanBoxSize, top + scanBoxSize), Offset(left + scanBoxSize, top + scanBoxSize - cornerLength), cornerStroke)

        // Moving Laser Line
        val laserY = top + scanBoxSize * laserPosition
        drawLine(
            color = Color(0xFF00D2FF),
            start = Offset(left + 8.dp.toPx(), laserY),
            end = Offset(left + scanBoxSize - 8.dp.toPx(), laserY),
            strokeWidth = 3.dp.toPx()
        )
    }
}

private fun decodeQrCode(imageProxy: ImageProxy, reader: MultiFormatReader): String? {
    return try {
        val buffer = imageProxy.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)

        val width = imageProxy.width
        val height = imageProxy.height

        val source = PlanarYUVLuminanceSource(
            bytes, width, height,
            0, 0, width, height,
            false
        )
        val bitmap = BinaryBitmap(HybridBinarizer(source))
        val result = reader.decodeWithState(bitmap)
        result.text
    } catch (e: Exception) {
        null
    } finally {
        reader.reset()
    }
}

private fun extractEquipmentCode(raw: String): String {
    // Check if URL pattern
    if (raw.contains("/")) {
        val lastSegment = raw.substringAfterLast("/")
        if (lastSegment.isNotBlank()) return lastSegment.substringBefore("?")
    }
    // Check if JSON pattern
    if (raw.contains("\"code\"")) {
        val match = Regex("\"code\"\\s*:\\s*\"([^\"]+)\"").find(raw)
        if (match != null) return match.groupValues[1]
    }
    return raw
}

private fun triggerVibration(context: Context) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator?.vibrate(
                VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        } else {
            @Suppress("DEPRECATION")
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            @Suppress("DEPRECATION")
            vibrator?.vibrate(120)
        }
    } catch (e: Exception) {
        // Ignore vibration failure
    }
}
