package com.example.ui.dialogs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.GridEquipment
import com.example.data.model.PeriodicInspection

@Composable
fun AddInspectionDialog(
    equipment: GridEquipment,
    onDismiss: () -> Unit,
    onSave: (PeriodicInspection) -> Unit
) {
    var inspectorName by remember { mutableStateOf("Nguyễn Văn A - Tổ QLVH") }
    var inspectionType by remember { mutableStateOf("Kiểm tra định kỳ tháng & Đo phát nhiệt") }
    var temperatureJoints by remember { mutableStateOf("Mối nối Pha A: 38°C, Pha B: 40°C, Pha C: 39°C") }
    var insulatorCondition by remember { mutableStateOf("Sứ Polymer sạch, không nứt mẻ") }
    var groundingCondition by remember { mutableStateOf("Tiếp địa tốt, dây đồng không đứt rỉ") }
    var sf6OrOilStatus by remember { mutableStateOf("Bình thường, áp lực trong ngưỡng quy định") }
    var resultStatus by remember { mutableStateOf("Đạt yêu cầu") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Phiếu Kiểm Tra Định Kỳ - ${equipment.code}", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = inspectorName,
                    onValueChange = { inspectorName = it },
                    label = { Text("Người / Tổ kiểm tra") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = inspectionType,
                    onValueChange = { inspectionType = it },
                    label = { Text("Loại hình kiểm tra") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = temperatureJoints,
                    onValueChange = { temperatureJoints = it },
                    label = { Text("Nhiệt độ mối nối / Tiếp xúc (Camera nhiệt)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = insulatorCondition,
                    onValueChange = { insulatorCondition = it },
                    label = { Text("Tình trạng sứ cách điện") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = groundingCondition,
                    onValueChange = { groundingCondition = it },
                    label = { Text("Hệ thống tiếp địa an toàn") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = sf6OrOilStatus,
                    onValueChange = { sf6OrOilStatus = it },
                    label = { Text("Áp lực khí SF6 / Môi chất / Cơ cấu") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = resultStatus,
                    onValueChange = { resultStatus = it },
                    label = { Text("Kết quả (Đạt yêu cầu / Có khiếm khuyết)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Ghi chú chi tiết đợt kiểm tra") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (inspectorName.isNotBlank()) {
                        val record = PeriodicInspection(
                            equipmentId = equipment.id,
                            equipmentCode = equipment.code,
                            inspectionDate = System.currentTimeMillis(),
                            inspectorName = inspectorName,
                            inspectionType = inspectionType,
                            temperatureJoints = temperatureJoints,
                            insulatorCondition = insulatorCondition,
                            groundingCondition = groundingCondition,
                            sf6OrOilStatus = sf6OrOilStatus,
                            resultStatus = resultStatus,
                            notes = notes
                        )
                        onSave(record)
                    }
                },
                modifier = Modifier.testTag("save_inspection_btn")
            ) {
                Text("Lưu kết quả")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}
