package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dangerous
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.widget.Toast
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.ui.platform.LocalContext
import com.example.data.model.AlertSeverity
import com.example.data.model.CorridorStatus
import com.example.data.model.DefectRecord
import com.example.data.model.DefectSeverity
import com.example.data.model.DefectStatus
import com.example.data.model.EquipmentStatus
import com.example.data.model.EquipmentType
import com.example.data.model.GridAlert
import com.example.data.model.GridEquipment
import com.example.ui.components.D3EquipmentChart
import com.example.ui.components.EquipmentTypeBadge
import com.example.ui.dialogs.BackupHistoryDialog
import com.example.ui.dialogs.InspectorSettingsDialog
import com.example.ui.dialogs.PdfReportDialog
import com.example.ui.viewmodel.GridViewModel
import com.example.util.GridNotificationManager

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    viewModel: GridViewModel,
    onNavigateToEquipment: (Long) -> Unit,
    onNavigateToMap: () -> Unit,
    onNavigateToDefects: () -> Unit,
    onNavigateToTasks: () -> Unit = {},
    onNavigateToCorridor: () -> Unit,
    onNavigateToReports: () -> Unit = {},
    onNavigateToQrScanner: () -> Unit = {},
    isOutdoorMode: Boolean = false,
    onToggleOutdoorMode: () -> Unit = {}
) {
    val context = LocalContext.current
    val stats by viewModel.gridStats.collectAsStateWithLifecycle()
    val equipments by viewModel.equipments.collectAsStateWithLifecycle()
    val maintenanceRecords by viewModel.maintenanceRecords.collectAsStateWithLifecycle()
    val inspections by viewModel.inspections.collectAsStateWithLifecycle()
    val defects by viewModel.defects.collectAsStateWithLifecycle()
    val corridorRecords by viewModel.corridorRecords.collectAsStateWithLifecycle()
    val automatedAlerts by viewModel.automatedAlerts.collectAsStateWithLifecycle()
    val substations by viewModel.substations.collectAsStateWithLifecycle()

    var showPdfDialog by remember { mutableStateOf(false) }
    var showInspectorSettingsDialog by remember { mutableStateOf(false) }
    var showBackupHistoryDialog by remember { mutableStateOf(false) }
    var selectedEquipmentForPdf by remember { mutableStateOf<Long?>(null) }

    val lastBackupTimestamp by viewModel.lastBackupTimestamp.collectAsStateWithLifecycle()
    val lastAutoBackupTimestamp by viewModel.lastAutoBackupTimestamp.collectAsStateWithLifecycle()
    val backupDateFormat = remember { java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()) }

    val now = System.currentTimeMillis()
    val oneDayMs = 24 * 3600 * 1000L

    // Pending Maintenance Devices: Overdue OR due within 14 days
    val pendingMaintenanceEquipments = equipments.filter { eq ->
        val maintenanceDueSoon = eq.nextMaintenanceDate in 1..(now + 14 * oneDayMs)
        val maintenanceOverdue = eq.nextMaintenanceDate in 1..now
        val inspectionDueSoon = eq.nextInspectionDate in 1..(now + 3 * oneDayMs)
        val inspectionOverdue = eq.nextInspectionDate in 1..now
        val hasWarning = eq.status == EquipmentStatus.WARNING
        maintenanceDueSoon || maintenanceOverdue || inspectionDueSoon || inspectionOverdue || hasWarning
    }

    // Critical or Major Defects
    val criticalDefects = defects.filter {
        (it.status == DefectStatus.PENDING || it.status == DefectStatus.IN_PROGRESS) &&
                (it.severity == DefectSeverity.CRITICAL || it.severity == DefectSeverity.MAJOR)
    }

    // Active Corridor Violations
    val activeCorridorViolations = corridorRecords.filter {
        it.status == CorridorStatus.VIOLATION_EXISTING || it.status == CorridorStatus.PROCESSING
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Bảng Điều Khiển Lưới Điện",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = Color.White
                        )
                        Text(
                            text = "SPC • Cty Điện lực An Giang (PCAG)",
                            fontSize = 11.sp,
                            color = Color(0xFFFFF9C4)
                        )
                    }
                },
                actions = {
                    // QR Scanner Button
                    IconButton(
                        onClick = onNavigateToQrScanner,
                        modifier = Modifier.testTag("dashboard_qr_scanner_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "Quét mã QR nhãn dán thiết bị",
                            tint = Color(0xFFFFD54F)
                        )
                    }

                    // Push Notification Alert Check Trigger
                    IconButton(
                        onClick = {
                            val count = GridNotificationManager.checkAndTriggerRealtimeAlerts(context, equipments)
                            Toast.makeText(
                                context,
                                if (count > 0) "Đã gửi $count cảnh báo đẩy thiết bị đến hạn kiểm tra!" else "Tất cả thiết bị đều an toàn, chưa đến hạn kiểm tra!",
                                Toast.LENGTH_LONG
                            ).show()
                        },
                        modifier = Modifier.testTag("dashboard_trigger_notification_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Kích hoạt kiểm tra cảnh báo đẩy",
                            tint = Color.White
                        )
                    }

                    // Outdoor Sunlight Mode Toggle
                    IconButton(
                        onClick = onToggleOutdoorMode,
                        modifier = Modifier.testTag("dashboard_outdoor_mode_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.WbSunny,
                            contentDescription = "Chế độ ánh sáng ngoài trời",
                            tint = if (isOutdoorMode) Color(0xFFFFD54F) else Color.White
                        )
                    }

                    // Inspector Settings
                    IconButton(
                        onClick = { showInspectorSettingsDialog = true },
                        modifier = Modifier.testTag("dashboard_inspector_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ManageAccounts,
                            contentDescription = "Cán bộ & Dữ liệu",
                            tint = Color.White
                        )
                    }

                    // PDF Export Button
                    Button(
                        onClick = {
                            selectedEquipmentForPdf = null
                            showPdfDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .testTag("dashboard_export_pdf_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF003366))
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. KPI Metric Summary Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Total Devices Card
                KpiCard(
                    title = "Tổng Thiết Bị",
                    value = "${stats.totalEquipments}",
                    subtitle = "Trên 3 xuất tuyến",
                    icon = Icons.Default.FlashOn,
                    color = Color(0xFF0066CC),
                    modifier = Modifier.weight(1f)
                )

                // Operational Card
                KpiCard(
                    title = "Vận Hành An Toàn",
                    value = "${stats.operationalEquipments}",
                    subtitle = "${if (stats.totalEquipments > 0) (stats.operationalEquipments * 100 / stats.totalEquipments) else 0}% đạt chuẩn",
                    icon = Icons.Default.CheckCircle,
                    color = Color(0xFF2E7D32),
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Pending Maintenance Card (HIGH PRIORITY)
                KpiCard(
                    title = "Cần Bảo Dưỡng",
                    value = "${pendingMaintenanceEquipments.size}",
                    subtitle = "Sắp hoặc quá hạn",
                    icon = Icons.Default.Build,
                    color = Color(0xFFE65100),
                    highlight = pendingMaintenanceEquipments.isNotEmpty(),
                    modifier = Modifier.weight(1f)
                )

                // Critical Defects Card (HIGH PRIORITY)
                KpiCard(
                    title = "Khiếm Khuyết Nguy Hiểm",
                    value = "${criticalDefects.size}",
                    subtitle = "Cần xử lý ngay",
                    icon = Icons.Default.Dangerous,
                    color = Color(0xFFC62828),
                    highlight = criticalDefects.isNotEmpty(),
                    modifier = Modifier.weight(1f)
                )
            }

            // D3.js Equipment Statistical Chart Module (Recloser, LBS, DS, LA, FCO, LBFCO)
            D3EquipmentChart(
                equipments = equipments,
                modifier = Modifier.fillMaxWidth()
            )

            // Sổ Phân Công Công Việc & Báo Cáo Cá Nhân (Thống kê tiếp địa mất, biển báo...)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToTasks() }
                    .testTag("dashboard_assigned_tasks_banner"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFFFB300))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFEF6C00)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Assignment, contentDescription = null, tint = Color.White)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Công Việc Phân Công Báo Cáo",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFFE65100)
                                )
                                Text(
                                    text = "Sổ phân công cá nhân • Báo cáo chuyên đề gửi QLVH",
                                    fontSize = 11.sp,
                                    color = Color(0xFFBF360C)
                                )
                            }
                        }
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Color(0xFFE65100)
                        )
                    }

                    // Tóm tắt số liệu
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color.White)
                                .padding(vertical = 6.dp, horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${stats.activeAssignedTasks}", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFFE65100))
                                Text("Đang thống kê", fontSize = 10.sp, color = Color.Gray)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color.White)
                                .padding(vertical = 6.dp, horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${stats.totalRecordedMissingItems}", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFFC62828))
                                Text("Vị trí mất/hỏng", fontSize = 10.sp, color = Color.Gray)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color.White)
                                .padding(vertical = 6.dp, horizontal = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${stats.submittedAssignedTasks}", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFF2E7D32))
                                Text("Đã gửi QLVH", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "⚡ Ví dụ: Thống kê tiếp địa bị mất, biển báo an toàn...",
                            fontSize = 11.sp,
                            color = Color(0xFF5D4037),
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Mở sổ việc →",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE65100)
                        )
                    }
                }
            }

            // Quick Map Banner Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToMap() }
                    .testTag("dashboard_map_banner"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA5D6A7))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF2E7D32)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Map, contentDescription = null, tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Bản Đồ Phân Bố Lưới Điện GIS",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF1B5E20)
                            )
                            Text(
                                text = "${substations.size} trạm 110kV (${substations.count { it.isLocked }} đã khóa) • ${equipments.size} thiết bị • ${activeCorridorViolations.size} điểm vi phạm",
                                fontSize = 11.sp,
                                color = Color(0xFF388E3C)
                            )
                        }
                    }
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = Color(0xFF2E7D32)
                    )
                }
            }

            // 1b. Automated System Alerts Card
            val criticalAlertCount = automatedAlerts.count { it.severity == AlertSeverity.CRITICAL }
            val warningAlertCount = automatedAlerts.count { it.severity == AlertSeverity.WARNING }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_automated_alerts_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (criticalAlertCount > 0) Color(0xFFFFF1F2) else Color(0xFFFFFBEB)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (criticalAlertCount > 0) Color(0xFFFECDD3) else Color(0xFFFDE68A)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(if (criticalAlertCount > 0) Color(0xFFE11D48) else Color(0xFFD97706)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Cảnh Báo Tự Động Thiết Bị (${automatedAlerts.size})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (criticalAlertCount > 0) Color(0xFF9F1239) else Color(0xFF92400E)
                                )
                                Text(
                                    text = "$criticalAlertCount nguy cấp • $warningAlertCount cảnh báo vận hành",
                                    fontSize = 11.sp,
                                    color = if (criticalAlertCount > 0) Color(0xFFBE123C) else Color(0xFFB45309),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        TextButton(onClick = onNavigateToReports) {
                            Text(
                                "Xem tất cả",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (criticalAlertCount > 0) Color(0xFFE11D48) else Color(0xFFD97706)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (automatedAlerts.isEmpty()) {
                        Text(
                            text = "Toàn bộ thiết bị Recloser, LBS, DS, LA, FCO, LBFCO đang hoạt động bình thường và đúng chu kỳ kiểm tra.",
                            fontSize = 12.sp,
                            color = Color(0xFF047857),
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        val topAlerts = automatedAlerts.take(3)
                        topAlerts.forEach { alert ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable { onNavigateToEquipment(alert.equipmentId) },
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (alert.severity == AlertSeverity.CRITICAL) Color(0xFFFECDD3) else Color(0xFFFED7AA)
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        EquipmentTypeBadge(alert.equipmentType)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = alert.equipmentCode,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = Color(0xFF0F172A)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = alert.title,
                                                    fontWeight = FontWeight.SemiBold,
                                                    fontSize = 11.sp,
                                                    color = if (alert.severity == AlertSeverity.CRITICAL) Color(0xFFBE123C) else Color(0xFFB45309)
                                                )
                                            }
                                            Text(
                                                text = alert.description,
                                                fontSize = 11.sp,
                                                color = Color(0xFF334155),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    Icon(
                                        Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = "Xem",
                                        tint = Color(0xFF64748B),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 2. Visual Status Breakdown: Animated Donut Chart
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Tỷ Lệ Trạng Thái Thiết Bị Lưới Điện",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF003366)
                    )
                    Text(
                        text = "Phân loại trạng thái kỹ thuật vận hành thời gian thực",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Donut Chart Canvas
                        Box(
                            modifier = Modifier
                                .size(130.dp)
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            StatusDonutChart(
                                operationalCount = stats.operationalEquipments,
                                warningCount = stats.warningEquipments,
                                defectCount = stats.defectEquipments
                            )
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${stats.totalEquipments}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 20.sp,
                                    color = Color(0xFF003366)
                                )
                                Text(
                                    text = "Thiết bị",
                                    fontSize = 9.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        // Chart Legends
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ChartLegendItem(
                                label = "Bình thường",
                                count = stats.operationalEquipments,
                                total = stats.totalEquipments,
                                color = Color(0xFF2E7D32)
                            )
                            ChartLegendItem(
                                label = "Cảnh báo / Sắp đến hạn",
                                count = stats.warningEquipments,
                                total = stats.totalEquipments,
                                color = Color(0xFFF57C00)
                            )
                            ChartLegendItem(
                                label = "Có khiếm khuyết",
                                count = stats.defectEquipments,
                                total = stats.totalEquipments,
                                color = Color(0xFFD32F2F)
                            )
                        }
                    }
                }
            }

            // 3. Equipment Breakdown by Type (Horizontal Bars)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Phân Bố Chủng Loại Thiết Bị",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF003366)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val typesWithCount = EquipmentType.entries.map { type ->
                        type to equipments.count { it.type == type }
                    }

                    typesWithCount.forEach { (type, count) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = type.displayName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.width(105.dp)
                            )

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(14.dp)
                                    .clip(RoundedCornerShape(7.dp))
                                    .background(Color(0xFFECEFF1))
                            ) {
                                val ratio = if (equipments.isNotEmpty()) count.toFloat() / equipments.size else 0f
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(ratio)
                                        .height(14.dp)
                                        .clip(RoundedCornerShape(7.dp))
                                        .background(
                                            when (type) {
                                                EquipmentType.RECLOSER -> Color(0xFF1565C0)
                                                EquipmentType.LBS -> Color(0xFF00838F)
                                                EquipmentType.DS -> Color(0xFF4527A0)
                                                EquipmentType.LA -> Color(0xFFEF6C00)
                                                EquipmentType.FCO -> Color(0xFF2E7D32)
                                                EquipmentType.LBFCO -> Color(0xFF00695C)
                                                else -> Color(0xFF1565C0)
                                            }
                                        )
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "$count TB",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF37474F),
                                modifier = Modifier.width(36.dp),
                                textAlign = TextAlign.End
                            )
                        }
                    }
                }
            }

            // 4. HIGHLIGHT SECTION: Thiết Bị Cần Bảo Dưỡng (Pending Maintenance)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFFFB300))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE65100)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.NotificationsActive,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Thiết Bị Cần Bảo Dưỡng (${pendingMaintenanceEquipments.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color(0xFFE65100)
                            )
                        }

                        Text(
                            text = "Đến hạn / Quá hạn",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFBF360C)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (pendingMaintenanceEquipments.isEmpty()) {
                        Text(
                            text = "Tất cả thiết bị đều đang trong chu kỳ bảo dưỡng an toàn.",
                            fontSize = 12.sp,
                            color = Color(0xFF795548)
                        )
                    } else {
                        for (eq in pendingMaintenanceEquipments) {
                            val isInspectionOverdue = eq.nextInspectionDate in 1..now
                            val isMaintenanceOverdue = eq.nextMaintenanceDate in 1..now
                            val daysToMaintenance = ((eq.nextMaintenanceDate - now) / oneDayMs).toInt()
                            val daysOverdue = ((now - eq.nextInspectionDate) / oneDayMs).toInt()

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFD54F))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "[${eq.code}] ${eq.name}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color(0xFF0D47A1),
                                            modifier = Modifier.weight(1f)
                                        )

                                        if (isInspectionOverdue) {
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFFFFEBEE), RoundedCornerShape(4.dp))
                                                    .border(1.dp, Color(0xFFE53935), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = "QUÁ HẠN KIỂM TRA ${daysOverdue.coerceAtLeast(1)} NGÀY",
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFFC62828)
                                                )
                                            }
                                        } else {
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFFFFF3E0), RoundedCornerShape(4.dp))
                                                    .border(1.dp, Color(0xFFFB8C00), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = "BẢO DƯỠNG TRONG $daysToMaintenance NGÀY",
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFFE65100)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Vị trí: ${eq.lineName} - ${eq.poleNumber} | Trạm: ${eq.substation}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF616161)
                                    )
                                    if (eq.notes.isNotBlank()) {
                                        Text(
                                            text = "Ghi chú: ${eq.notes}",
                                            fontSize = 11.sp,
                                            color = Color(0xFFBF360C),
                                            fontWeight = FontWeight.Medium
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextButton(
                                            onClick = {
                                                selectedEquipmentForPdf = eq.id
                                                showPdfDialog = true
                                            }
                                        ) {
                                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Xuất PDF TB", fontSize = 11.sp)
                                        }

                                        FilledTonalButton(
                                            onClick = { onNavigateToEquipment(eq.id) },
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Text("Xem Chi Tiết", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 5. HIGHLIGHT SECTION: Khiếm Khuyết Nguy Hiểm & Khẩn Cấp (Critical Defects)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFE53935))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFC62828)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Dangerous,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Khiếm Khuyết Khẩn Cấp (${criticalDefects.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color(0xFFC62828)
                            )
                        }

                        TextButton(onClick = onNavigateToDefects) {
                            Text("Xem tất cả", fontSize = 11.sp, color = Color(0xFFC62828))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (criticalDefects.isEmpty()) {
                        Text(
                            text = "Không có khiếm khuyết khẩn cấp đang tồn đọng trên lưới.",
                            fontSize = 12.sp,
                            color = Color(0xFF4E342E)
                        )
                    } else {
                        for (defect in criticalDefects) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF9A9A))
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = defect.title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color(0xFFB71C1C),
                                            modifier = Modifier.weight(1f)
                                        )

                                        Box(
                                            modifier = Modifier
                                                .background(Color(0xFFC62828), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = defect.severity.label,
                                                fontSize = 9.sp,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = defect.description,
                                        fontSize = 11.sp,
                                        color = Color(0xFF424242)
                                    )

                                    if (defect.actionPlan != null) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Phương án xử lý: ${defect.actionPlan}",
                                            fontSize = 11.sp,
                                            color = Color(0xFF004D40),
                                            fontWeight = FontWeight.Medium
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Báo cáo bởi: ${defect.reportedBy}",
                                            fontSize = 10.sp,
                                            color = Color.Gray
                                        )

                                        Button(
                                            onClick = onNavigateToDefects,
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                                            modifier = Modifier.height(30.dp)
                                        ) {
                                            Text("Xử Lý Sự Cố", fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 6. Corridor Hazards Warning Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToCorridor() },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFB74D))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE65100)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Hành Lang An Toàn Lưới Điện",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFFE65100)
                            )
                            Text(
                                text = "${activeCorridorViolations.size} điểm vi phạm đang giải tỏa (Cây xanh & Nhà cửa)",
                                fontSize = 11.sp,
                                color = Color(0xFFBF360C)
                            )
                        }
                    }
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = Color(0xFFE65100)
                    )
                }
            }

            // 7. Data Backup & Auto-Save History Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showBackupHistoryDialog = true }
                    .testTag("dashboard_backup_history_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF86EFAC)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF16A34A)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Assessment,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Nhật Ký Sao Lưu & Trạng Thái CSDL",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFF166534)
                                )
                                Text(
                                    text = "Lịch sử Export / Import & Tự động lưu",
                                    fontSize = 11.sp,
                                    color = Color(0xFF15803D)
                                )
                            }
                        }

                        TextButton(onClick = { showBackupHistoryDialog = true }) {
                            Text(
                                "Xem sổ ký →",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF16A34A)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White)
                                .border(1.dp, Color(0xFFBBF7D0), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text("Lần sao lưu gần nhất", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (lastBackupTimestamp > 0L) backupDateFormat.format(java.util.Date(lastBackupTimestamp)) else "Chưa ghi nhận",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (lastBackupTimestamp > 0L) Color(0xFF166534) else Color.Gray
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White)
                                .border(1.dp, Color(0xFFBBF7D0), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text("Tự động lưu (Auto-Save)", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (lastAutoBackupTimestamp > 0L) backupDateFormat.format(java.util.Date(lastAutoBackupTimestamp)) else "Đang kích hoạt",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF15803D)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showBackupHistoryDialog) {
        BackupHistoryDialog(
            viewModel = viewModel,
            onDismiss = { showBackupHistoryDialog = false }
        )
    }

    if (showInspectorSettingsDialog) {
        InspectorSettingsDialog(
            viewModel = viewModel,
            onOpenPdfReport = {
                showInspectorSettingsDialog = false
                selectedEquipmentForPdf = null
                showPdfDialog = true
            },
            onDismiss = { showInspectorSettingsDialog = false }
        )
    }

    if (showPdfDialog) {
        PdfReportDialog(
            equipments = equipments,
            maintenanceRecords = maintenanceRecords,
            inspections = inspections,
            defects = defects,
            corridors = corridorRecords,
            preSelectedEquipmentId = selectedEquipmentForPdf,
            onDismiss = {
                showPdfDialog = false
                selectedEquipmentForPdf = null
            }
        )
    }
}

@Composable
fun KpiCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    highlight: Boolean = false
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (highlight) color.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            if (highlight) 1.5.dp else 1.dp,
            if (highlight) color else Color(0xFFCBD5E1)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (highlight) color else Color(0xFF1E293B)
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (highlight) color else Color(0xFF003366)
            )

            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF475569),
                maxLines = 1
            )
        }
    }
}

@Composable
fun StatusDonutChart(
    operationalCount: Int,
    warningCount: Int,
    defectCount: Int
) {
    val total = (operationalCount + warningCount + defectCount).coerceAtLeast(1)
    val opAngle = (operationalCount.toFloat() / total) * 360f
    val warnAngle = (warningCount.toFloat() / total) * 360f
    val defAngle = (defectCount.toFloat() / total) * 360f

    val animProgress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        animProgress.animateTo(1f, animationSpec = tween(700))
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidth = 18.dp.toPx()
        val diameter = size.minDimension - strokeWidth
        val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
        val arcSize = Size(diameter, diameter)

        var startAngle = -90f

        // Draw Operational segment (Green)
        if (opAngle > 0) {
            val sweep = opAngle * animProgress.value
            drawArc(
                color = Color(0xFF2E7D32),
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            startAngle += opAngle
        }

        // Draw Warning segment (Orange)
        if (warnAngle > 0) {
            val sweep = warnAngle * animProgress.value
            drawArc(
                color = Color(0xFFF57C00),
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            startAngle += warnAngle
        }

        // Draw Defect segment (Red)
        if (defAngle > 0) {
            val sweep = defAngle * animProgress.value
            drawArc(
                color = Color(0xFFD32F2F),
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
fun ChartLegendItem(
    label: String,
    count: Int,
    total: Int,
    color: Color
) {
    val percent = if (total > 0) (count * 100 / total) else 0
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Text(
            text = "$count ($percent%)",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}
