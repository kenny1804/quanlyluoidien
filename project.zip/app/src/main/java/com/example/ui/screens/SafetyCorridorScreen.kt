package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.HomeWork
import androidx.compose.material.icons.filled.NaturePeople
import androidx.compose.material.icons.filled.Park
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CorridorStatus
import com.example.data.model.HazardRiskLevel
import com.example.data.model.HazardType
import com.example.data.model.SafetyCorridorRecord
import com.example.ui.components.CorridorStatusBadge
import com.example.ui.components.HazardTypeBadge
import com.example.ui.components.formatDateTime
import com.example.ui.dialogs.AddCorridorDialog
import com.example.ui.dialogs.CorridorPdfReportDialog
import com.example.ui.dialogs.ResolveCorridorDialog
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GridAmber
import com.example.ui.theme.SpcNavy
import com.example.ui.theme.StatusDangerRed
import com.example.ui.theme.StatusNormalGreen
import com.example.ui.theme.StatusWarningAmber
import com.example.ui.theme.SubstationCyan
import com.example.ui.viewmodel.GridViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafetyCorridorScreen(
    viewModel: GridViewModel,
    modifier: Modifier = Modifier
) {
    val corridors by viewModel.allCorridors.collectAsStateWithLifecycle()

    var typeFilter by remember { mutableStateOf<HazardType?>(null) } // null = Tất cả
    var statusFilter by remember { mutableStateOf<CorridorStatus?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var resolvingCorridor by remember { mutableStateOf<SafetyCorridorRecord?>(null) }
    var reportingCorridor by remember { mutableStateOf<SafetyCorridorRecord?>(null) }

    val filteredCorridors = corridors.filter { c ->
        val matchType = typeFilter == null || c.hazardType == typeFilter
        val matchStatus = statusFilter == null || c.status == statusFilter
        matchType && matchStatus
    }

    val treeCount = corridors.count { it.hazardType == HazardType.TREE && it.status != CorridorStatus.RESOLVED }
    val houseCount = corridors.count { it.hazardType == HazardType.HOUSE_BUILDING && it.status != CorridorStatus.RESOLVED }
    val otherCount = corridors.count { it.hazardType == HazardType.EQUIPMENT_OTHER && it.status != CorridorStatus.RESOLVED }
    val resolvedCount = corridors.count { it.status == CorridorStatus.RESOLVED }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "Hành Lang An Toàn Lưới Điện",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            "Cây xanh vi phạm, nhà cửa, công trình, thiết bị",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SpcNavy)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = SubstationCyan,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_corridor_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ghi nhận vi phạm hành lang")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Stats Row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$treeCount", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFF1B5E20))
                            Text("Cây xanh", fontSize = 11.sp, color = Color(0xFF1B5E20))
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFEDE7F6))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$houseCount", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFF4A148C))
                            Text("Nhà cửa", fontSize = 11.sp, color = Color(0xFF4A148C))
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$otherCount", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFFE65100))
                            Text("Mái tôn/Khác", fontSize = 11.sp, color = Color(0xFFE65100))
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F7FA))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$resolvedCount", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = SubstationCyan)
                            Text("Đã xử lý", fontSize = 11.sp, color = SubstationCyan)
                        }
                    }
                }
            }

            // Filter chips
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = typeFilter == null && statusFilter == null,
                        onClick = {
                            typeFilter = null
                            statusFilter = null
                        },
                        label = { Text("Tất cả (${corridors.size})") }
                    )
                    FilterChip(
                        selected = typeFilter == HazardType.TREE,
                        onClick = { typeFilter = if (typeFilter == HazardType.TREE) null else HazardType.TREE },
                        label = { Text("🌲 Cây xanh") }
                    )
                    FilterChip(
                        selected = typeFilter == HazardType.HOUSE_BUILDING,
                        onClick = { typeFilter = if (typeFilter == HazardType.HOUSE_BUILDING) null else HazardType.HOUSE_BUILDING },
                        label = { Text("🏠 Nhà cửa công trình") }
                    )
                    FilterChip(
                        selected = typeFilter == HazardType.EQUIPMENT_OTHER,
                        onClick = { typeFilter = if (typeFilter == HazardType.EQUIPMENT_OTHER) null else HazardType.EQUIPMENT_OTHER },
                        label = { Text("⚠️ Mái tôn & Khác") }
                    )
                    FilterChip(
                        selected = statusFilter == CorridorStatus.VIOLATION_EXISTING,
                        onClick = { statusFilter = if (statusFilter == CorridorStatus.VIOLATION_EXISTING) null else CorridorStatus.VIOLATION_EXISTING },
                        label = { Text("Chưa xử lý") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StatusDangerRed,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            // Corridors list
            if (filteredCorridors.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Không có điểm vi phạm nào trong mục này", color = MaterialTheme.colorScheme.outline)
                    }
                }
            } else {
                items(filteredCorridors, key = { it.id }) { item ->
                    CorridorItemCard(
                        corridor = item,
                        onResolve = { resolvingCorridor = item },
                        onReportPdf = { reportingCorridor = item }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(70.dp)) }
        }
    }

    if (showAddDialog) {
        AddCorridorDialog(
            onDismiss = { showAddDialog = false },
            onSave = {
                viewModel.saveCorridor(it)
                showAddDialog = false
            }
        )
    }

    resolvingCorridor?.let { c ->
        ResolveCorridorDialog(
            corridor = c,
            onDismiss = { resolvingCorridor = null },
            onConfirm = { by, action ->
                viewModel.resolveCorridor(c.id, by, action)
                resolvingCorridor = null
            }
        )
    }

    reportingCorridor?.let { c ->
        CorridorPdfReportDialog(
            corridor = c,
            onDismiss = { reportingCorridor = null }
        )
    }
}

@Composable
fun CorridorItemCard(
    corridor: SafetyCorridorRecord,
    onResolve: () -> Unit,
    onReportPdf: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                HazardTypeBadge(corridor.hazardType)
                CorridorStatusBadge(corridor.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Location
            Text(
                text = "${corridor.lineName} • ${corridor.spanLocation}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = ElectricBlue
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Distance & Risk pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (corridor.riskLevel == HazardRiskLevel.HIGH) Color(0xFFFFEBEE) else Color(0xFFFFF3E0))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "📏 Khoảng cách: ${corridor.currentDistance} • ${corridor.riskLevel.label}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (corridor.riskLevel == HazardRiskLevel.HIGH) StatusDangerRed else StatusWarningAmber
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Description
            Text(corridor.description, style = MaterialTheme.typography.bodyMedium)

            // Ảnh chụp hiện trường nếu có
            if (!corridor.photoBase64.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                val photoBitmap = remember(corridor.photoBase64) {
                    com.example.util.CameraPhotoHelper.base64ToBitmap(corridor.photoBase64)
                }
                if (photoBitmap != null) {
                    androidx.compose.foundation.Image(
                        bitmap = photoBitmap.asImageBitmap(),
                        contentDescription = "Ảnh hiện trường vi phạm hành lang",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Phát hiện: ${formatDateTime(corridor.discoveredDate)}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Resolution status
            if (corridor.status == CorridorStatus.RESOLVED) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFE8F5E9))
                        .padding(10.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = StatusNormalGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ĐÃ GIẢI TỎA / XỬ LÝ AN TOÀN", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = StatusNormalGreen)
                        }
                        if (corridor.clearedDate != null) {
                            Text("Ngày hoàn thành: ${formatDateTime(corridor.clearedDate)}", fontSize = 11.sp)
                        }
                        if (corridor.clearedBy != null) {
                            Text("Đơn vị xử lý: ${corridor.clearedBy}", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        }
                        if (corridor.clearanceActionTaken != null) {
                            Text("Biện pháp: ${corridor.clearanceActionTaken}", fontSize = 11.sp)
                        }
                    }
                }
            }

            // Action buttons
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onReportPdf,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("report_corridor_pdf_btn_${corridor.id}"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00695C)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ký & Báo Cáo QLVH", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                if (corridor.status != CorridorStatus.RESOLVED) {
                    Button(
                        onClick = onResolve,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("resolve_corridor_btn_${corridor.id}"),
                        colors = ButtonDefaults.buttonColors(containerColor = SubstationCyan),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("✓ Đã xử lý", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
