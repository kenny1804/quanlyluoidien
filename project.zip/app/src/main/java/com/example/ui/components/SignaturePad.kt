package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint as AndroidPaint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SignaturePad(
    inspectorName: String,
    onSignatureChanged: (Bitmap?) -> Unit,
    modifier: Modifier = Modifier
) {
    val points = remember { mutableStateListOf<List<Offset>>() }
    var currentLine by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var useElectronicSignOnly by remember { mutableStateOf(false) }

    fun generateBitmap(): Bitmap? {
        if (useElectronicSignOnly) {
            val width = 360
            val height = 120
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
                color = AndroidColor.parseColor("#0D47A1")
                textSize = 18f
                isFakeBoldText = true
            }
            val t1 = "✓ ĐÃ XÁC THỰC KÝ ĐIỆN TỬ"
            val w1 = paint.measureText(t1)
            canvas.drawText(t1, (width - w1) / 2f, 38f, paint)

            paint.textSize = 15f
            paint.color = AndroidColor.parseColor("#333333")
            paint.isFakeBoldText = false
            val t2 = "Cán bộ: $inspectorName"
            val w2 = paint.measureText(t2)
            canvas.drawText(t2, (width - w2) / 2f, 66f, paint)

            paint.textSize = 12f
            paint.color = AndroidColor.parseColor("#003366")
            val t3 = "Cty Điện lực An Giang (PCAG) • SPC"
            val w3 = paint.measureText(t3)
            canvas.drawText(t3, (width - w3) / 2f, 90f, paint)

            paint.textSize = 10.5f
            paint.color = AndroidColor.parseColor("#777777")
            val t4 = "Xác thực quản lý vận hành số"
            val w4 = paint.measureText(t4)
            canvas.drawText(t4, (width - w4) / 2f, 110f, paint)
            return bmp
        }

        if (points.isEmpty()) return null

        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = Float.MIN_VALUE
        var maxY = Float.MIN_VALUE
        var totalPoints = 0

        for (line in points) {
            for (pt in line) {
                totalPoints++
                if (pt.x < minX) minX = pt.x
                if (pt.y < minY) minY = pt.y
                if (pt.x > maxX) maxX = pt.x
                if (pt.y > maxY) maxY = pt.y
            }
        }

        if (totalPoints < 2 || maxX <= minX || maxY <= minY) return null

        val strokeWidthRange = (maxX - minX).coerceAtLeast(10f)
        val strokeHeightRange = (maxY - minY).coerceAtLeast(10f)

        // Tạo bitmap chữ ký sắc nét, căn giữa tuyệt đối
        val bmpWidth = 400
        val bmpHeight = 160
        val padX = 24f
        val padY = 20f
        val targetInnerW = bmpWidth - padX * 2f
        val targetInnerH = bmpHeight - padY * 2f

        val scale = minOf(targetInnerW / strokeWidthRange, targetInnerH / strokeHeightRange).coerceIn(0.2f, 4.0f)
        val scaledW = strokeWidthRange * scale
        val scaledH = strokeHeightRange * scale

        val offsetX = padX + (targetInnerW - scaledW) / 2f - (minX * scale)
        val offsetY = padY + (targetInnerH - scaledH) / 2f - (minY * scale)

        val bmp = Bitmap.createBitmap(bmpWidth, bmpHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
            color = AndroidColor.parseColor("#002171")
            strokeWidth = (3.5f * scale).coerceIn(3.0f, 5.5f)
            style = AndroidPaint.Style.STROKE
            strokeCap = AndroidPaint.Cap.ROUND
            strokeJoin = AndroidPaint.Join.ROUND
        }

        for (line in points) {
            if (line.size < 2) continue
            val path = android.graphics.Path()
            path.moveTo(line[0].x * scale + offsetX, line[0].y * scale + offsetY)
            for (i in 1 until line.size) {
                path.lineTo(line[i].x * scale + offsetX, line[i].y * scale + offsetY)
            }
            canvas.drawPath(path, paint)
        }
        return bmp
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Ký tên xác nhận:",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(
                    onClick = {
                        points.clear()
                        currentLine = emptyList()
                        useElectronicSignOnly = true
                        onSignatureChanged(generateBitmap())
                    }
                ) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Ký điện tử nhanh", fontSize = 11.sp)
                }

                TextButton(
                    onClick = {
                        points.clear()
                        currentLine = emptyList()
                        useElectronicSignOnly = false
                        onSignatureChanged(null)
                    }
                ) {
                    Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Xóa chữ ký", fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFFFAFAFA))
                .border(1.dp, if (points.isNotEmpty() || useElectronicSignOnly) Color(0xFF1976D2) else Color(0xFFCCCCCC), RoundedCornerShape(8.dp))
        ) {
            // Watermark chìm của Công ty Điện lực An Giang
            Text(
                text = "PCAG • Cty Điện lực An Giang",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF003366).copy(alpha = 0.22f),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
            )
            if (useElectronicSignOnly) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(12.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = Color(0xFF2E7D32),
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "XÁC NHẬN CHỮ KÝ ĐIỆN TỬ",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0D47A1),
                        fontSize = 13.sp
                    )
                    Text(
                        text = "Cán bộ kiểm tra: $inspectorName",
                        fontSize = 12.sp,
                        color = Color(0xFF333333)
                    )
                }
            } else {
                if (points.isEmpty() && currentLine.isEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Create,
                            contentDescription = null,
                            tint = Color(0xFF9E9E9E),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Dùng ngón tay ký trực tiếp vào khung này",
                            fontSize = 12.sp,
                            color = Color(0xFF9E9E9E)
                        )
                    }
                }

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    useElectronicSignOnly = false
                                    currentLine = listOf(offset)
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    currentLine = currentLine + change.position
                                },
                                onDragEnd = {
                                    if (currentLine.isNotEmpty()) {
                                        points.add(currentLine)
                                        currentLine = emptyList()
                                        onSignatureChanged(generateBitmap())
                                    }
                                },
                                onDragCancel = {
                                    currentLine = emptyList()
                                }
                            )
                        }
                ) {
                    val stroke = Stroke(
                        width = 4.dp.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                    for (line in points) {
                        if (line.size < 2) continue
                        val path = Path()
                        path.moveTo(line.first().x, line.first().y)
                        for (i in 1 until line.size) {
                            path.lineTo(line[i].x, line[i].y)
                        }
                        drawPath(path, Color(0xFF0D47A1), style = stroke)
                    }
                    if (currentLine.size >= 2) {
                        val path = Path()
                        path.moveTo(currentLine.first().x, currentLine.first().y)
                        for (i in 1 until currentLine.size) {
                            path.lineTo(currentLine[i].x, currentLine[i].y)
                        }
                        drawPath(path, Color(0xFF0D47A1), style = stroke)
                    }
                }
            }
        }
    }
}
