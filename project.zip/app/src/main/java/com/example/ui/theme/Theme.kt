package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = SpcNavyLight,
    secondary = SpcYellow,
    tertiary = SubstationCyan,
    background = Color(0xFF0F172A),
    surface = Color(0xFF1E293B),
    surfaceVariant = Color(0xFF334155),
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color(0xFFF8FAFC),
    onSurface = Color(0xFFF8FAFC),
    onSurfaceVariant = Color(0xFFE2E8F0),
    outline = Color(0xFF64748B)
  )

private val LightColorScheme =
  lightColorScheme(
    primary = SpcNavy,
    secondary = SpcYellow,
    tertiary = SubstationCyan,
    background = SpcBackgroundLight,
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE2E8F0),
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = SpcTextPrimaryLight,
    onSurface = SpcTextPrimaryLight,
    onSurfaceVariant = SpcTextSecondaryLight,
    outline = Color(0xFF94A3B8)
  )

private val OutdoorHighContrastColorScheme =
  lightColorScheme(
    primary = OutdoorPrimary,
    secondary = SpcYellow,
    tertiary = SubstationCyan,
    background = OutdoorBg,
    surface = OutdoorSurface,
    surfaceVariant = Color(0xFFE2E8F0),
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = OutdoorTextPrimary,
    onSurface = OutdoorTextPrimary,
    onSurfaceVariant = OutdoorTextSecondary,
    outline = OutdoorBorder
  )

@Composable
fun MyApplicationTheme(
  // Default to false: Cổng điều hành EVNSPC dùng giao diện sáng tương phản cao chuẩn ngành điện
  darkTheme: Boolean = false,
  outdoorHighContrast: Boolean = false,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    outdoorHighContrast -> OutdoorHighContrastColorScheme
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
