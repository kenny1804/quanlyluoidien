package com.example.ui.components

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.model.EquipmentStatus
import com.example.data.model.EquipmentType
import com.example.data.model.GridEquipment
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GridAmber
import com.example.ui.theme.SpcNavy
import com.example.ui.theme.StatusDangerRed
import com.example.ui.theme.StatusNormalGreen

enum class D3ChartMode(val label: String) {
    STACKED_BAR("Cột Chồng"),
    DONUT("Biểu Đồ Tròn"),
    GROUPED_BAR("Cột Nhóm")
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun D3EquipmentChart(
    equipments: List<GridEquipment>,
    modifier: Modifier = Modifier,
    initialMode: D3ChartMode = D3ChartMode.STACKED_BAR
) {
    var chartMode by remember { mutableStateOf(initialMode) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var isLoaded by remember { mutableStateOf(false) }

    // Aggregate data for the 6 equipment types requested
    val targetTypes = listOf(
        EquipmentType.RECLOSER,
        EquipmentType.LBS,
        EquipmentType.DS,
        EquipmentType.LA,
        EquipmentType.FCO,
        EquipmentType.LBFCO
    )

    // Build JSON data
    val jsonData = remember(equipments) {
        val list = targetTypes.map { type ->
            val matching = equipments.filter { it.type == type }
            val operational = matching.count { it.status == EquipmentStatus.OPERATIONAL }
            val warning = matching.count { it.status == EquipmentStatus.WARNING }
            val defect = matching.count { it.status == EquipmentStatus.DEFECT }
            val maintenance = matching.count { it.status == EquipmentStatus.MAINTENANCE }
            val total = matching.size

            """
            {
              "type": "${type.name}",
              "shortName": "${type.shortName}",
              "vietnameseName": "${type.vietnameseName}",
              "operational": $operational,
              "warning": $warning,
              "defect": $defect,
              "maintenance": $maintenance,
              "total": $total
            }
            """.trimIndent()
        }
        "[" + list.joinToString(",") + "]"
    }

    // Whenever data or mode changes, notify D3 script
    LaunchedEffect(jsonData, chartMode, isLoaded) {
        if (isLoaded && webViewRef != null) {
            val modeStr = chartMode.name
            webViewRef?.evaluateJavascript(
                "if (window.renderD3Chart) { window.renderD3Chart($jsonData, '$modeStr'); }",
                null
            )
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.5.dp, Color(0xFFCBD5E1), RoundedCornerShape(14.dp))
            .testTag("d3_equipment_chart_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Title and Mode Switcher
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(SpcNavy)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "THỐNG KÊ THIẾT BỊ D3.JS",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = SpcNavy
                        )
                    }
                    Text(
                        "Trực quan hóa Recloser, LBS, DS, LA, FCO, LBFCO",
                        fontSize = 11.sp,
                        color = Color(0xFF475569)
                    )
                }

                // Mode Buttons
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFF1F5F9))
                        .padding(2.dp)
                ) {
                    D3ChartMode.values().forEach { mode ->
                        val selected = chartMode == mode
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (selected) SpcNavy else Color.Transparent)
                                .clickable { chartMode = mode }
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                                .testTag("d3_mode_${mode.name}")
                        ) {
                            Text(
                                text = mode.label,
                                fontSize = 10.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = if (selected) Color.White else Color(0xFF334155)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Color Legend (High Contrast)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendItem(color = Color(0xFF15803D), label = "Vận hành tốt")
                LegendItem(color = Color(0xFFD97706), label = "Cảnh báo")
                LegendItem(color = Color(0xFFDC2626), label = "Khiếm khuyết")
                LegendItem(color = Color(0xFF0284C7), label = "Bảo dưỡng")
            }

            Spacer(modifier = Modifier.height(10.dp))

            // WebView Container for D3.js
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(290.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFF8FAFC))
                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
            ) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                cacheMode = WebSettings.LOAD_DEFAULT
                                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            }
                            setBackgroundColor(android.graphics.Color.WHITE)
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    isLoaded = true
                                    view?.evaluateJavascript(
                                        "if (window.renderD3Chart) { window.renderD3Chart($jsonData, '${chartMode.name}'); }",
                                        null
                                    )
                                }
                            }
                            webChromeClient = WebChromeClient()
                            loadDataWithBaseURL(
                                "https://localhost",
                                getD3HtmlContent(),
                                "text/html",
                                "UTF-8",
                                null
                            )
                            webViewRef = this
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(290.dp)
                )

                if (!isLoaded) {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(290.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = SpcNavy, modifier = Modifier.size(32.dp))
                    }
                }
            }

            // Summary Table Footnote
            Spacer(modifier = Modifier.height(8.dp))
            val totalAll = equipments.count { it.type in targetTypes }
            val warningDefects = equipments.count { it.type in targetTypes && (it.status == EquipmentStatus.WARNING || it.status == EquipmentStatus.DEFECT) }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "Tổng số: $totalAll thiết bị 6 phân loại",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                if (warningDefects > 0) {
                    Text(
                        "Cần chú ý: $warningDefects thiết bị",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB91C1C)
                    )
                } else {
                    Text(
                        "Tất cả ổn định",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF15803D)
                    )
                }
            }
        }
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            color = Color(0xFF1E293B),
            fontWeight = FontWeight.SemiBold
        )
    }
}

private fun getD3HtmlContent(): String {
    return """
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <script src="https://d3js.org/d3.v7.min.js"></script>
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          background-color: #ffffff;
          overflow: hidden;
          width: 100%;
          height: 100%;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }
        #chart-container {
          width: 100%;
          height: 100%;
          position: relative;
        }
        .tooltip {
          position: absolute;
          background: rgba(15, 23, 42, 0.95);
          color: #ffffff;
          padding: 6px 10px;
          border-radius: 6px;
          font-size: 11px;
          pointer-events: none;
          opacity: 0;
          transition: opacity 0.2s;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
          z-index: 10;
          font-weight: 500;
        }
        .axis text {
          font-size: 10px;
          font-weight: 600;
          fill: #1e293b;
        }
        .axis line, .axis path {
          stroke: #cbd5e1;
        }
        .bar-hover:hover {
          opacity: 0.85;
          cursor: pointer;
        }
      </style>
    </head>
    <body>
      <div id="chart-container">
        <div id="tooltip" class="tooltip"></div>
        <svg id="chart-svg"></svg>
      </div>

      <script>
        // High contrast colors for EVN SPC
        const colors = {
          operational: "#15803d",
          warning: "#d97706",
          defect: "#dc2626",
          maintenance: "#0284c7"
        };

        const statusNames = {
          operational: "Vận hành tốt",
          warning: "Cảnh báo đến hạn",
          defect: "Có khiếm khuyết",
          maintenance: "Đang bảo dưỡng"
        };

        let currentData = [];
        let currentMode = "STACKED_BAR";

        window.renderD3Chart = function(data, mode) {
          currentData = data || currentData;
          currentMode = mode || currentMode;

          const container = document.getElementById("chart-container");
          const width = container.clientWidth || 360;
          const height = container.clientHeight || 280;

          const svg = d3.select("#chart-svg")
            .attr("width", width)
            .attr("height", height);

          svg.selectAll("*").remove();

          const tooltip = d3.select("#tooltip");

          if (currentMode === "DONUT") {
            renderDonutChart(svg, currentData, width, height, tooltip);
          } else if (currentMode === "GROUPED_BAR") {
            renderGroupedBarChart(svg, currentData, width, height, tooltip);
          } else {
            renderStackedBarChart(svg, currentData, width, height, tooltip);
          }
        };

        function renderStackedBarChart(svg, data, width, height, tooltip) {
          const margin = { top: 20, right: 15, bottom: 40, left: 35 };
          const innerWidth = width - margin.left - margin.right;
          const innerHeight = height - margin.top - margin.bottom;

          const g = svg.append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

          const subgroups = ["operational", "warning", "defect", "maintenance"];
          const groups = data.map(d => d.shortName);

          const x = d3.scaleBand()
            .domain(groups)
            .range([0, innerWidth])
            .padding(0.32);

          const maxTotal = d3.max(data, d => d.total) || 5;
          const y = d3.scaleLinear()
            .domain([0, Math.max(maxTotal + 1, 4)])
            .nice()
            .range([innerHeight, 0]);

          // Grid lines
          g.append("g")
            .attr("class", "grid")
            .call(d3.axisLeft(y).ticks(5).tickSize(-innerWidth).tickFormat(""))
            .selectAll("line")
            .attr("stroke", "#f1f5f9");

          // Stack generator
          const stackedData = d3.stack()
            .keys(subgroups)(data);

          // Bars
          g.append("g")
            .selectAll("g")
            .data(stackedData)
            .join("g")
              .attr("fill", d => colors[d.key])
            .selectAll("rect")
            .data(d => d)
            .join("rect")
              .attr("class", "bar-hover")
              .attr("x", d => x(d.data.shortName))
              .attr("y", d => y(d[1]))
              .attr("height", d => y(d[0]) - y(d[1]))
              .attr("width", x.bandwidth())
              .attr("rx", 3)
              .on("touchstart click", function(event, d) {
                const key = d3.select(this.parentNode).datum().key;
                const count = d[1] - d[0];
                tooltip
                  .style("opacity", 1)
                  .html("<strong>" + d.data.shortName + "</strong> (" + d.data.vietnameseName + ")<br/>" +
                        statusNames[key] + ": <strong>" + count + "</strong> thiết bị<br/>" +
                        "Tổng: " + d.data.total)
                  .style("left", (event.pageX || 50) + "px")
                  .style("top", (event.pageY || 40) + "px");
                setTimeout(() => tooltip.style("opacity", 0), 3000);
              });

          // Bar top total labels
          g.selectAll(".total-label")
            .data(data)
            .join("text")
              .attr("class", "total-label")
              .attr("x", d => x(d.shortName) + x.bandwidth() / 2)
              .attr("y", d => y(d.total) - 5)
              .attr("text-anchor", "middle")
              .attr("font-size", "10px")
              .attr("font-weight", "bold")
              .attr("fill", "#0f172a")
              .text(d => d.total > 0 ? d.total : "");

          // X Axis
          g.append("g")
            .attr("class", "axis")
            .attr("transform", "translate(0," + innerHeight + ")")
            .call(d3.axisBottom(x))
            .selectAll("text")
            .style("text-anchor", "middle");

          // Y Axis
          g.append("g")
            .attr("class", "axis")
            .call(d3.axisLeft(y).ticks(5));
        }

        function renderGroupedBarChart(svg, data, width, height, tooltip) {
          const margin = { top: 20, right: 15, bottom: 40, left: 35 };
          const innerWidth = width - margin.left - margin.right;
          const innerHeight = height - margin.top - margin.bottom;

          const g = svg.append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

          const subgroups = ["operational", "warning", "defect", "maintenance"];
          const groups = data.map(d => d.shortName);

          const x0 = d3.scaleBand()
            .domain(groups)
            .range([0, innerWidth])
            .padding(0.2);

          const x1 = d3.scaleBand()
            .domain(subgroups)
            .range([0, x0.bandwidth()])
            .padding(0.08);

          const maxVal = d3.max(data, d => Math.max(d.operational, d.warning, d.defect, d.maintenance)) || 4;
          const y = d3.scaleLinear()
            .domain([0, maxVal + 1])
            .nice()
            .range([innerHeight, 0]);

          g.append("g")
            .selectAll("g")
            .data(data)
            .join("g")
              .attr("transform", d => "translate(" + x0(d.shortName) + ",0)")
            .selectAll("rect")
            .data(d => subgroups.map(key => ({ key: key, value: d[key], shortName: d.shortName })))
            .join("rect")
              .attr("class", "bar-hover")
              .attr("x", d => x1(d.key))
              .attr("y", d => y(d.value))
              .attr("width", x1.bandwidth())
              .attr("height", d => innerHeight - y(d.value))
              .attr("fill", d => colors[d.key])
              .attr("rx", 2)
              .on("touchstart click", function(event, d) {
                tooltip
                  .style("opacity", 1)
                  .html("<strong>" + d.shortName + "</strong><br/>" +
                        statusNames[d.key] + ": <strong>" + d.value + "</strong>")
                  .style("left", (event.pageX || 50) + "px")
                  .style("top", (event.pageY || 40) + "px");
                setTimeout(() => tooltip.style("opacity", 0), 2500);
              });

          g.append("g")
            .attr("class", "axis")
            .attr("transform", "translate(0," + innerHeight + ")")
            .call(d3.axisBottom(x0));

          g.append("g")
            .attr("class", "axis")
            .call(d3.axisLeft(y).ticks(5));
        }

        function renderDonutChart(svg, data, width, height, tooltip) {
          const radius = Math.min(width, height) / 2 - 25;
          const g = svg.append("g")
            .attr("transform", "translate(" + (width / 2) + "," + (height / 2) + ")");

          // Aggregated totals across all 6 equipment types
          const totals = {
            operational: d3.sum(data, d => d.operational),
            warning: d3.sum(data, d => d.warning),
            defect: d3.sum(data, d => d.defect),
            maintenance: d3.sum(data, d => d.maintenance)
          };

          const pieData = Object.keys(totals).map(k => ({
            status: k,
            label: statusNames[k],
            count: totals[k]
          })).filter(d => d.count > 0);

          const pie = d3.pie()
            .value(d => d.count)
            .sort(null);

          const arc = d3.arc()
            .innerRadius(radius * 0.52)
            .outerRadius(radius * 0.88)
            .cornerRadius(4);

          const outerArc = d3.arc()
            .innerRadius(radius * 0.9)
            .outerRadius(radius * 0.9);

          const totalSum = d3.sum(pieData, d => d.count);

          g.selectAll("path")
            .data(pie(pieData))
            .join("path")
              .attr("d", arc)
              .attr("fill", d => colors[d.data.status])
              .attr("stroke", "#ffffff")
              .style("stroke-width", "2px")
              .attr("class", "bar-hover")
              .on("touchstart click", function(event, d) {
                const pct = totalSum > 0 ? Math.round((d.data.count / totalSum) * 100) : 0;
                tooltip
                  .style("opacity", 1)
                  .html("<strong>" + d.data.label + "</strong><br/>Số lượng: <strong>" + d.data.count + "</strong> (" + pct + "%)")
                  .style("left", (width / 2 - 40) + "px")
                  .style("top", (height / 2 - 20) + "px");
                setTimeout(() => tooltip.style("opacity", 0), 3000);
              });

          // Center Text
          g.append("text")
            .attr("text-anchor", "middle")
            .attr("dy", "-0.2em")
            .attr("font-size", "18px")
            .attr("font-weight", "bold")
            .attr("fill", "#0f172a")
            .text(totalSum);

          g.append("text")
            .attr("text-anchor", "middle")
            .attr("dy", "1.2em")
            .attr("font-size", "10px")
            .attr("font-weight", "600")
            .attr("fill", "#64748b")
            .text("THIẾT BỊ");
        }

        // Trigger on load
        window.addEventListener("resize", () => {
          if (currentData.length > 0) window.renderD3Chart(currentData, currentMode);
        });
      </script>
    </body>
    </html>
    """.trimIndent()
}
