package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AlertActionType
import com.example.data.model.AlertSeverity
import com.example.data.model.AlertType
import com.example.data.model.AssignedWorkTask
import com.example.data.model.DefectRecord
import com.example.data.model.EquipmentType
import com.example.data.model.GridAlert
import com.example.data.model.GridEquipment
import com.example.data.model.SafetyCorridorRecord
import com.example.ui.components.D3EquipmentChart
import com.example.ui.components.EquipmentStatusBadge
import com.example.ui.components.EquipmentTypeBadge
import com.example.ui.components.formatTimestamp
import com.example.ui.dialogs.CorridorPdfReportDialog
import com.example.ui.dialogs.DefectPdfReportDialog
import com.example.ui.dialogs.InspectorSettingsDialog
import com.example.ui.dialogs.PdfReportDialog
import com.example.ui.dialogs.TaskPdfReportDialog
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GridAmber
import com.example.ui.theme.SpcNavy
import com.example.ui.theme.StatusDangerRed
import com.example.ui.theme.StatusNormalGreen
import com.example.ui.theme.StatusWarningAmber
import com.example.ui.theme.SubstationCyan
import com.example.ui.viewmodel.GridViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    viewModel: GridViewModel,
    onNavigateToEquipment: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val stats by viewModel.gridStats.collectAsStateWithLifecycle()
    val equipments by viewModel.allEquipments.collectAsStateWithLifecycle()
    val maintenanceRecords by viewModel.maintenanceRecords.collectAsStateWithLifecycle()
    val inspections by viewModel.inspections.collectAsStateWithLifecycle()
    val defects by viewModel.defects.collectAsStateWithLifecycle()
    val corridors by viewModel.corridorRecords.collectAsStateWithLifecycle()
    val automatedAlerts by viewModel.automatedAlerts.collectAsStateWithLifecycle()
    val tasks by viewModel.allAssignedTasks.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var showPdfDialog by remember { mutableStateOf(false) }
    var selectedEquipmentForPdf by remember { mutableStateOf<Long?>(null) }
    var showInspectorSettingsDialog by remember { mutableStateOf(false) }

    var reportingDefect by remember { mutableStateOf<DefectRecord?>(null) }
    var reportingCorridor by remember { mutableStateOf<SafetyCorridorRecord?>(null) }
    var reportingTask by remember { mutableStateOf<AssignedWorkTask?>(null) }

    // Alert filter: null = all, or specific severity
    var selectedAlertSeverity by remember { mutableStateOf<AlertSeverity?>(null) }

    // Equipment report filter: null = all, or specific type
    var selectedReportType by remember { mutableStateOf<EquipmentType?>(null) }

    val now = System.currentTimeMillis()

    // Alert counts
    val criticalAlertsCount = automatedAlerts.count { it.severity == AlertSeverity.CRITICAL }
    val warningAlertsCount = automatedAlerts.count { it.severity == AlertSeverity.WARNING }
    val infoAlertsCount = automatedAlerts.count { it.severity == AlertSeverity.INFO }

    val filteredAlerts = remember(automatedAlerts, selectedAlertSeverity) {
        if (selectedAlertSeverity == null) automatedAlerts
        else automatedAlerts.filter { it.severity == selectedAlertSeverity }
    }

    // Filtered equipments for reports list
    val filteredEquipments = remember(equipments, selectedReportType) {
        if (selectedReportType == null) equipments
        else equipments.filter { it.type == selectedReportType }
    }

    // Calculations
    val defectTotal = stats.activeDefects + stats.resolvedDefects
    val defectRate = if (defectTotal > 0) (stats.resolvedDefects.toFloat() / defectTotal) else 1f

    val corridorTotal = stats.activeCorridorHazards + stats.resolvedCorridorHazards
    val corridorRate = if (corridorTotal > 0) (stats.resolvedCorridorHazards.toFloat() / corridorTotal) else 1f

    val inspectionOnTimeRate = if (stats.totalEquipments > 0) {
        ((stats.totalEquipments - stats.overdueInspections).toFloat() / stats.totalEquipments)
    } else 1f

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "Báo Cáo & Cảnh Báo Lưới Điện",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            "SPC • Cty Điện lực An Giang (PCAG)",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFFFF9C4)
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showInspectorSettingsDialog = true },
                        modifier = Modifier.testTag("reports_inspector_settings_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ManageAccounts,
                            contentDescription = "Cán bộ & Đơn vị",
                            tint = Color.White
                        )
                    }
                    Button(
                        onClick = {
                            selectedEquipmentForPdf = null
                            showPdfDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("reports_top_export_pdf_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Xuất PDF Toàn Bộ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SpcNavy)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF8FAFC)),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Executive Quick Export Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SpcNavy),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "Báo Cáo Tình Trạng Thiết Bị Chuẩn EVN",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    "Bao gồm thông số kỹ thuật, kiểm tra định kỳ, bảo dưỡng, khiếm khuyết và hành lang an toàn",
                                    fontSize = 12.sp,
                                    color = Color(0xFFE2E8F0)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(Icons.Filled.Assignment, contentDescription = null, tint = GridAmber, modifier = Modifier.size(32.dp))
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    selectedEquipmentForPdf = null
                                    showPdfDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("export_pdf_report_btn")
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("BC Thiết Bị PDF", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    val reportText = viewModel.generateExecutiveReport()
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("Báo cáo lưới điện EVN", reportText)
                                    clipboard.setPrimaryClip(clip)
                                    Toast.makeText(context, "Đã sao chép báo cáo EVN đầy đủ vào bộ nhớ tạm!", Toast.LENGTH_LONG).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GridAmber),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("copy_report_btn")
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Sao Chép EVN", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Quick buttons for other sub-modules
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // Defect PDF
                            OutlinedButton(
                                onClick = {
                                    val latestDefect = defects.firstOrNull()
                                    if (latestDefect != null) {
                                        reportingDefect = latestDefect
                                    } else {
                                        Toast.makeText(context, "Chưa có khiếm khuyết nào được ghi nhận để xuất báo cáo", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = Color(0xFFE65100).copy(alpha = 0.15f),
                                    contentColor = Color.White
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFB74D)),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("export_defect_pdf_btn"),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFFCC80), modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("BC Khiếm Khuyết", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                            }

                            // Corridor PDF
                            OutlinedButton(
                                onClick = {
                                    val latestCorridor = corridors.firstOrNull()
                                    if (latestCorridor != null) {
                                        reportingCorridor = latestCorridor
                                    } else {
                                        Toast.makeText(context, "Chưa có điểm hành lang nào được ghi nhận để xuất báo cáo", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = Color(0xFF2E7D32).copy(alpha = 0.15f),
                                    contentColor = Color.White
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA5D6A7)),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("export_corridor_pdf_btn"),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFA5D6A7), modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("BC Hành Lang", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                            }

                            // Task PDF
                            OutlinedButton(
                                onClick = {
                                    val latestTask = tasks.firstOrNull()
                                    if (latestTask != null) {
                                        reportingTask = latestTask
                                    } else {
                                        Toast.makeText(context, "Chưa có công việc nào được giao để xuất báo cáo", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = Color(0xFF0288D1).copy(alpha = 0.15f),
                                    contentColor = Color.White
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF81D4FA)),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("export_task_pdf_btn"),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Assignment, contentDescription = null, tint = Color(0xFF81D4FA), modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("BC Công Việc", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                            }
                        }
                    }
                }
            }

            // D3.js Equipment Statistical Chart Module
            item {
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    D3EquipmentChart(
                        equipments = equipments,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // 2. Automated Alerts Section (Recloser, LBS, DS, LA, FCO, LBFCO)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (criticalAlertsCount > 0) Color(0xFFFFF1F2) else Color.White
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (criticalAlertsCount > 0) Color(0xFFFECDD3) else Color(0xFFCBD5E1)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(if (criticalAlertsCount > 0) Color(0xFFE11D48) else Color(0xFFD97706)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Filled.NotificationsActive,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        "Hệ Thống Cảnh Báo Tự Động Thiết Bị",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (criticalAlertsCount > 0) Color(0xFF9F1239) else Color(0xFF0F172A)
                                    )
                                    Text(
                                        "Tự động rà soát hạn kiểm tra, bảo dưỡng, khiếm khuyết và hành lang an toàn",
                                        fontSize = 11.sp,
                                        color = Color(0xFF475569)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Severity Filter Chips
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = selectedAlertSeverity == null,
                                onClick = { selectedAlertSeverity = null },
                                label = { Text("Tất cả (${automatedAlerts.size})", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                            )
                            FilterChip(
                                selected = selectedAlertSeverity == AlertSeverity.CRITICAL,
                                onClick = { selectedAlertSeverity = AlertSeverity.CRITICAL },
                                label = { Text("Nguy cấp ($criticalAlertsCount)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFFFEBEE),
                                    selectedLabelColor = StatusDangerRed
                                )
                            )
                            FilterChip(
                                selected = selectedAlertSeverity == AlertSeverity.WARNING,
                                onClick = { selectedAlertSeverity = AlertSeverity.WARNING },
                                label = { Text("Cảnh báo ($warningAlertsCount)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFFFF8E1),
                                    selectedLabelColor = Color(0xFFB45309)
                                )
                            )
                            FilterChip(
                                selected = selectedAlertSeverity == AlertSeverity.INFO,
                                onClick = { selectedAlertSeverity = AlertSeverity.INFO },
                                label = { Text("Nhắc nhở ($infoAlertsCount)", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFE0F2FE),
                                    selectedLabelColor = Color(0xFF0369A1)
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (filteredAlerts.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFF1F5F9))
                                    .padding(14.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "Không có cảnh báo nào trong nhóm này.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF475569),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        } else {
                            filteredAlerts.forEach { alert ->
                                AlertItemCard(
                                    alert = alert,
                                    onClick = { onNavigateToEquipment(alert.equipmentId) }
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                        }
                    }
                }
            }

            // 3. Module Báo Cáo Chi Tiết Từng Thiết Bị (Recloser, LBS, DS, LA, FCO, LBFCO)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "Module Báo Cáo Chi Tiết Thiết Bị",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    "Tạo và tải báo cáo PDF tình trạng kỹ thuật cho từng thiết bị",
                                    fontSize = 11.sp,
                                    color = Color(0xFF475569)
                                )
                            }
                            Icon(Icons.Filled.PictureAsPdf, contentDescription = null, tint = Color(0xFFD32F2F))
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Type Filter Chips for reports
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = selectedReportType == null,
                                onClick = { selectedReportType = null },
                                label = { Text("Tất cả (${equipments.size})", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                            )
                            EquipmentType.entries.forEach { eqType ->
                                val count = equipments.count { it.type == eqType }
                                FilterChip(
                                    selected = selectedReportType == eqType,
                                    onClick = { selectedReportType = eqType },
                                    label = { Text("${eqType.displayName} ($count)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        filteredEquipments.forEach { eq ->
                            val eqMaintenanceCount = maintenanceRecords.count { it.equipmentId == eq.id }
                            val eqDefectCount = defects.count { it.equipmentId == eq.id }
                            val eqCorridorCount = corridors.count {
                                it.lineName.contains(eq.lineName, ignoreCase = true) || eq.lineName.contains(it.lineName, ignoreCase = true)
                            }
                            val isOverdue = eq.nextInspectionDate in 1 until now

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            EquipmentTypeBadge(eq.type)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(eq.code, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF0F172A))
                                                Text(eq.name, fontSize = 12.sp, color = Color(0xFF334155), fontWeight = FontWeight.Medium)
                                            }
                                        }
                                        EquipmentStatusBadge(eq.status)
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        "${eq.lineName} • ${eq.poleNumber} • ${eq.substation}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF475569)
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))

                                    // Metric tags
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "$eqMaintenanceCount bảo dưỡng",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = Color(0xFF15803D)
                                        )
                                        Text("•", fontSize = 11.sp, color = Color(0xFF94A3B8))
                                        Text(
                                            text = "$eqDefectCount khiếm khuyết",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (eqDefectCount > 0) Color(0xFFB91C1C) else Color(0xFF64748B)
                                        )
                                        Text("•", fontSize = 11.sp, color = Color(0xFF94A3B8))
                                        Text(
                                            text = "$eqCorridorCount vi phạm HLAT",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (eqCorridorCount > 0) Color(0xFFD97706) else Color(0xFF64748B)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (isOverdue) "⚠️ Quá hạn: ${formatTimestamp(eq.nextInspectionDate)}"
                                            else "Kỳ tới: ${formatTimestamp(eq.nextInspectionDate)}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isOverdue) StatusDangerRed else Color(0xFF334155)
                                        )

                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            OutlinedButton(
                                                onClick = { onNavigateToEquipment(eq.id) },
                                                shape = RoundedCornerShape(6.dp),
                                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                                modifier = Modifier.height(32.dp)
                                            ) {
                                                Text("Chi tiết", fontSize = 11.sp, color = SpcNavy)
                                            }

                                            Button(
                                                onClick = {
                                                    selectedEquipmentForPdf = eq.id
                                                    showPdfDialog = true
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                                                shape = RoundedCornerShape(6.dp),
                                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                                modifier = Modifier.height(32.dp)
                                            ) {
                                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Xuất PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. Performance Metrics & Progress Indicators
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            "Chỉ Tiêu Vận Hành & Khắc Phục",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Tỷ lệ kiểm tra đúng hạn
                        MetricProgressItem(
                            label = "Tỷ lệ kiểm tra định kỳ đúng hạn",
                            value = "${(inspectionOnTimeRate * 100).toInt()}%",
                            progress = inspectionOnTimeRate,
                            color = if (inspectionOnTimeRate >= 0.9f) StatusNormalGreen else StatusDangerRed
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Tỷ lệ khắc phục khiếm khuyết
                        MetricProgressItem(
                            label = "Tiến độ khắc phục khiếm khuyết",
                            value = "${(defectRate * 100).toInt()}% (${stats.resolvedDefects}/$defectTotal)",
                            progress = defectRate,
                            color = SpcNavy
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Tỷ lệ giải tỏa hành lang an toàn
                        MetricProgressItem(
                            label = "Tiến độ phát quang / giải tỏa hành lang",
                            value = "${(corridorRate * 100).toInt()}% (${stats.resolvedCorridorHazards}/$corridorTotal)",
                            progress = corridorRate,
                            color = SubstationCyan
                        )
                    }
                }
            }

            // 5. Equipment distribution breakdown
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            "Phân Bổ Chủng Loại Thiết Bị (6 Loại)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            TypeStatItem("Recloser (Máy cắt)", "${stats.recloserCount}", SpcNavy)
                            TypeStatItem("LBS (Cắt có tải)", "${stats.lbsCount}", SubstationCyan)
                            TypeStatItem("DS (Cầu dao)", "${stats.dsCount}", Color(0xFF455A64))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            TypeStatItem("LA (Chống sét)", "${stats.laCount}", GridAmber)
                            TypeStatItem("FCO (Chì tự rơi)", "${stats.fcoCount}", Color(0xFF6A1B9A))
                            TypeStatItem("LBFCO (Cắt phụ tải)", "${stats.lbfcoCount}", Color(0xFF00695C))
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(80.dp)) }
        }
    }

    if (showInspectorSettingsDialog) {
        InspectorSettingsDialog(
            viewModel = viewModel,
            onOpenPdfReport = {
                showInspectorSettingsDialog = false
                selectedEquipmentForPdf = null
                showPdfDialog = true
            },
            onDismiss = { showInspectorSettingsDialog = false }
        )
    }

    if (showPdfDialog) {
        PdfReportDialog(
            equipments = equipments,
            maintenanceRecords = maintenanceRecords,
            inspections = inspections,
            defects = defects,
            corridors = corridors,
            preSelectedEquipmentId = selectedEquipmentForPdf,
            onDismiss = {
                showPdfDialog = false
                selectedEquipmentForPdf = null
            }
        )
    }

    reportingDefect?.let { defect ->
        DefectPdfReportDialog(
            defect = defect,
            onDismiss = { reportingDefect = null }
        )
    }

    reportingCorridor?.let { corridor ->
        CorridorPdfReportDialog(
            corridor = corridor,
            onDismiss = { reportingCorridor = null }
        )
    }

    reportingTask?.let { task ->
        TaskPdfReportDialog(
            task = task,
            onDismiss = { reportingTask = null }
        )
    }
}

@Composable
fun AlertItemCard(
    alert: GridAlert,
    onClick: () -> Unit
) {
    val borderColor = when (alert.severity) {
        AlertSeverity.CRITICAL -> Color(0xFFFECDD3)
        AlertSeverity.WARNING -> Color(0xFFFED7AA)
        AlertSeverity.INFO -> Color(0xFFBAE6FD)
    }

    val bannerBg = when (alert.severity) {
        AlertSeverity.CRITICAL -> Color(0xFFFFF1F2)
        AlertSeverity.WARNING -> Color(0xFFFFFBEB)
        AlertSeverity.INFO -> Color(0xFFF0F9FF)
    }

    val severityLabelColor = when (alert.severity) {
        AlertSeverity.CRITICAL -> Color(0xFFBE123C)
        AlertSeverity.WARNING -> Color(0xFFB45309)
        AlertSeverity.INFO -> Color(0xFF0369A1)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    EquipmentTypeBadge(alert.equipmentType)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = alert.equipmentCode,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = "${alert.lineName} • ${alert.poleNumber}",
                            fontSize = 11.sp,
                            color = Color(0xFF475569)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(bannerBg)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = alert.severity.displayName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = severityLabelColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = alert.title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color(0xFF0F172A)
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = alert.description,
                fontSize = 12.sp,
                color = Color(0xFF334155)
            )

            if (alert.details.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = alert.details,
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Recommended Action Box
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFFF1F5F9))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Build,
                        contentDescription = null,
                        tint = SpcNavy,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Khuyến nghị: ${alert.recommendedAction}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF1E293B)
                    )
                }

                Icon(
                    Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Xem thiết bị",
                    tint = SpcNavy,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun MetricProgressItem(
    label: String,
    value: String,
    progress: Float,
    color: Color
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 12.sp, color = Color(0xFF334155), fontWeight = FontWeight.Medium)
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { progress.coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = color,
            trackColor = color.copy(alpha = 0.2f)
        )
    }
}

@Composable
fun TypeStatItem(label: String, count: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.1f))
            .border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(count, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = color)
            Text(label, fontSize = 10.sp, color = color, fontWeight = FontWeight.Bold)
        }
    }
}
