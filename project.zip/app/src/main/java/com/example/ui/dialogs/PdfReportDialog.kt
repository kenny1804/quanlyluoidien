package com.example.ui.dialogs

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import com.example.data.repository.InspectorProfileManager
import com.example.ui.components.SignaturePad
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.DefectRecord
import com.example.data.model.EquipmentType
import com.example.data.model.GridEquipment
import com.example.data.model.MaintenanceRecord
import com.example.data.model.PeriodicInspection
import com.example.data.model.SafetyCorridorRecord
import com.example.ui.components.PdfQuickShareSection
import com.example.util.PdfReportGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfReportDialog(
    equipments: List<GridEquipment>,
    maintenanceRecords: List<MaintenanceRecord>,
    inspections: List<PeriodicInspection>,
    defects: List<DefectRecord>,
    corridors: List<SafetyCorridorRecord> = emptyList(),
    preSelectedEquipmentId: Long? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedIds by remember {
        mutableStateOf(
            if (preSelectedEquipmentId != null) {
                setOf(preSelectedEquipmentId)
            } else {
                equipments.map { it.id }.toSet()
            }
        )
    }

    var selectedFeederFilter by remember { mutableStateOf("Tất cả") }
    var selectedTypeFilter by remember { mutableStateOf<EquipmentType?>(null) }

    var isGenerating by remember { mutableStateOf(false) }
    var generatedFile by remember { mutableStateOf<File?>(null) }
    var renderedBitmaps by remember { mutableStateOf<List<Bitmap>>(emptyList()) }
    var currentPreviewPage by remember { mutableIntStateOf(0) }

    val feeders = listOf("Tất cả", "471", "472", "473")

    val initialProfile = remember { InspectorProfileManager.getProfile(context) }
    var inspectorName by remember { mutableStateOf(initialProfile.inspectorName) }
    var teamName by remember { mutableStateOf(initialProfile.teamName) }
    var companyName by remember { mutableStateOf(initialProfile.companyName) }
    var managedArea by remember { mutableStateOf(initialProfile.managedArea) }
    var signatureBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var showSignatureSection by remember { mutableStateOf(true) }

    val filteredEquipments = equipments.filter { eq ->
        val feederMatch = selectedFeederFilter == "Tất cả" || eq.lineName.contains(selectedFeederFilter)
        val typeMatch = selectedTypeFilter == null || eq.type == selectedTypeFilter
        feederMatch && typeMatch
    }

    Dialog(
        onDismissRequest = {
            if (!isGenerating) onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Top Header Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF003366))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE53935)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PictureAsPdf,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (renderedBitmaps.isNotEmpty()) "Bản Xem Trước Báo Cáo PDF" else "Xuất Báo Cáo Kỹ Thuật PDF",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                )
                                Text(
                                    text = "SPC • Cty Điện lực An Giang (PCAG) • Dấu chìm xác thực",
                                    color = Color(0xFFFFF9C4),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Đóng",
                                tint = Color.White
                            )
                        }
                    }
                }

                if (renderedBitmaps.isNotEmpty() && generatedFile != null) {
                    // Preview Screen
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        // Action Bar at top of Preview
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    renderedBitmaps = emptyList()
                                    generatedFile = null
                                }
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Chọn Lại Thiết Bị", fontSize = 12.sp)
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = {
                                        generatedFile?.let {
                                            PdfReportGenerator.sharePdfToOperationTeam(
                                                context = context,
                                                pdfFile = it,
                                                teamName = teamName,
                                                inspectorName = inspectorName,
                                                area = managedArea
                                            )
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003366))
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Gửi Tổ QLVH", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        generatedFile?.let { PdfReportGenerator.openPdfFile(context, it) }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                                ) {
                                    Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Mở File", fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        generatedFile?.let { PdfReportGenerator.sharePdfFile(context, it) }
                                    }
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = "Chia sẻ", modifier = Modifier.size(16.dp))
                                }

                                OutlinedButton(
                                    onClick = {
                                        generatedFile?.let { PdfReportGenerator.printPdfFile(context, it) }
                                    }
                                ) {
                                    Icon(Icons.Default.Print, contentDescription = "In báo cáo", modifier = Modifier.size(16.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Page navigation header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { if (currentPreviewPage > 0) currentPreviewPage-- },
                                enabled = currentPreviewPage > 0
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Trang trước")
                            }

                            Text(
                                text = "Trang ${currentPreviewPage + 1} / ${renderedBitmaps.size}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )

                            IconButton(
                                onClick = { if (currentPreviewPage < renderedBitmaps.size - 1) currentPreviewPage++ },
                                enabled = currentPreviewPage < renderedBitmaps.size - 1
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Trang sau")
                            }
                        }

                        // Page Rendered View
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .background(Color(0xFFE0E0E0), RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFFBDBDBD), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            val bitmap = renderedBitmaps.getOrNull(currentPreviewPage)
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap.asImageBitmap(),
                                    contentDescription = "Trang ${currentPreviewPage + 1}",
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .aspectRatio(595f / 842f)
                                        .clip(RoundedCornerShape(4.dp))
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        PdfQuickShareSection(
                            onShareZalo = {
                                generatedFile?.let {
                                    PdfReportGenerator.shareReportViaTarget(
                                        context = context,
                                        pdfFile = it,
                                        target = PdfReportGenerator.ShareTarget.ZALO,
                                        reportTitle = "Báo cáo kỹ thuật thiết bị lưới điện",
                                        teamName = teamName,
                                        inspectorName = inspectorName,
                                        area = managedArea
                                    )
                                }
                            },
                            onShareGmail = {
                                generatedFile?.let {
                                    PdfReportGenerator.shareReportViaTarget(
                                        context = context,
                                        pdfFile = it,
                                        target = PdfReportGenerator.ShareTarget.GMAIL,
                                        reportTitle = "Báo cáo kỹ thuật thiết bị lưới điện",
                                        teamName = teamName,
                                        inspectorName = inspectorName,
                                        area = managedArea
                                    )
                                }
                            },
                            onShareTelegram = {
                                generatedFile?.let {
                                    PdfReportGenerator.shareReportViaTarget(
                                        context = context,
                                        pdfFile = it,
                                        target = PdfReportGenerator.ShareTarget.TELEGRAM,
                                        reportTitle = "Báo cáo kỹ thuật thiết bị lưới điện",
                                        teamName = teamName,
                                        inspectorName = inspectorName,
                                        area = managedArea
                                    )
                                }
                            },
                            onShareGeneral = {
                                generatedFile?.let { PdfReportGenerator.sharePdfFile(context, it) }
                            },
                            onPrint = {
                                generatedFile?.let { PdfReportGenerator.printPdfFile(context, it) }
                            },
                            onOpenFile = {
                                generatedFile?.let { PdfReportGenerator.openPdfFile(context, it) }
                            }
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Check,
                                contentDescription = null,
                                tint = Color(0xFF003366),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Bản in PDF có dấu chìm: CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF003366)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "File PDF đã lưu tại bộ nhớ máy. Bạn có thể gửi Tổ QLVH hoặc mở đọc ngay.",
                            fontSize = 11.sp,
                            color = Color(0xFF616161),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                } else {
                    // Device Selection Screen
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Chọn thiết bị cần xuất báo cáo tổng hợp:",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        // Selection stats & Select All / Deselect All
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Đã chọn: ${selectedIds.size} / ${equipments.size} thiết bị",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(
                                    onClick = {
                                        selectedIds = equipments.map { it.id }.toSet()
                                    }
                                ) {
                                    Text("Chọn tất cả", fontSize = 12.sp)
                                }
                                TextButton(
                                    onClick = {
                                        selectedIds = emptySet()
                                    }
                                ) {
                                    Text("Bỏ chọn", fontSize = 12.sp)
                                }
                            }
                        }

                        // Filter by feeder
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("Tuyến:", fontSize = 12.sp, color = Color.Gray)
                            feeders.forEach { feeder ->
                                FilterChip(
                                    selected = selectedFeederFilter == feeder,
                                    onClick = { selectedFeederFilter = feeder },
                                    label = { Text(feeder, fontSize = 11.sp) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Card: Thông tin Cán bộ & Chữ ký gửi Tổ QLVH
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { showSignatureSection = !showSignatureSection },
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Send, contentDescription = null, tint = Color(0xFF003366), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Thông tin Cán bộ & Ký tên gửi Tổ QLVH",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.5.sp,
                                            color = Color(0xFF003366)
                                        )
                                    }
                                    Text(
                                        text = if (showSignatureSection) "Thu gọn ▲" else "Mở rộng ▼",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }

                                if (showSignatureSection) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(
                                            value = inspectorName,
                                            onValueChange = { inspectorName = it },
                                            label = { Text("Cán bộ kiểm tra", fontSize = 10.sp) },
                                            placeholder = { Text("VD: Nguyễn Văn A", fontSize = 10.sp) },
                                            modifier = Modifier.weight(1f),
                                            singleLine = true
                                        )
                                        OutlinedTextField(
                                            value = teamName,
                                            onValueChange = { teamName = it },
                                            label = { Text("Tổ QLVH tiếp nhận", fontSize = 10.sp) },
                                            modifier = Modifier.weight(1f),
                                            singleLine = true
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    OutlinedTextField(
                                        value = managedArea,
                                        onValueChange = { managedArea = it },
                                        label = { Text("Khu vực / Tuyến phụ trách", fontSize = 10.sp) },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    SignaturePad(
                                        inspectorName = inspectorName,
                                        onSignatureChanged = { signatureBitmap = it }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Equipment List
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(filteredEquipments) { equipment ->
                                val isSelected = selectedIds.contains(equipment.id)
                                val eqMaintenanceCount = maintenanceRecords.count { it.equipmentId == equipment.id }
                                val eqDefectCount = defects.count { it.equipmentId == equipment.id }

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedIds = if (isSelected) {
                                                selectedIds - equipment.id
                                            } else {
                                                selectedIds + equipment.id
                                            }
                                        },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) Color(0xFFE8F0FE) else MaterialTheme.colorScheme.surfaceVariant
                                    ),
                                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF1976D2)) else null
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = isSelected,
                                            onCheckedChange = { checked ->
                                                selectedIds = if (checked) {
                                                    selectedIds + equipment.id
                                                } else {
                                                    selectedIds - equipment.id
                                                }
                                            }
                                        )

                                        Spacer(modifier = Modifier.width(6.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text(
                                                    text = equipment.code,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    color = Color(0xFF0D47A1)
                                                )
                                                Box(
                                                    modifier = Modifier
                                                        .background(Color(0xFFE0E0E0), RoundedCornerShape(4.dp))
                                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text(
                                                        text = equipment.type.displayName,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                }
                                            }

                                            Text(
                                                text = equipment.name,
                                                fontSize = 12.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )

                                            Row(
                                                modifier = Modifier.padding(top = 2.dp),
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                Text(
                                                    text = "${equipment.lineName} - ${equipment.poleNumber}",
                                                    fontSize = 11.sp,
                                                    color = Color(0xFF334155),
                                                    fontWeight = FontWeight.Medium
                                                )
                                                Text(
                                                    text = "$eqMaintenanceCount đợt bảo dưỡng",
                                                    fontSize = 11.sp,
                                                    color = Color(0xFF15803D),
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                if (eqDefectCount > 0) {
                                                    Text(
                                                        text = "$eqDefectCount khiếm khuyết",
                                                        fontSize = 11.sp,
                                                        color = Color(0xFFB91C1C),
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Bottom button: Generate PDF
                        Button(
                            onClick = {
                                val selectedList = equipments.filter { selectedIds.contains(it.id) }
                                if (selectedList.isNotEmpty()) {
                                    isGenerating = true
                                    coroutineScope.launch {
                                        withContext(Dispatchers.Default) {
                                            val file = PdfReportGenerator.generateDeviceSummaryPdf(
                                                context = context,
                                                selectedEquipments = selectedList,
                                                allMaintenance = maintenanceRecords,
                                                allInspections = inspections,
                                                allDefects = defects,
                                                allCorridors = corridors,
                                                inspectorName = inspectorName,
                                                teamName = teamName,
                                                companyName = companyName,
                                                managedArea = managedArea,
                                                signatureBitmap = signatureBitmap
                                            )
                                            val bitmaps = PdfReportGenerator.renderPdfPagesToBitmaps(file)
                                            withContext(Dispatchers.Main) {
                                                generatedFile = file
                                                renderedBitmaps = bitmaps
                                                currentPreviewPage = 0
                                                isGenerating = false
                                            }
                                        }
                                    }
                                }
                            },
                            enabled = selectedIds.isNotEmpty() && !isGenerating,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003366))
                        ) {
                            if (isGenerating) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Đang khởi tạo báo cáo PDF...")
                            } else {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Tạo Báo Cáo PDF (${selectedIds.size} Thiết Bị)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
