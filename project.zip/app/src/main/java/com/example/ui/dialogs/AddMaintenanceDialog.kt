package com.example.ui.dialogs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.GridEquipment
import com.example.data.model.MaintenanceRecord

@Composable
fun AddMaintenanceDialog(
    equipment: GridEquipment,
    onDismiss: () -> Unit,
    onSave: (MaintenanceRecord) -> Unit
) {
    var maintenanceType by remember { mutableStateOf("Bảo dưỡng định kỳ lưới điện") }
    var workUnit by remember { mutableStateOf("Đội Quản lý Vận hành & Sửa chữa") }
    var content by remember { mutableStateOf("Vệ sinh hotline cách điện, kiểm tra xiết lực bulông đầu cốt, đo điện trở tiếp xúc và dòng rò.") }
    var partsReplaced by remember { mutableStateOf("Thay mới kẹp cực ép nhôm - đồng") }
    var outcome by remember { mutableStateOf("Đạt tiêu chuẩn vận hành an toàn") }
    var supervisor by remember { mutableStateOf("Trưởng đơn vị công tác") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Ghi Lịch Sử Bảo Dưỡng - ${equipment.code}", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = maintenanceType,
                    onValueChange = { maintenanceType = it },
                    label = { Text("Loại bảo dưỡng / Sửa chữa") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = workUnit,
                    onValueChange = { workUnit = it },
                    label = { Text("Đơn vị / Đội thực hiện") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Nội dung công việc thực hiện") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )

                OutlinedTextField(
                    value = partsReplaced,
                    onValueChange = { partsReplaced = it },
                    label = { Text("Linh kiện, phụ kiện đã thay thế") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = outcome,
                    onValueChange = { outcome = it },
                    label = { Text("Kết quả nghiệm thu") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = supervisor,
                    onValueChange = { supervisor = it },
                    label = { Text("Người giám sát / Chỉ huy trực tiếp") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (content.isNotBlank()) {
                        val record = MaintenanceRecord(
                            equipmentId = equipment.id,
                            equipmentCode = equipment.code,
                            maintenanceDate = System.currentTimeMillis(),
                            maintenanceType = maintenanceType,
                            workUnit = workUnit,
                            content = content,
                            partsReplaced = partsReplaced,
                            outcome = outcome,
                            supervisor = supervisor
                        )
                        onSave(record)
                    }
                },
                modifier = Modifier.testTag("save_maintenance_btn")
            ) {
                Text("Lưu nhật ký bảo dưỡng")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}
