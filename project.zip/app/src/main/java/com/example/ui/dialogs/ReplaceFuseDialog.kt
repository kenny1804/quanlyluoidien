package com.example.ui.dialogs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.GridEquipment

@Composable
fun ReplaceFuseDialog(
    equipment: GridEquipment,
    onDismiss: () -> Unit,
    onConfirm: (fuseType: String, fuseRating: String, notes: String) -> Unit
) {
    var fuseType by remember { mutableStateOf(if (equipment.fuseType.isNotBlank()) equipment.fuseType else "Type K") }
    var fuseRating by remember { mutableStateOf(if (equipment.fuseRating.isNotBlank()) equipment.fuseRating else "15K") }
    var notes by remember { mutableStateOf("Thay dây chì bảo vệ đúng trị số tính toán kỹ thuật theo công suất trạm.") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Thay Dây Chì - ${equipment.code}", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Thiết bị: ${equipment.name} (${equipment.poleNumber} - ${equipment.lineName})",
                    style = androidx.compose.material3.MaterialTheme.typography.bodyMedium
                )
                if (equipment.protectedCapacity.isNotBlank()) {
                    Text(
                        text = "Công suất TBA bảo vệ: ${equipment.protectedCapacity}",
                        style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                OutlinedTextField(
                    value = fuseType,
                    onValueChange = { fuseType = it },
                    label = { Text("Loại dây chì (Type K: nhanh / Type T: chậm)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = fuseRating,
                    onValueChange = { fuseRating = it },
                    label = { Text("Trị số chì định mức (ví dụ: 10K, 15K, 25K, 40K, 65K)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("fuse_rating_input")
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Ghi chú lý do thay / tình trạng chì cũ") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (fuseRating.isNotBlank()) {
                        onConfirm(fuseType, fuseRating, notes)
                    }
                },
                modifier = Modifier.testTag("confirm_fuse_replace_btn")
            ) {
                Text("Xác nhận thay chì")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}
