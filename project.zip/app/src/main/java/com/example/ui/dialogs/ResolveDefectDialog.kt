package com.example.ui.dialogs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.DefectRecord

@Composable
fun ResolveDefectDialog(
    defect: DefectRecord,
    onDismiss: () -> Unit,
    onConfirm: (resolvedBy: String, resolutionNotes: String) -> Unit
) {
    var resolvedBy by remember { mutableStateOf("Đội Sửa Chữa Hotline & Quản Lý Lưới") }
    var resolutionNotes by remember { mutableStateOf("Đã hoàn thành sửa chữa khắc phục, thay thế kẹp cực mới, xiết lực theo tiêu chuẩn, đo thử nghiệm đạt yêu cầu đóng điện vận hành an toàn.") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Xác Nhận Đã Khắc Phục Khiếm Khuyết", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Khiếm khuyết: ${defect.title}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                if (defect.equipmentCode != null) {
                    Text(
                        text = "Thiết bị: ${defect.equipmentCode}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                OutlinedTextField(
                    value = resolvedBy,
                    onValueChange = { resolvedBy = it },
                    label = { Text("Người / Đội thực hiện khắc phục") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = resolutionNotes,
                    onValueChange = { resolutionNotes = it },
                    label = { Text("Biên bản / Chi tiết nội dung đã thực hiện") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("resolution_notes_input"),
                    minLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (resolvedBy.isNotBlank() && resolutionNotes.isNotBlank()) {
                        onConfirm(resolvedBy, resolutionNotes)
                    }
                },
                modifier = Modifier.testTag("confirm_resolve_defect_btn")
            ) {
                Text("Đã khắc phục xong")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}
