package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.AssignedWorkTask
import com.example.data.model.WorkTaskStatus
import com.example.data.model.CorridorStatus
import com.example.data.model.DefectRecord
import com.example.data.model.DefectSeverity
import com.example.data.model.DefectStatus
import com.example.data.model.EquipmentStatus
import com.example.data.model.EquipmentType
import com.example.data.model.GridAlert
import com.example.data.model.AlertType
import com.example.data.model.AlertSeverity
import com.example.data.model.AlertActionType
import com.example.data.model.HazardRiskLevel
import com.example.data.model.GridEquipment
import com.example.data.model.MaintenanceRecord
import com.example.data.model.PeriodicInspection
import com.example.data.model.SafetyCorridorRecord
import com.example.data.model.InspectorProfile
import com.example.data.repository.GridRepository
import com.example.data.repository.InspectorProfileManager
import com.example.data.repository.SubstationManager
import com.example.util.SubstationLocation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.example.data.model.BackupHistoryItem
import com.example.util.BackupHistoryManager
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GridViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: GridRepository

    // Backup & Restore History State
    val backupHistory = MutableStateFlow<List<BackupHistoryItem>>(BackupHistoryManager.getHistory(application))
    val lastBackupTimestamp = MutableStateFlow<Long>(BackupHistoryManager.getLastBackupTime(application))
    val lastAutoBackupTimestamp = MutableStateFlow<Long>(BackupHistoryManager.getLastAutoBackupTime(application))

    init {
        val db = AppDatabase.getDatabase(application, viewModelScope)
        repository = GridRepository(db.gridDao())

        // Auto-Save feature: Tự động lưu bản snapshot sao lưu cục bộ vào storage định kỳ (mỗi 3 phút)
        // Toàn bộ việc serialize JSON (có thể chứa ảnh Base64) + ghi file được chuyển sang
        // Dispatchers.IO để KHÔNG chặn Main thread / gây giật UI hay ANR định kỳ.
        viewModelScope.launch {
            delay(15000L) // Chờ dữ liệu ban đầu nạp xong
            while (true) {
                try {
                    val count = allEquipments.value.size + allAssignedTasks.value.size + allDefects.value.size + allCorridors.value.size
                    if (count > 0) {
                        val app = getApplication<android.app.Application>()
                        // Đọc dữ liệu StateFlow (an toàn trên bất kỳ thread nào) nhưng đưa toàn bộ
                        // phần nặng (serialize JSON + ghi file) chạy nền trên Dispatchers.IO.
                        val equipmentsSnapshot = allEquipments.value
                        val tasksSnapshot = allAssignedTasks.value
                        val defectsSnapshot = allDefects.value
                        val corridorsSnapshot = allCorridors.value
                        val inspectionsSnapshot = allInspections.value
                        val maintenanceSnapshot = allMaintenanceRecords.value
                        withContext(Dispatchers.IO) {
                            val jsonState = com.example.util.GridJsonBackupHelper.exportToJson(
                                equipments = equipmentsSnapshot,
                                tasks = tasksSnapshot,
                                defects = defectsSnapshot,
                                corridors = corridorsSnapshot,
                                inspections = inspectionsSnapshot,
                                maintenance = maintenanceSnapshot
                            )
                            BackupHistoryManager.saveLocalAutoBackup(app, jsonState, count)
                        }
                        lastAutoBackupTimestamp.value = System.currentTimeMillis()
                        lastBackupTimestamp.value = System.currentTimeMillis()
                        backupHistory.value = withContext(Dispatchers.IO) { BackupHistoryManager.getHistory(app) }
                    }
                } catch (e: Exception) {
                    // Tránh crash trong background auto-save loop
                }
                delay(180_000L) // 3 phút / chu kỳ tự động lưu (Auto-Save)
            }
        }
    }

    // Repository flows
    val allEquipments: StateFlow<List<GridEquipment>> = repository.allEquipments.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allInspections: StateFlow<List<PeriodicInspection>> = repository.allInspections.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allMaintenanceRecords: StateFlow<List<MaintenanceRecord>> = repository.allMaintenanceRecords.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allDefects: StateFlow<List<DefectRecord>> = repository.allDefects.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allCorridors: StateFlow<List<SafetyCorridorRecord>> = repository.allCorridors.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allAssignedTasks: StateFlow<List<AssignedWorkTask>> = repository.allAssignedTasks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Convenience flow aliases
    val equipments: StateFlow<List<GridEquipment>> get() = allEquipments
    val inspections: StateFlow<List<PeriodicInspection>> get() = allInspections
    val maintenanceRecords: StateFlow<List<MaintenanceRecord>> get() = allMaintenanceRecords
    val defects: StateFlow<List<DefectRecord>> get() = allDefects
    val corridorRecords: StateFlow<List<SafetyCorridorRecord>> get() = allCorridors
    val assignedTasks: StateFlow<List<AssignedWorkTask>> get() = allAssignedTasks

    // Inspector Profile & Area Filter
    val inspectorProfile = MutableStateFlow(InspectorProfileManager.getProfile(application))
    val selectedArea = MutableStateFlow<String?>(null) // null = Tất cả khu vực / tuyến

    // Substations 110kV Management Flow
    val substations = MutableStateFlow<List<SubstationLocation>>(SubstationManager.getSubstations(application))

    // Filter states
    val searchQuery = MutableStateFlow("")
    val selectedType = MutableStateFlow<EquipmentType?>(null) // null = Tất cả
    val alertFilter = MutableStateFlow("ALL") // ALL, OVERDUE, DUE_SOON, DEFECTS

    // Filtered equipments flow
    val filteredEquipments: StateFlow<List<GridEquipment>> = combine(
        allEquipments,
        searchQuery,
        selectedType,
        alertFilter,
        selectedArea
    ) { equipments, query, type, alert, area ->
        val now = System.currentTimeMillis()
        val sevenDaysMs = 7 * 24 * 3600 * 1000L

        equipments.filter { eq ->
            // Filter by type
            val matchType = type == null || eq.type == type

            // Filter by area
            val matchArea = area.isNullOrBlank() ||
                eq.lineName.contains(area, ignoreCase = true) ||
                eq.substation.contains(area, ignoreCase = true)

            // Filter by search text (code, name, line, pole, manufacturer, fuse)
            val matchQuery = query.isBlank() ||
                eq.code.contains(query, ignoreCase = true) ||
                eq.name.contains(query, ignoreCase = true) ||
                eq.lineName.contains(query, ignoreCase = true) ||
                eq.poleNumber.contains(query, ignoreCase = true) ||
                eq.fuseRating.contains(query, ignoreCase = true) ||
                eq.substation.contains(query, ignoreCase = true)

            // Filter by alert
            val matchAlert = when (alert) {
                "OVERDUE" -> eq.nextInspectionDate in 1 until now || eq.nextMaintenanceDate in 1 until now
                "DUE_SOON" -> (eq.nextInspectionDate in now..(now + sevenDaysMs)) || (eq.nextMaintenanceDate in now..(now + sevenDaysMs * 2))
                "DEFECTS" -> eq.status == EquipmentStatus.DEFECT
                else -> true
            }

            matchType && matchArea && matchQuery && matchAlert
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Selected Equipment Details
    val selectedEquipmentId = MutableStateFlow<Long?>(null)

    val selectedEquipment: StateFlow<GridEquipment?> = selectedEquipmentId.flatMapLatest { id ->
        if (id != null) repository.getEquipmentById(id) else flowOf(null)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val selectedEquipmentInspections: StateFlow<List<PeriodicInspection>> = selectedEquipmentId.flatMapLatest { id ->
        if (id != null) repository.getInspectionsForEquipment(id) else flowOf(emptyList())
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val selectedEquipmentMaintenance: StateFlow<List<MaintenanceRecord>> = selectedEquipmentId.flatMapLatest { id ->
        if (id != null) repository.getMaintenanceForEquipment(id) else flowOf(emptyList())
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val selectedEquipmentDefects: StateFlow<List<DefectRecord>> = selectedEquipmentId.flatMapLatest { id ->
        if (id != null) repository.getDefectsForEquipment(id) else flowOf(emptyList())
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Alert statistics
    data class GridStats(
        val totalEquipments: Int = 0,
        val operationalEquipments: Int = 0,
        val warningEquipments: Int = 0,
        val defectEquipments: Int = 0,
        val overdueInspections: Int = 0,
        val dueSoonInspections: Int = 0,
        val activeDefects: Int = 0,
        val criticalDefects: Int = 0,
        val resolvedDefects: Int = 0,
        val activeCorridorHazards: Int = 0,
        val resolvedCorridorHazards: Int = 0,
        val recloserCount: Int = 0,
        val lbsCount: Int = 0,
        val dsCount: Int = 0,
        val laCount: Int = 0,
        val fcoCount: Int = 0,
        val lbfcoCount: Int = 0,
        val totalAssignedTasks: Int = 0,
        val activeAssignedTasks: Int = 0,
        val submittedAssignedTasks: Int = 0,
        val totalRecordedMissingItems: Int = 0
    )

    val gridStats: StateFlow<GridStats> = combine(
        allEquipments,
        allDefects,
        allCorridors,
        allAssignedTasks
    ) { equipments, defects, corridors, tasks ->
        val now = System.currentTimeMillis()
        val sevenDaysMs = 7 * 24 * 3600 * 1000L

        val overdue = equipments.count { it.nextInspectionDate in 1 until now }
        val dueSoon = equipments.count { it.nextInspectionDate in now..(now + sevenDaysMs) }
        val operational = equipments.count { it.status == EquipmentStatus.OPERATIONAL }
        val warning = equipments.count { it.status == EquipmentStatus.WARNING }
        val defectCount = equipments.count { it.status == EquipmentStatus.DEFECT }
        val activeDef = defects.count { it.status != DefectStatus.RESOLVED }
        val criticalDef = defects.count { it.status != DefectStatus.RESOLVED && it.severity == DefectSeverity.CRITICAL }
        val resolvedDef = defects.count { it.status == DefectStatus.RESOLVED }
        val activeCorridor = corridors.count { it.status != CorridorStatus.RESOLVED }
        val resolvedCorridor = corridors.count { it.status == CorridorStatus.RESOLVED }

        val totalTasks = tasks.size
        val activeTasks = tasks.count { it.status != WorkTaskStatus.SUBMITTED_QLVH }
        val submittedTasks = tasks.count { it.status == WorkTaskStatus.SUBMITTED_QLVH }
        val totalMissing = tasks.sumOf { it.recordedCount }

        GridStats(
            totalEquipments = equipments.size,
            operationalEquipments = operational,
            warningEquipments = warning,
            defectEquipments = defectCount,
            overdueInspections = overdue,
            dueSoonInspections = dueSoon,
            activeDefects = activeDef,
            criticalDefects = criticalDef,
            resolvedDefects = resolvedDef,
            activeCorridorHazards = activeCorridor,
            resolvedCorridorHazards = resolvedCorridor,
            recloserCount = equipments.count { it.type == EquipmentType.RECLOSER },
            lbsCount = equipments.count { it.type == EquipmentType.LBS },
            dsCount = equipments.count { it.type == EquipmentType.DS },
            laCount = equipments.count { it.type == EquipmentType.LA },
            fcoCount = equipments.count { it.type == EquipmentType.FCO },
            lbfcoCount = equipments.count { it.type == EquipmentType.LBFCO },
            totalAssignedTasks = totalTasks,
            activeAssignedTasks = activeTasks,
            submittedAssignedTasks = submittedTasks,
            totalRecordedMissingItems = totalMissing
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = GridStats()
    )

    // Hệ thống Cảnh Báo Tự Động cho các thiết bị lưới điện (Recloser, LBS, DS, LA, FCO, LBFCO)
    val automatedAlerts: StateFlow<List<GridAlert>> = combine(
        allEquipments,
        allDefects,
        allMaintenanceRecords,
        allCorridors
    ) { equipments, defects, maintenance, corridors ->
        val now = System.currentTimeMillis()
        val sevenDaysMs = 7 * 24 * 3600 * 1000L
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val alerts = mutableListOf<GridAlert>()

        // 1. Cảnh báo kiểm tra định kỳ
        equipments.forEach { eq ->
            if (eq.nextInspectionDate in 1 until now) {
                val overdueDays = ((now - eq.nextInspectionDate) / (24 * 3600 * 1000L)).toInt().coerceAtLeast(1)
                alerts.add(
                    GridAlert(
                        id = "insp_overdue_${eq.id}",
                        equipmentId = eq.id,
                        equipmentCode = eq.code,
                        equipmentName = eq.name,
                        equipmentType = eq.type,
                        lineName = eq.lineName,
                        poleNumber = eq.poleNumber,
                        alertType = AlertType.PERIODIC_INSPECTION_OVERDUE,
                        severity = AlertSeverity.CRITICAL,
                        title = "Quá hạn kiểm tra định kỳ ($overdueDays ngày)",
                        description = "Thiết bị ${eq.code} (${eq.type.displayName}) tại ${eq.lineName} - ${eq.poleNumber} đã quá hạn kiểm tra định kỳ $overdueDays ngày.",
                        details = "Chu kỳ: ${eq.inspectionIntervalDays} ngày/lần. Hạn chót: ${dateFormat.format(Date(eq.nextInspectionDate))}",
                        timestamp = eq.nextInspectionDate,
                        recommendedAction = "Ghi phiếu kiểm tra",
                        actionType = AlertActionType.INSPECT
                    )
                )
            } else if (eq.nextInspectionDate in now..(now + sevenDaysMs)) {
                val daysLeft = ((eq.nextInspectionDate - now) / (24 * 3600 * 1000L)).toInt().coerceAtLeast(0)
                alerts.add(
                    GridAlert(
                        id = "insp_due_soon_${eq.id}",
                        equipmentId = eq.id,
                        equipmentCode = eq.code,
                        equipmentName = eq.name,
                        equipmentType = eq.type,
                        lineName = eq.lineName,
                        poleNumber = eq.poleNumber,
                        alertType = AlertType.PERIODIC_INSPECTION_DUE_SOON,
                        severity = AlertSeverity.WARNING,
                        title = "Sắp đến hạn kiểm tra định kỳ ($daysLeft ngày)",
                        description = "Thiết bị ${eq.code} sẽ đến hạn kiểm tra định kỳ trong $daysLeft ngày tới. Cần bố trí lịch công tác.",
                        details = "Hạn kiểm tra: ${dateFormat.format(Date(eq.nextInspectionDate))}",
                        timestamp = eq.nextInspectionDate,
                        recommendedAction = "Lập kế hoạch kiểm tra",
                        actionType = AlertActionType.INSPECT
                    )
                )
            }

            // 2. Cảnh báo bảo dưỡng theo lịch hoặc số lần thao tác
            if (eq.nextMaintenanceDate in 1 until now) {
                alerts.add(
                    GridAlert(
                        id = "maint_overdue_${eq.id}",
                        equipmentId = eq.id,
                        equipmentCode = eq.code,
                        equipmentName = eq.name,
                        equipmentType = eq.type,
                        lineName = eq.lineName,
                        poleNumber = eq.poleNumber,
                        alertType = AlertType.MAINTENANCE_DUE,
                        severity = AlertSeverity.CRITICAL,
                        title = "Đến hạn bảo dưỡng định kỳ",
                        description = "Thiết bị ${eq.code} đã tới chu kỳ bảo dưỡng, thí nghiệm định kỳ (${eq.maintenanceIntervalDays} ngày).",
                        details = "Hạn bảo dưỡng: ${dateFormat.format(Date(eq.nextMaintenanceDate))}",
                        timestamp = eq.nextMaintenanceDate,
                        recommendedAction = "Tạo phiếu bảo dưỡng",
                        actionType = AlertActionType.MAINTAIN
                    )
                )
            } else if (eq.surgeCounter >= 30) {
                alerts.add(
                    GridAlert(
                        id = "op_count_${eq.id}",
                        equipmentId = eq.id,
                        equipmentCode = eq.code,
                        equipmentName = eq.name,
                        equipmentType = eq.type,
                        lineName = eq.lineName,
                        poleNumber = eq.poleNumber,
                        alertType = AlertType.MAINTENANCE_OPERATION_COUNT,
                        severity = if (eq.surgeCounter >= 45) AlertSeverity.CRITICAL else AlertSeverity.WARNING,
                        title = "Số lần đóng cắt / cắt sét cao (${eq.surgeCounter} lần)",
                        description = "Bộ đếm của ${eq.code} ghi nhận ${eq.surgeCounter} lần thao tác/cắt sét. Cần kiểm tra buồng dập hồ quang & tiếp điểm.",
                        details = "Ngưỡng cảnh báo đại tu: >= 30 lần",
                        timestamp = now,
                        recommendedAction = "Bảo dưỡng buồng dập hồ quang",
                        actionType = AlertActionType.MAINTAIN
                    )
                )
            }

            // 3. Cảnh báo dây chì FCO / LBFCO
            if (eq.type in listOf(EquipmentType.FCO, EquipmentType.LBFCO)) {
                if (eq.fuseRating.isBlank()) {
                    alerts.add(
                        GridAlert(
                            id = "fuse_missing_${eq.id}",
                            equipmentId = eq.id,
                            equipmentCode = eq.code,
                            equipmentName = eq.name,
                            equipmentType = eq.type,
                            lineName = eq.lineName,
                            poleNumber = eq.poleNumber,
                            alertType = AlertType.FUSE_CHECK_NEEDED,
                            severity = AlertSeverity.WARNING,
                            title = "Chưa cập nhật thông số chì FCO/LBFCO",
                            description = "Thiết bị ${eq.code} bảo vệ TBA ${eq.protectedCapacity.ifBlank { "chưa rõ" }} chưa có thông tin trị số dây chì định mức.",
                            details = "Cần phối hợp rà soát trị số dòng chì bảo vệ theo công suất máy biến áp.",
                            timestamp = now,
                            recommendedAction = "Cập nhật chì",
                            actionType = AlertActionType.REPLACE_FUSE
                        )
                    )
                }
            }
        }

        // 4. Cảnh báo khiếm khuyết đang tồn tại
        defects.filter { it.status != DefectStatus.RESOLVED }.forEach { defect ->
            val eq = equipments.find { it.id == defect.equipmentId || (defect.equipmentCode != null && it.code == defect.equipmentCode) }
            val eqCode = eq?.code ?: defect.equipmentCode ?: "T/Bị"
            val eqName = eq?.name ?: defect.title
            val eqType = eq?.type ?: EquipmentType.DS
            val line = eq?.lineName ?: "Đường dây trung thế"
            val pole = eq?.poleNumber ?: "Cột điện"

            alerts.add(
                GridAlert(
                    id = "defect_${defect.id}",
                    equipmentId = defect.equipmentId ?: (eq?.id ?: 0L),
                    equipmentCode = eqCode,
                    equipmentName = eqName,
                    equipmentType = eqType,
                    lineName = line,
                    poleNumber = pole,
                    alertType = if (defect.severity == DefectSeverity.CRITICAL) AlertType.ACTIVE_DEFECT_CRITICAL else AlertType.ACTIVE_DEFECT_NORMAL,
                    severity = when (defect.severity) {
                        DefectSeverity.CRITICAL -> AlertSeverity.CRITICAL
                        DefectSeverity.MAJOR -> AlertSeverity.CRITICAL
                        DefectSeverity.MINOR -> AlertSeverity.WARNING
                        DefectSeverity.MONITOR -> AlertSeverity.INFO
                    },
                    title = "[${defect.severity.label}] ${defect.title}",
                    description = defect.description,
                    details = "Phát hiện: ${dateFormat.format(Date(defect.reportedDate))} bởi ${defect.reportedBy}. BP: ${defect.actionPlan ?: "Đang lập phương án"}",
                    timestamp = defect.reportedDate,
                    recommendedAction = "Khắc phục sự cố",
                    actionType = AlertActionType.RESOLVE_DEFECT
                )
            )
        }

        // 5. Cảnh báo vi phạm hành lang an toàn (Cây xanh, nhà cửa)
        corridors.filter { it.status != CorridorStatus.RESOLVED }.forEach { corridor ->
            val matchingEq = equipments.find { it.lineName.contains(corridor.lineName, ignoreCase = true) }
            alerts.add(
                GridAlert(
                    id = "corridor_${corridor.id}",
                    equipmentId = matchingEq?.id ?: 0L,
                    equipmentCode = matchingEq?.code ?: corridor.spanLocation,
                    equipmentName = "Hành lang ${corridor.lineName} (${corridor.hazardType.label})",
                    equipmentType = matchingEq?.type ?: EquipmentType.DS,
                    lineName = corridor.lineName,
                    poleNumber = corridor.spanLocation,
                    alertType = AlertType.CORRIDOR_VIOLATION,
                    severity = when (corridor.riskLevel) {
                        HazardRiskLevel.HIGH -> AlertSeverity.CRITICAL
                        HazardRiskLevel.MEDIUM -> AlertSeverity.WARNING
                        HazardRiskLevel.LOW -> AlertSeverity.INFO
                    },
                    title = "Vi phạm hành lang: ${corridor.hazardType.label} tại ${corridor.spanLocation}",
                    description = "${corridor.description} - Khoảng cách: ${corridor.currentDistance}",
                    details = "Tuyến: ${corridor.lineName} • Mức rủi ro: ${corridor.riskLevel.label} • Tình trạng: ${corridor.status.label}",
                    timestamp = corridor.discoveredDate,
                    recommendedAction = "Giải tỏa an toàn",
                    actionType = AlertActionType.RESOLVE_CORRIDOR
                )
            )
        }

        // Sắp xếp theo mức độ nghiêm trọng: CRITICAL -> WARNING -> INFO, sau đó theo thời gian
        alerts.sortedWith(
            compareBy<GridAlert> {
                when (it.severity) {
                    AlertSeverity.CRITICAL -> 0
                    AlertSeverity.WARNING -> 1
                    AlertSeverity.INFO -> 2
                }
            }.thenByDescending { it.timestamp }
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // --- Action Methods ---

    private var lastDownloadBackupTime = 0L

    private fun triggerAutoBackupToDownloads() {
        val now = System.currentTimeMillis()
        // Chỉ ghi file tải về tối đa 1 lần mỗi phút để tránh làm đầy thư mục Downloads khi thao tác liên tục
        if (now - lastDownloadBackupTime < 60_000) return 
        lastDownloadBackupTime = now

        viewModelScope.launch {
            try {
                // Đợi 1 chút để DB flow kịp emit dữ liệu mới nhất
                kotlinx.coroutines.delay(1000)
                // Lấy snapshot state trước (an toàn ở bất kỳ dispatcher nào), rồi đẩy toàn bộ
                // phần nặng (serialize JSON + ghi file Downloads) sang Dispatchers.IO để không
                // chặn Main thread mỗi khi người dùng lưu/sửa/xóa một bản ghi bất kỳ trong app.
                val equipmentsSnapshot = allEquipments.value
                val tasksSnapshot = allAssignedTasks.value
                val defectsSnapshot = allDefects.value
                val corridorsSnapshot = allCorridors.value
                val inspectionsSnapshot = allInspections.value
                val maintenanceSnapshot = allMaintenanceRecords.value
                val context = getApplication<android.app.Application>()

                withContext(Dispatchers.IO) {
                    val jsonStr = com.example.util.GridJsonBackupHelper.exportToJson(
                        equipments = equipmentsSnapshot,
                        tasks = tasksSnapshot,
                        defects = defectsSnapshot,
                        corridors = corridorsSnapshot,
                        inspections = inspectionsSnapshot,
                        maintenance = maintenanceSnapshot
                    )
                    val timeStr = java.text.SimpleDateFormat("yyyyMMdd_HHmm", java.util.Locale.getDefault()).format(java.util.Date())
                    val exactFilename = "QLVH_Backup_$timeStr.json"

                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        val contentValues = android.content.ContentValues().apply {
                            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, exactFilename)
                            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/json")
                            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS + "/QLVH_AutoBackup")
                        }
                        val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                        if (uri != null) {
                            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                                outputStream.write(jsonStr.toByteArray(Charsets.UTF_8))
                            }
                        }
                    } else {
                        val dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                        val appDir = java.io.File(dir, "QLVH_AutoBackup")
                        if (!appDir.exists()) appDir.mkdirs()
                        val file = java.io.File(appDir, exactFilename)
                        file.writeText(jsonStr, Charsets.UTF_8)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun saveEquipment(equipment: GridEquipment) {
        viewModelScope.launch {
            if (equipment.id == 0L) {
                val oneDayMs = 24 * 3600 * 1000L
                val now = System.currentTimeMillis()
                val nextInsp = if (equipment.nextInspectionDate == 0L) {
                    now + equipment.inspectionIntervalDays * oneDayMs
                } else equipment.nextInspectionDate

                val nextMaint = if (equipment.nextMaintenanceDate == 0L) {
                    now + equipment.maintenanceIntervalDays * oneDayMs
                } else equipment.nextMaintenanceDate

                repository.insertEquipment(
                    equipment.copy(
                        lastInspectionDate = if (equipment.lastInspectionDate == 0L) now else equipment.lastInspectionDate,
                        nextInspectionDate = nextInsp,
                        lastMaintenanceDate = if (equipment.lastMaintenanceDate == 0L) now else equipment.lastMaintenanceDate,
                        nextMaintenanceDate = nextMaint
                    )
                )
            } else {
                repository.updateEquipment(equipment)
            }
            triggerAutoBackupToDownloads()
        }
    }

    fun deleteEquipment(equipment: GridEquipment) {
        viewModelScope.launch {
            repository.deleteEquipment(equipment)
            if (selectedEquipmentId.value == equipment.id) {
                selectedEquipmentId.value = null
            }
            triggerAutoBackupToDownloads()
        }
    }

    fun addInspection(inspection: PeriodicInspection) {
        viewModelScope.launch {
            repository.insertInspection(inspection)
            // Cập nhật lại lịch kiểm tra tiếp theo của thiết bị tương ứng
            val equipment = allEquipments.value.find { it.id == inspection.equipmentId }
            if (equipment != null) {
                val oneDayMs = 24 * 3600 * 1000L
                val newNextDate = inspection.inspectionDate + equipment.inspectionIntervalDays * oneDayMs
                val updatedStatus = if (inspection.resultStatus.contains("khiếm khuyết", ignoreCase = true)) {
                    EquipmentStatus.DEFECT
                } else {
                    EquipmentStatus.OPERATIONAL
                }
                repository.updateEquipment(
                    equipment.copy(
                        lastInspectionDate = inspection.inspectionDate,
                        nextInspectionDate = newNextDate,
                        status = updatedStatus
                    )
                )
            }
            triggerAutoBackupToDownloads()
        }
    }

    fun addMaintenance(record: MaintenanceRecord) {
        viewModelScope.launch {
            repository.insertMaintenance(record)
            val equipment = allEquipments.value.find { it.id == record.equipmentId }
            if (equipment != null) {
                val oneDayMs = 24 * 3600 * 1000L
                val newNextMaintDate = record.maintenanceDate + equipment.maintenanceIntervalDays * oneDayMs
                repository.updateEquipment(
                    equipment.copy(
                        lastMaintenanceDate = record.maintenanceDate,
                        nextMaintenanceDate = newNextMaintDate,
                        status = EquipmentStatus.OPERATIONAL
                    )
                )
            }
            triggerAutoBackupToDownloads()
        }
    }

    fun replaceFuse(equipmentId: Long, fuseType: String, fuseRating: String, notes: String) {
        viewModelScope.launch {
            val equipment = allEquipments.value.find { it.id == equipmentId }
            if (equipment != null) {
                val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                val todayStr = sdf.format(Date())
                repository.updateEquipment(
                    equipment.copy(
                        fuseType = fuseType,
                        fuseRating = fuseRating,
                        fuseReplacedDate = todayStr,
                        notes = if (notes.isNotBlank()) "${equipment.notes}\n[Thay chì $todayStr]: $notes" else equipment.notes
                    )
                )
            }
            triggerAutoBackupToDownloads()
        }
    }

    fun saveDefect(defect: DefectRecord) {
        viewModelScope.launch {
            if (defect.id == 0L) {
                repository.insertDefect(defect)
                // Cập nhật trạng thái thiết bị thành CÓ KHIẾM KHUYẾT
                defect.equipmentId?.let { eqId ->
                    val eq = allEquipments.value.find { it.id == eqId }
                    if (eq != null && eq.status != EquipmentStatus.DEFECT) {
                        repository.updateEquipment(eq.copy(status = EquipmentStatus.DEFECT))
                    }
                }
            } else {
                repository.updateDefect(defect)
            }
            triggerAutoBackupToDownloads()
        }
    }

    fun resolveDefect(defectId: Long, resolvedBy: String, resolutionNotes: String) {
        viewModelScope.launch {
            val defect = allDefects.value.find { it.id == defectId }
            if (defect != null) {
                repository.updateDefect(
                    defect.copy(
                        status = DefectStatus.RESOLVED,
                        resolvedDate = System.currentTimeMillis(),
                        resolvedBy = resolvedBy,
                        resolutionNotes = resolutionNotes
                    )
                )
                // Kiểm tra xem thiết bị còn khiếm khuyết active nào khác không
                defect.equipmentId?.let { eqId ->
                    val remainingActive = allDefects.value.any { it.equipmentId == eqId && it.id != defectId && it.status != DefectStatus.RESOLVED }
                    if (!remainingActive) {
                        val eq = allEquipments.value.find { it.id == eqId }
                        if (eq != null) {
                            repository.updateEquipment(eq.copy(status = EquipmentStatus.OPERATIONAL))
                        }
                    }
                }
            }
            triggerAutoBackupToDownloads()
        }
    }

    fun saveCorridor(corridor: SafetyCorridorRecord) {
        viewModelScope.launch {
            if (corridor.id == 0L) {
                repository.insertCorridor(corridor)
            } else {
                repository.updateCorridor(corridor)
            }
            triggerAutoBackupToDownloads()
        }
    }

    fun resolveCorridor(corridorId: Long, clearedBy: String, clearanceAction: String) {
        viewModelScope.launch {
            val corridor = allCorridors.value.find { it.id == corridorId }
            if (corridor != null) {
                repository.updateCorridor(
                    corridor.copy(
                        status = CorridorStatus.RESOLVED,
                        clearedDate = System.currentTimeMillis(),
                        clearedBy = clearedBy,
                        clearanceActionTaken = clearanceAction
                    )
                )
            }
            triggerAutoBackupToDownloads()
        }
    }

    // Inspector Profile & Area Actions
    fun updateInspectorProfile(profile: InspectorProfile) {
        InspectorProfileManager.saveProfile(getApplication(), profile)
        inspectorProfile.value = profile
    }

    // --- Substation 110kV CRUD & Lock Management ---
    fun saveSubstation(sub: SubstationLocation) {
        val current = substations.value.toMutableList()
        val index = current.indexOfFirst { it.id == sub.id }
        if (index >= 0) {
            current[index] = sub
        } else {
            val newId = if (sub.id != 0L) sub.id else System.currentTimeMillis()
            current.add(sub.copy(id = newId))
        }
        SubstationManager.saveSubstations(getApplication(), current)
        substations.value = current
        triggerAutoBackupToDownloads()
    }

    fun updateSubstationCoordinates(subId: Long, newLat: Double, newLng: Double) {
        val current = substations.value.toMutableList()
        val index = current.indexOfFirst { it.id == subId }
        if (index >= 0) {
            val item = current[index]
            if (item.isLocked) return // Không di chuyển nếu đang khóa
            current[index] = item.copy(latitude = newLat, longitude = newLng)
            SubstationManager.saveSubstations(getApplication(), current)
            substations.value = current
            triggerAutoBackupToDownloads()
        }
    }

    fun toggleLockSubstation(subId: Long) {
        val current = substations.value.toMutableList()
        val index = current.indexOfFirst { it.id == subId }
        if (index >= 0) {
            val item = current[index]
            current[index] = item.copy(isLocked = !item.isLocked)
            SubstationManager.saveSubstations(getApplication(), current)
            substations.value = current
            triggerAutoBackupToDownloads()
        }
    }

    fun deleteSubstation(subId: Long): Boolean {
        val current = substations.value.toMutableList()
        val item = current.find { it.id == subId } ?: return false
        if (item.isLocked) return false // Trạm bị khóa không cho xóa
        current.removeAll { it.id == subId }
        SubstationManager.saveSubstations(getApplication(), current)
        substations.value = current
        triggerAutoBackupToDownloads()
        return true
    }

    fun setAreaFilter(area: String?) {
        selectedArea.value = if (area.isNullOrBlank() || area == "Tất cả") null else area
    }

    fun updateEquipmentBulkStatus(ids: Set<Long>, newStatus: EquipmentStatus) {
        viewModelScope.launch {
            if (ids.isNotEmpty()) {
                repository.updateEquipmentStatusByIds(ids.toList(), newStatus)
                triggerAutoBackupToDownloads()
            }
        }
    }

    fun exportDatabaseToJson(): String {
        val totalCount = allEquipments.value.size + allAssignedTasks.value.size + allDefects.value.size + allCorridors.value.size
        val jsonStr = com.example.util.GridJsonBackupHelper.exportToJson(
            equipments = allEquipments.value,
            tasks = allAssignedTasks.value,
            defects = allDefects.value,
            corridors = allCorridors.value,
            inspections = allInspections.value,
            maintenance = allMaintenanceRecords.value
        )
        // Ghi nhận lịch sử Export
        BackupHistoryManager.recordAction(
            context = getApplication(),
            actionType = "EXPORT",
            description = "Xuất file dữ liệu JSON dự phòng toàn hệ thống",
            itemCount = totalCount,
            success = true
        )
        lastBackupTimestamp.value = System.currentTimeMillis()
        backupHistory.value = BackupHistoryManager.getHistory(getApplication())
        return jsonStr
    }

    fun importDatabaseFromJson(jsonString: String, onSuccess: (itemCount: Int) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                val backup = com.example.util.GridJsonBackupHelper.parseFromJson(jsonString)
                repository.importAllData(
                    equipments = backup.equipments,
                    tasks = backup.tasks,
                    defects = backup.defects,
                    corridors = backup.corridors,
                    inspections = backup.inspections,
                    maintenance = backup.maintenance
                )
                val totalCount = backup.equipments.size + backup.tasks.size + backup.defects.size + backup.corridors.size
                // Ghi nhận lịch sử Import
                BackupHistoryManager.recordAction(
                    context = getApplication(),
                    actionType = "IMPORT",
                    description = "Phục hồi dữ liệu từ tệp JSON sao lưu",
                    itemCount = totalCount,
                    success = true
                )
                lastBackupTimestamp.value = System.currentTimeMillis()
                backupHistory.value = BackupHistoryManager.getHistory(getApplication())
                onSuccess(totalCount)
            } catch (e: Exception) {
                BackupHistoryManager.recordAction(
                    context = getApplication(),
                    actionType = "IMPORT",
                    description = "Thất bại khi phục hồi dữ liệu từ JSON: ${e.message}",
                    itemCount = 0,
                    success = false
                )
                backupHistory.value = BackupHistoryManager.getHistory(getApplication())
                onError(e.localizedMessage ?: "Lỗi khi nạp file sao lưu JSON")
            }
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllData()
            selectedEquipmentId.value = null
        }
    }

    fun restoreSampleData() {
        viewModelScope.launch {
            val db = AppDatabase.getDatabase(getApplication(), viewModelScope)
            AppDatabase.populateInitialData(db.gridDao())
        }
    }

    // Format Báo Cáo Chuẩn Ngành Điện Lực
    fun generateExecutiveReport(): String {
        val stats = gridStats.value
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val dateStr = sdf.format(Date())

        val sb = StringBuilder()
        sb.appendLine("====================================================")
        sb.appendLine("TẬP ĐOÀN ĐIỆN LỰC VIỆT NAM - CÔNG TY ĐIỆN LỰC")
        sb.appendLine("BÁO CÁO QUẢN LÝ VẬN HÀNH THIẾT BỊ LƯỚI ĐIỆN")
        sb.appendLine("Thời điểm xuất báo cáo: $dateStr")
        sb.appendLine("====================================================")
        sb.appendLine()
        sb.appendLine("I. TỔNG HỢP THỐNG KÊ THIẾT BỊ LƯỚI ĐIỆN")
        sb.appendLine("- Tổng số thiết bị quản lý: ${stats.totalEquipments} thiết bị")
        sb.appendLine("  + Recloser (Máy cắt tự đóng lại): ${stats.recloserCount}")
        sb.appendLine("  + LBS (Cầu dao phụ tải): ${stats.lbsCount}")
        sb.appendLine("  + DS (Cầu dao cách ly): ${stats.dsCount}")
        sb.appendLine("  + LA (Chống sét van): ${stats.laCount}")
        sb.appendLine("  + FCO (Cầu chì tự rơi): ${stats.fcoCount}")
        sb.appendLine("  + LBFCO (Cầu chì cắt có tải): ${stats.lbfcoCount}")
        sb.appendLine()
        sb.appendLine("II. TÌNH HÌNH KIỂM TRA ĐỊNH KỲ & CẢNH BÁO ĐẾN HẠN")
        sb.appendLine("- Thiết bị QUÁ HẠN kiểm tra định kỳ: ${stats.overdueInspections} thiết bị (Cần xử lý khẩn)")
        sb.appendLine("- Thiết bị SẮP ĐẾN HẠN (trong 7 ngày tới): ${stats.dueSoonInspections} thiết bị")
        sb.appendLine()
        sb.appendLine("III. QUẢN LÝ KHIẾM KHUYẾT THIẾT BỊ")
        sb.appendLine("- Tổng số khiếm khuyết đang tồn tại: ${stats.activeDefects}")
        sb.appendLine("  + Khiếm khuyết Khẩn cấp (Nguy cơ sự cố): ${stats.criticalDefects}")
        sb.appendLine("- Khiếm khuyết đã khắc phục hoàn thành: ${stats.resolvedDefects}")
        sb.appendLine()
        sb.appendLine("IV. QUẢN LÝ HÀNH LANG AN TOÀN LƯỚI ĐIỆN (CÂY XANH, CÔNG TRÌNH)")
        sb.appendLine("- Điểm vi phạm hành lang đang tồn tại: ${stats.activeCorridorHazards}")
        sb.appendLine("- Điểm đã phát quang / giải tỏa an toàn: ${stats.resolvedCorridorHazards}")
        sb.appendLine()
        sb.appendLine("V. DANH SÁCH THIẾT BỊ CẦN CHÚ Ý ĐẶC BIỆT")
        allEquipments.value.filter { it.nextInspectionDate in 1 until System.currentTimeMillis() || it.status == EquipmentStatus.DEFECT }.forEach { eq ->
            sb.appendLine("• [${eq.code}] ${eq.name} - ${eq.lineName} (${eq.poleNumber}): ${eq.status.label}")
        }
        sb.appendLine("====================================================")
        return sb.toString()
    }

    // --- Xử lý Công việc phân công & Thống kê báo cáo gửi QLVH ---
    fun saveAssignedTask(task: AssignedWorkTask) {
        viewModelScope.launch {
            if (task.id == 0L) {
                repository.insertAssignedTask(task)
            } else {
                repository.updateAssignedTask(task)
            }
        }
    }

    fun updateTaskStatistics(
        taskId: Long,
        recordedCount: Int,
        detailedStats: String,
        proposedRemedy: String
    ) {
        viewModelScope.launch {
            val existing = allAssignedTasks.value.find { it.id == taskId } ?: return@launch
            val updated = existing.copy(
                recordedCount = recordedCount,
                detailedStatistics = detailedStats,
                proposedRemedy = proposedRemedy,
                status = if (existing.status == WorkTaskStatus.NEW) WorkTaskStatus.IN_PROGRESS else existing.status
            )
            repository.updateAssignedTask(updated)
        }
    }

    fun submitTaskToQlvh(
        taskId: Long,
        recipient: String = "Tổ Kỹ thuật & Quản lý vận hành",
        additionalNotes: String = ""
    ) {
        viewModelScope.launch {
            val existing = allAssignedTasks.value.find { it.id == taskId } ?: return@launch
            val codeDate = SimpleDateFormat("yyMM", Locale.getDefault()).format(Date())
            val randomSuffix = (100..999).random()
            val generatedReportCode = existing.reportCode ?: "BC-QLVH-$codeDate-$randomSuffix"

            val updatedStats = if (additionalNotes.isNotBlank()) {
                if (existing.detailedStatistics.isNotBlank()) {
                    existing.detailedStatistics + "\n- Ghi chú gửi QLVH: $additionalNotes"
                } else {
                    "- Ghi chú gửi QLVH: $additionalNotes"
                }
            } else {
                existing.detailedStatistics
            }

            val updated = existing.copy(
                status = WorkTaskStatus.SUBMITTED_QLVH,
                submittedDate = System.currentTimeMillis(),
                reportCode = generatedReportCode,
                qlvhRecipient = recipient,
                detailedStatistics = updatedStats
            )
            repository.updateAssignedTask(updated)
        }
    }

    fun recallSubmittedTask(taskId: Long) {
        viewModelScope.launch {
            val existing = allAssignedTasks.value.find { it.id == taskId } ?: return@launch
            val updated = existing.copy(
                status = WorkTaskStatus.IN_PROGRESS
            )
            repository.updateAssignedTask(updated)
        }
    }

    fun deleteAssignedTask(task: AssignedWorkTask) {
        viewModelScope.launch {
            repository.deleteAssignedTask(task)
        }
    }

    fun generateWorkTaskReportText(task: AssignedWorkTask): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val dateSdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val nowStr = sdf.format(Date())
        val assignedDateStr = dateSdf.format(Date(task.assignedDate))
        val deadlineStr = task.deadlineDate?.let { dateSdf.format(Date(it)) } ?: "Không quy định"
        val submittedDateStr = task.submittedDate?.let { sdf.format(Date(it)) } ?: "Chưa gửi"

        val sb = StringBuilder()
        sb.appendLine("====================================================")
        sb.appendLine("TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM - EVN SPC")
        sb.appendLine("PHIẾU THỐNG KÊ BÁO CÁO CÔNG VIỆC CHUYÊN ĐỀ")
        sb.appendLine("Mã số phiếu: ${task.reportCode ?: "DỰ THẢO - CHƯA DUYỆT"}")
        sb.appendLine("Thời điểm xuất phiếu: $nowStr")
        sb.appendLine("====================================================")
        sb.appendLine()
        sb.appendLine("1. THÔNG TIN PHÂN CÔNG SỔ SÁCH:")
        sb.appendLine("- Tiêu đề công việc: ${task.title.uppercase(Locale.getDefault())}")
        sb.appendLine("- Phân loại: ${task.category}")
        sb.appendLine("- Mức độ ưu tiên: ${task.priority}")
        sb.appendLine("- Đơn vị/Bộ phận giao việc: ${task.assignedBy}")
        sb.appendLine("- Cán bộ được phân công: ${task.assignee}")
        sb.appendLine("- Tuyến đường dây / Xuất tuyến: ${task.lineName}")
        sb.appendLine("- Phạm vi / Vị trí cột: ${task.spanLocation}")
        sb.appendLine("- Quy mô rà soát: ${task.targetScope}")
        sb.appendLine("- Ngày giao: $assignedDateStr | Hạn hoàn thành: $deadlineStr")
        sb.appendLine()
        sb.appendLine("2. NỘI DUNG & CHỈ ĐẠO CÔNG VIỆC:")
        sb.appendLine(task.description.ifBlank { "Thực hiện rà soát, kiểm tra hiện trường theo kế hoạch phân công." })
        sb.appendLine()
        sb.appendLine("3. KẾT QUẢ THỐNG KÊ HIỆN TRƯỜNG:")
        sb.appendLine("- TỔNG SỐ LƯỢNG PHÁT HIỆN: ${task.recordedCount} ${task.unit}")
        sb.appendLine("- Chi tiết thống kê cụ thể:")
        if (task.detailedStatistics.isNotBlank()) {
            sb.appendLine(task.detailedStatistics)
        } else {
            sb.appendLine("(Chưa có số liệu thống kê chi tiết)")
        }
        sb.appendLine()
        sb.appendLine("4. ĐỀ XUẤT XỬ LÝ & VẬT TƯ DỰ TRÙ:")
        if (task.proposedRemedy.isNotBlank()) {
            sb.appendLine(task.proposedRemedy)
        } else {
            sb.appendLine("(Chưa ghi nhận đề xuất xử lý)")
        }
        sb.appendLine()
        sb.appendLine("5. TÌNH TRẠNG BÁO CÁO GỬI VỀ QLVH:")
        sb.appendLine("- Trạng thái: ${task.status.label.uppercase(Locale.getDefault())}")
        sb.appendLine("- Nơi nhận báo cáo: ${task.qlvhRecipient}")
        sb.appendLine("- Thời gian gửi về QLVH: $submittedDateStr")
        sb.appendLine("====================================================")
        return sb.toString()
    }
}
