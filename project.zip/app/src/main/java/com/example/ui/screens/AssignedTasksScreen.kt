package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PriorityHigh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AssignedWorkTask
import com.example.data.model.WorkTaskStatus
import com.example.ui.dialogs.TaskPdfReportDialog
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.SpcNavy
import com.example.ui.theme.StatusDangerRed
import com.example.ui.theme.StatusNormalGreen
import com.example.ui.theme.StatusWarningAmber
import com.example.ui.viewmodel.GridViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssignedTasksScreen(
    viewModel: GridViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val tasks by viewModel.allAssignedTasks.collectAsStateWithLifecycle()
    val inspectorProfile by viewModel.inspectorProfile.collectAsStateWithLifecycle()

    var statusFilter by remember { mutableStateOf<WorkTaskStatus?>(null) }
    var categoryFilter by remember { mutableStateOf<String?>(null) }

    var showAddDialog by remember { mutableStateOf(false) }
    var taskToUpdateStats by remember { mutableStateOf<AssignedWorkTask?>(null) }
    var taskToSubmitQlvh by remember { mutableStateOf<AssignedWorkTask?>(null) }
    var taskToDelete by remember { mutableStateOf<AssignedWorkTask?>(null) }

    val filteredTasks = tasks.filter { task ->
        val matchStatus = statusFilter == null || task.status == statusFilter
        val matchCat = categoryFilter == null || task.category == categoryFilter
        matchStatus && matchCat
    }

    val totalTasks = tasks.size
    val inProgressCount = tasks.count { it.status == WorkTaskStatus.IN_PROGRESS || it.status == WorkTaskStatus.NEW }
    val submittedCount = tasks.count { it.status == WorkTaskStatus.SUBMITTED_QLVH }
    val totalRecordedItems = tasks.sumOf { it.recordedCount }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Công Việc Phân Công Báo Cáo",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = Color.White
                        )
                        Text(
                            text = "Sổ phân công cá nhân • Báo cáo chuyên đề gửi QLVH",
                            fontSize = 11.sp,
                            color = Color(0xFFFFF9C4)
                        )
                    }
                },
                actions = {
                    Button(
                        onClick = { showAddDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("btn_add_assigned_task")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ghi nhận việc", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SpcNavy)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = SpcNavy,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_assigned_task")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Thêm công việc phân công")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // KPI Cards Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Tổng số việc
                TaskKpiCard(
                    title = "Tổng việc",
                    count = "$totalTasks",
                    subtitle = "Được giao",
                    color = ElectricBlue,
                    modifier = Modifier.weight(1f)
                )

                // Đang thống kê
                TaskKpiCard(
                    title = "Đang làm",
                    count = "$inProgressCount",
                    subtitle = "Chưa gửi",
                    color = StatusWarningAmber,
                    modifier = Modifier.weight(1f)
                )

                // Đã gửi QLVH
                TaskKpiCard(
                    title = "Đã gửi QLVH",
                    count = "$submittedCount",
                    subtitle = "Đã báo cáo",
                    color = StatusNormalGreen,
                    modifier = Modifier.weight(1f)
                )

                // Số lượng phát hiện (vd: tiếp địa mất)
                TaskKpiCard(
                    title = "Phát hiện",
                    count = "$totalRecordedItems",
                    subtitle = "Vị trí/điểm",
                    color = StatusDangerRed,
                    modifier = Modifier.weight(1f)
                )
            }

            // Filter Chips Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = statusFilter == null && categoryFilter == null,
                    onClick = {
                        statusFilter = null
                        categoryFilter = null
                    },
                    label = { Text("Tất cả ($totalTasks)") }
                )

                FilterChip(
                    selected = statusFilter == WorkTaskStatus.IN_PROGRESS,
                    onClick = {
                        statusFilter = if (statusFilter == WorkTaskStatus.IN_PROGRESS) null else WorkTaskStatus.IN_PROGRESS
                    },
                    label = { Text("Đang làm ($inProgressCount)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = StatusWarningAmber.copy(alpha = 0.2f),
                        selectedLabelColor = Color(0xFFE65100)
                    )
                )

                FilterChip(
                    selected = statusFilter == WorkTaskStatus.SUBMITTED_QLVH,
                    onClick = {
                        statusFilter = if (statusFilter == WorkTaskStatus.SUBMITTED_QLVH) null else WorkTaskStatus.SUBMITTED_QLVH
                    },
                    label = { Text("Đã gửi QLVH ($submittedCount)") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = StatusNormalGreen.copy(alpha = 0.2f),
                        selectedLabelColor = Color(0xFF1B5E20)
                    )
                )

                FilterChip(
                    selected = categoryFilter == "Tiếp địa & Nối đất",
                    onClick = {
                        categoryFilter = if (categoryFilter == "Tiếp địa & Nối đất") null else "Tiếp địa & Nối đất"
                    },
                    label = { Text("⚡ Tiếp địa & Nối đất") }
                )

                FilterChip(
                    selected = categoryFilter == "Biển báo an toàn",
                    onClick = {
                        categoryFilter = if (categoryFilter == "Biển báo an toàn") null else "Biển báo an toàn"
                    },
                    label = { Text("⚠️ Biển báo an toàn") }
                )

                FilterChip(
                    selected = categoryFilter == "Phụ kiện xà sứ",
                    onClick = {
                        categoryFilter = if (categoryFilter == "Phụ kiện xà sứ") null else "Phụ kiện xà sứ"
                    },
                    label = { Text("🔧 Phụ kiện xà sứ") }
                )
            }

            // Task List
            if (filteredTasks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.AssignmentTurnedIn,
                            contentDescription = null,
                            modifier = Modifier.size(56.dp),
                            tint = Color.Gray
                        )
                        Text(
                            text = "Chưa có công việc phân công nào phù hợp",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Bấm 'Ghi nhận việc' để lập sổ theo dõi các nhiệm vụ kiểm tra làm thêm (ví dụ: thống kê tiếp địa bị mất, biển báo hư hỏng...).",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredTasks, key = { it.id }) { task ->
                        AssignedTaskItemCard(
                            task = task,
                            onUpdateStats = { taskToUpdateStats = task },
                            onSubmitQlvh = { taskToSubmitQlvh = task },
                            onRecall = {
                                viewModel.recallSubmittedTask(task.id)
                                Toast.makeText(context, "Đã thu hồi báo cáo về trạng thái đang thực hiện", Toast.LENGTH_SHORT).show()
                            },
                            onShare = {
                                val reportText = viewModel.generateWorkTaskReportText(task)
                                shareReportText(context, reportText)
                            },
                            onCopy = {
                                val reportText = viewModel.generateWorkTaskReportText(task)
                                copyToClipboard(context, reportText)
                            },
                            onDelete = { taskToDelete = task }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(72.dp))
                    }
                }
            }
        }
    }

    // Dialogs
    if (showAddDialog) {
        AddAssignedTaskDialog(
            defaultAssignee = inspectorProfile.inspectorName,
            onDismiss = { showAddDialog = false },
            onConfirm = { newTask ->
                viewModel.saveAssignedTask(newTask)
                showAddDialog = false
                Toast.makeText(context, "Đã thêm công việc phân công mới!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    taskToUpdateStats?.let { task ->
        UpdateTaskStatsDialog(
            task = task,
            onDismiss = { taskToUpdateStats = null },
            onConfirm = { count, details, remedy ->
                viewModel.updateTaskStatistics(task.id, count, details, remedy)
                taskToUpdateStats = null
                Toast.makeText(context, "Đã cập nhật số liệu thống kê hiện trường!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    taskToSubmitQlvh?.let { task ->
        TaskPdfReportDialog(
            task = task,
            onDismiss = { taskToSubmitQlvh = null },
            onSubmittedToQlvh = { recipient, notes ->
                viewModel.submitTaskToQlvh(task.id, recipient, notes)
                taskToSubmitQlvh = null
                Toast.makeText(context, "ĐÃ GỬI BÁO CÁO VỀ QLVH THÀNH CÔNG!", Toast.LENGTH_LONG).show()
            }
        )
    }

    taskToDelete?.let { task ->
        AlertDialog(
            onDismissRequest = { taskToDelete = null },
            title = { Text("Xác nhận xóa công việc", fontWeight = FontWeight.Bold) },
            text = { Text("Bạn có chắc chắn muốn xóa sổ theo dõi công việc '${task.title}' không?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAssignedTask(task)
                        taskToDelete = null
                        Toast.makeText(context, "Đã xóa công việc", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDangerRed)
                ) {
                    Text("Xóa", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { taskToDelete = null }) {
                    Text("Hủy")
                }
            }
        )
    }
}

@Composable
private fun TaskKpiCard(
    title: String,
    count: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.08f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.25f))
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontSize = 10.sp, color = color, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(count, fontSize = 18.sp, color = color, fontWeight = FontWeight.ExtraBold)
            Text(subtitle, fontSize = 9.sp, color = Color.Gray, maxLines = 1)
        }
    }
}

@Composable
private fun AssignedTaskItemCard(
    task: AssignedWorkTask,
    onUpdateStats: () -> Unit,
    onSubmitQlvh: () -> Unit,
    onRecall: () -> Unit,
    onShare: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit
) {
    val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    val isSubmitted = task.status == WorkTaskStatus.SUBMITTED_QLVH

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("task_item_${task.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSubmitted) Color(0xFFF1F8E9) else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSubmitted) Color(0xFFA5D6A7) else MaterialTheme.colorScheme.outlineVariant
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header: Category, Priority, Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(SpcNavy.copy(alpha = 0.1f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = task.category,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = SpcNavy
                        )
                    }

                    if (task.priority == "Khẩn cấp") {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(StatusDangerRed.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "KHẨN CẤP",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = StatusDangerRed
                            )
                        }
                    }
                }

                // Status Badge
                if (isSubmitted) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF2E7D32))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ĐÃ GỬI VỀ QLVH", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFEF6C00))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.PendingActions, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            if (task.status == WorkTaskStatus.NEW) "MỚI GIAO" else "ĐANG THỐNG KÊ",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            // Task Title
            Text(
                text = task.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Line & Location Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = SpcNavy, modifier = Modifier.size(15.dp))
                Text(
                    text = "${task.lineName} • ${task.spanLocation.ifBlank { "Toàn tuyến" }}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = SpcNavy
                )
            }

            // Assignment Details
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = "• Phân công bởi: ${task.assignedBy}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "• Cán bộ thực hiện: ${task.assignee} | Hạn: ${task.deadlineDate?.let { sdf.format(Date(it)) } ?: "Trong tuần"}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (task.description.isNotBlank()) {
                    Text(
                        text = "• Nội dung giao việc: ${task.description}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Statistical Results Highlight Block
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (task.recordedCount > 0) Color(0xFFFFF3E0) else Color(0xFFF5F5F5)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (task.recordedCount > 0) Color(0xFFFFB74D) else Color(0xFFE0E0E0)
                )
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.ElectricBolt,
                                contentDescription = null,
                                tint = if (task.recordedCount > 0) Color(0xFFE65100) else Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "KẾT QUẢ THỐNG KÊ HIỆN TRƯỜNG:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (task.recordedCount > 0) Color(0xFFE65100) else Color.DarkGray
                            )
                        }

                        // Recorded Count Badge
                        Text(
                            text = "${task.recordedCount} ${task.unit}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (task.recordedCount > 0) StatusDangerRed else Color.Gray
                        )
                    }

                    if (task.detailedStatistics.isNotBlank()) {
                        Text(
                            text = task.detailedStatistics,
                            fontSize = 12.sp,
                            color = Color(0xFF263238),
                            lineHeight = 16.sp
                        )
                    } else {
                        Text(
                            text = "(Chưa ghi nhận số liệu cụ thể. Bấm 'Cập nhật số liệu' bên dưới)",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        )
                    }

                    if (task.proposedRemedy.isNotBlank()) {
                        Text(
                            text = "💡 Đề xuất vật tư / giải pháp: ${task.proposedRemedy}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1565C0)
                        )
                    }
                }
            }

            // Submitted QLVH info if sent
            if (isSubmitted) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFFE8F5E9))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Mã số phiếu QLVH: ${task.reportCode ?: "BC-QLVH"}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B5E20)
                        )
                        Text(
                            text = "Gửi lúc: ${task.submittedDate?.let { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(it)) }} • Nơi nhận: ${task.qlvhRecipient}",
                            fontSize = 10.sp,
                            color = Color(0xFF2E7D32)
                        )
                    }
                }
            }

            // Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isSubmitted) {
                    // Send to QLVH Button (PRIMARY)
                    Button(
                        onClick = onSubmitQlvh,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1.3f)
                            .testTag("btn_submit_qlvh_${task.id}")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ký & Gửi QLVH", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    // Update Statistics Button
                    OutlinedButton(
                        onClick = onUpdateStats,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_update_stats_${task.id}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Thống kê", fontSize = 12.sp)
                    }
                } else {
                    // Already submitted: PDF report
                    Button(
                        onClick = onSubmitQlvh,
                        colors = ButtonDefaults.buttonColors(containerColor = SpcNavy),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Ký / Xuất PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    OutlinedButton(
                        onClick = onRecall,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Thu hồi sửa", fontSize = 11.sp)
                    }
                }

                // Copy Text Icon Button
                IconButton(
                    onClick = onCopy,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.Assignment, contentDescription = "Sao chép nội dung", tint = SpcNavy, modifier = Modifier.size(18.dp))
                }

                // Delete Icon Button
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Xóa", tint = Color.Gray, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

// Dialog thêm công việc phân công mới
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddAssignedTaskDialog(
    defaultAssignee: String,
    onDismiss: () -> Unit,
    onConfirm: (AssignedWorkTask) -> Unit
) {
    var title by remember { mutableStateOf("Thống kê hệ thống tiếp địa bị mất") }
    var assignedBy by remember { mutableStateOf("Tổ Kỹ thuật QLVH") }
    var assignee by remember { mutableStateOf(defaultAssignee.ifBlank { "Nguyễn Văn A" }) }
    var category by remember { mutableStateOf("Tiếp địa & Nối đất") }
    var lineName by remember { mutableStateOf("Đường dây 471 E1.1") }
    var spanLocation by remember { mutableStateOf("Cột 10 đến cột 40") }
    var targetScope by remember { mutableStateOf("30 vị trí cột") }
    var unit by remember { mutableStateOf("vị trí") }
    var priority by remember { mutableStateOf("Quan trọng") }
    var description by remember { mutableStateOf("Kiểm tra thực tế dây và cọc tiếp địa trên đoạn tuyến, thống kê các điểm mất hoặc đứt rỉ sét để gửi QLVH đề xuất cấp vật tư hoàn trả.") }

    var categoryExpanded by remember { mutableStateOf(false) }
    var priorityExpanded by remember { mutableStateOf(false) }

    val categoryOptions = listOf(
        "Tiếp địa & Nối đất",
        "Biển báo an toàn",
        "Phụ kiện xà sứ",
        "Móng cột & Dây néo",
        "Hành lang & Cây xanh",
        "Công tác phát sinh khác"
    )

    val priorityOptions = listOf("Khẩn cấp", "Quan trọng", "Bình thường")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Ghi Nhận Công Việc Phân Công",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = SpcNavy
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Tiêu đề
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Tiêu đề công việc *") },
                    placeholder = { Text("VD: Thống kê tiếp địa bị mất tuyến 471") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Phân loại công việc
                ExposedDropdownMenuBox(
                    expanded = categoryExpanded,
                    onExpandedChange = { categoryExpanded = it }
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Phân loại chuyên mục") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = categoryExpanded,
                        onDismissRequest = { categoryExpanded = false }
                    ) {
                        categoryOptions.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt) },
                                onClick = {
                                    category = opt
                                    categoryExpanded = false
                                }
                            )
                        }
                    }
                }

                // Tuyến đường dây & Vị trí cột
                OutlinedTextField(
                    value = lineName,
                    onValueChange = { lineName = it },
                    label = { Text("Tuyến đường dây / Xuất tuyến *") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = spanLocation,
                        onValueChange = { spanLocation = it },
                        label = { Text("Đoạn cột / Vị trí") },
                        modifier = Modifier.weight(1.2f)
                    )

                    OutlinedTextField(
                        value = targetScope,
                        onValueChange = { targetScope = it },
                        label = { Text("Quy mô") },
                        modifier = Modifier.weight(0.8f)
                    )
                }

                // Người giao & Người làm
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = assignedBy,
                        onValueChange = { assignedBy = it },
                        label = { Text("Đơn vị giao việc") },
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = assignee,
                        onValueChange = { assignee = it },
                        label = { Text("Người thực hiện *") },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Mức độ ưu tiên
                ExposedDropdownMenuBox(
                    expanded = priorityExpanded,
                    onExpandedChange = { priorityExpanded = it }
                ) {
                    OutlinedTextField(
                        value = priority,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Mức độ ưu tiên") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = priorityExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = priorityExpanded,
                        onDismissRequest = { priorityExpanded = false }
                    ) {
                        priorityOptions.forEach { p ->
                            DropdownMenuItem(
                                text = { Text(p) },
                                onClick = {
                                    priority = p
                                    priorityExpanded = false
                                }
                            )
                        }
                    }
                }

                // Mô tả
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Nội dung chỉ đạo & yêu cầu") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && lineName.isNotBlank() && assignee.isNotBlank()) {
                        val task = AssignedWorkTask(
                            title = title.trim(),
                            assignedBy = assignedBy.trim(),
                            assignee = assignee.trim(),
                            category = category,
                            lineName = lineName.trim(),
                            spanLocation = spanLocation.trim(),
                            targetScope = targetScope.trim(),
                            recordedCount = 0,
                            unit = unit,
                            description = description.trim(),
                            detailedStatistics = "",
                            proposedRemedy = "",
                            assignedDate = System.currentTimeMillis(),
                            deadlineDate = System.currentTimeMillis() + 5 * 24 * 3600 * 1000L,
                            status = WorkTaskStatus.IN_PROGRESS,
                            priority = priority
                        )
                        onConfirm(task)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SpcNavy),
                enabled = title.isNotBlank() && lineName.isNotBlank() && assignee.isNotBlank()
            ) {
                Text("Tạo công việc", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}

// Dialog cập nhật số liệu thống kê hiện trường
@Composable
fun UpdateTaskStatsDialog(
    task: AssignedWorkTask,
    onDismiss: () -> Unit,
    onConfirm: (count: Int, details: String, remedy: String) -> Unit
) {
    var countText by remember { mutableStateOf(if (task.recordedCount > 0) task.recordedCount.toString() else "4") }
    var details by remember {
        mutableStateOf(
            task.detailedStatistics.ifBlank {
                "- Cột 15: Mất dây tiếp địa đồng trần dài 3.2m\n- Cột 24: Bị cạy nắp bảo vệ, mất dây tiếp địa Recloser\n- Cột 31: Mất 01 cọc tiếp địa đồng phi 16"
            }
        )
    }
    var remedy by remember {
        mutableStateOf(
            task.proposedRemedy.ifBlank {
                "Cấp bổ sung dây cáp đồng M50, 04 kẹp siết tiếp địa và cọc tiếp địa thép mạ đồng để phục hồi an toàn."
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Thống Kê Hiện Trường & Vật Tư",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = SpcNavy
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Công việc: ${task.title}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.DarkGray
                )

                // Số lượng phát hiện
                OutlinedTextField(
                    value = countText,
                    onValueChange = { if (it.all { char -> char.isDigit() }) countText = it },
                    label = { Text("Số lượng phát hiện / vi phạm (${task.unit}) *") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Chi tiết thống kê
                OutlinedTextField(
                    value = details,
                    onValueChange = { details = it },
                    label = { Text("Chi tiết thống kê cụ thể từng vị trí *") },
                    placeholder = { Text("Ghi rõ vị trí cột và hiện trạng mất/hư hỏng...") },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth()
                )

                // Đề xuất xử lý / vật tư
                OutlinedTextField(
                    value = remedy,
                    onValueChange = { remedy = it },
                    label = { Text("Đề xuất xử lý & Vật tư dự trù cần cấp") },
                    placeholder = { Text("VD: Cấp 10m dây tiếp địa đồng, 2 cọc tiếp địa...") },
                    minLines = 2,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val count = countText.toIntOrNull() ?: 0
                    onConfirm(count, details.trim(), remedy.trim())
                },
                colors = ButtonDefaults.buttonColors(containerColor = SpcNavy)
            ) {
                Text("Lưu số liệu", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}

// Dialog gửi báo cáo về QLVH
@Composable
fun SubmitToQlvhDialog(
    task: AssignedWorkTask,
    onDismiss: () -> Unit,
    onConfirm: (recipient: String, notes: String) -> Unit
) {
    var recipient by remember { mutableStateOf(task.qlvhRecipient.ifBlank { "Tổ Kỹ thuật & Quản lý vận hành" }) }
    var notes by remember { mutableStateOf("Kính gửi bộ phận QLVH tiếp nhận số liệu để tổng hợp phương án xử lý và cấp phát vật tư.") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = Color(0xFF2E7D32))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Gửi Báo Cáo Về QLVH", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA5D6A7))
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(task.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1B5E20))
                        Text("• Tuyến: ${task.lineName} (${task.spanLocation})", fontSize = 11.sp, color = Color(0xFF2E7D32))
                        Text("• Số lượng thống kê: ${task.recordedCount} ${task.unit}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = StatusDangerRed)
                        Text("• Người báo cáo: ${task.assignee}", fontSize = 11.sp, color = Color(0xFF2E7D32))
                    }
                }

                OutlinedTextField(
                    value = recipient,
                    onValueChange = { recipient = it },
                    label = { Text("Bộ phận / Nơi tiếp nhận báo cáo *") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Ghi chú kèm theo phiếu gửi") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Sau khi gửi, hệ thống sẽ tự động sinh mã phiếu theo dõi QLVH và lưu trữ dữ liệu an toàn.",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(recipient.trim(), notes.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
            ) {
                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Xác nhận gửi QLVH", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Đóng")
            }
        }
    )
}

// Hàm chia sẻ qua Android Intent
private fun shareReportText(context: Context, text: String) {
    val sendIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, text)
        type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "Gửi Báo Cáo Công Việc QLVH")
    context.startActivity(shareIntent)
}

// Hàm sao chép vào Clipboard
private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Báo cáo công việc QLVH", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "Đã sao chép nội dung báo cáo vào bộ nhớ tạm!", Toast.LENGTH_SHORT).show()
}
