package com.example.ui.dialogs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.SafetyCorridorRecord

@Composable
fun ResolveCorridorDialog(
    corridor: SafetyCorridorRecord,
    onDismiss: () -> Unit,
    onConfirm: (clearedBy: String, clearanceAction: String) -> Unit
) {
    var clearedBy by remember { mutableStateOf("Tổ Phát Quang Tuyến & An Toàn Lưới") }
    var clearanceAction by remember {
        mutableStateOf(
            if (corridor.hazardType.name == "TREE")
                "Đã chặt hạ và tỉa gọn cành cây vi phạm, đảm bảo khoảng cách an toàn tĩnh và động > 3.0 mét tới dây pha."
            else
                "Đã làm việc với chủ hộ và chính quyền địa phương, hạ phần công trình cơi nới, bọc ống cách điện composite bảo vệ an toàn."
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Xác Nhận Đã Giải Tỏa / Xử Lý Hành Lang", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "${corridor.hazardType.label} - ${corridor.lineName} (${corridor.spanLocation})",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = corridor.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = clearedBy,
                    onValueChange = { clearedBy = it },
                    label = { Text("Đơn vị / Đội thực hiện xử lý") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = clearanceAction,
                    onValueChange = { clearanceAction = it },
                    label = { Text("Biện pháp thực hiện đã khắc phục") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("clearance_action_input"),
                    minLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (clearedBy.isNotBlank() && clearanceAction.isNotBlank()) {
                        onConfirm(clearedBy, clearanceAction)
                    }
                },
                modifier = Modifier.testTag("confirm_resolve_corridor_btn")
            ) {
                Text("Đã xử lý an toàn")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}
