package com.example.ui.dialogs

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.DefectRecord
import com.example.data.model.DefectSeverity
import com.example.data.model.DefectStatus
import com.example.data.model.GridEquipment
import com.example.ui.theme.ElectricBlue
import com.example.util.CameraPhotoHelper

@Composable
fun AddDefectDialog(
    equipmentList: List<GridEquipment>,
    preselectedEquipment: GridEquipment? = null,
    onDismiss: () -> Unit,
    onSave: (DefectRecord) -> Unit
) {
    val context = LocalContext.current
    var selectedEq by remember { mutableStateOf(preselectedEquipment) }
    var title by remember { mutableStateOf("") }
    var severity by remember { mutableStateOf(DefectSeverity.MAJOR) }
    var category by remember { mutableStateOf("Thiết bị") }
    var description by remember { mutableStateOf("") }
    var actionPlan by remember { mutableStateOf("") }
    var reportedBy by remember { mutableStateOf("Nguyễn Văn A - Tổ QLVH") }
    var photoBase64 by remember { mutableStateOf<String?>(null) }
    var capturedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            capturedBitmap = bitmap
            photoBase64 = CameraPhotoHelper.bitmapToBase64(bitmap)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch()
        } else {
            Toast.makeText(context, "Cần cấp quyền máy ảnh để chụp ảnh hiện trường!", Toast.LENGTH_SHORT).show()
        }
    }

    var eqDropdownExpanded by remember { mutableStateOf(false) }
    var severityDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Báo Cáo Khiếm Khuyết Mới", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Chọn thiết bị
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { eqDropdownExpanded = true },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Thiết bị liên quan", style = MaterialTheme.typography.labelSmall)
                        Text(
                            text = selectedEq?.let { "${it.code} - ${it.name}" } ?: "Chưa chọn (hoặc khiếm khuyết chung tuyến)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                        DropdownMenu(
                            expanded = eqDropdownExpanded,
                            onDismissRequest = { eqDropdownExpanded = false }
                        ) {
                            equipmentList.forEach { eq ->
                                DropdownMenuItem(
                                    text = { Text("${eq.code} - ${eq.name} (${eq.poleNumber})") },
                                    onClick = {
                                        selectedEq = eq
                                        eqDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Chọn mức độ nghiêm trọng
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { severityDropdownExpanded = true },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Mức độ nghiêm trọng", style = MaterialTheme.typography.labelSmall)
                        Text(
                            text = severity.label,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = when (severity) {
                                DefectSeverity.CRITICAL -> MaterialTheme.colorScheme.error
                                DefectSeverity.MAJOR -> MaterialTheme.colorScheme.secondary
                                else -> MaterialTheme.colorScheme.primary
                            }
                        )
                        DropdownMenu(
                            expanded = severityDropdownExpanded,
                            onDismissRequest = { severityDropdownExpanded = false }
                        ) {
                            DefectSeverity.entries.forEach { entry ->
                                DropdownMenuItem(
                                    text = { Text(entry.label) },
                                    onClick = {
                                        severity = entry
                                        severityDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Tiêu đề khiếm khuyết (ví dụ: Phát nhiệt ngàm lèo pha B)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("defect_title_input")
                )

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Hạng mục (Mối nối, Tiếp địa, Sứ, Dây chì, Tủ điều khiển)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Mô tả chi tiết hiện trạng") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                OutlinedTextField(
                    value = actionPlan,
                    onValueChange = { actionPlan = it },
                    label = { Text("Phương án xử lý / Biện pháp an toàn") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                OutlinedTextField(
                    value = reportedBy,
                    onValueChange = { reportedBy = it },
                    label = { Text("Người phát hiện") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Chụp ảnh hiện trường đính kèm
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Ảnh chụp hiện trường",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Button(
                                onClick = {
                                    val hasPermission = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.CAMERA
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (hasPermission) {
                                        cameraLauncher.launch()
                                    } else {
                                        permissionLauncher.launch(Manifest.permission.CAMERA)
                                    }
                                },
                                colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                                modifier = Modifier.testTag("defect_camera_btn")
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = "Chụp ảnh", modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (photoBase64 == null) "Chụp ảnh" else "Chụp lại", fontSize = 12.sp)
                            }
                        }

                        if (capturedBitmap != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black)
                            ) {
                                Image(
                                    bitmap = capturedBitmap!!.asImageBitmap(),
                                    contentDescription = "Ảnh hiện trường",
                                    modifier = Modifier.fillMaxWidth().height(180.dp),
                                    contentScale = ContentScale.Crop
                                )
                                IconButton(
                                    onClick = {
                                        capturedBitmap = null
                                        photoBase64 = null
                                    },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(50))
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Xóa ảnh", tint = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val defect = DefectRecord(
                            equipmentId = selectedEq?.id,
                            equipmentCode = selectedEq?.code,
                            title = title,
                            severity = severity,
                            category = category,
                            reportedDate = System.currentTimeMillis(),
                            reportedBy = reportedBy,
                            description = description,
                            actionPlan = actionPlan,
                            status = DefectStatus.PENDING,
                            photoBase64 = photoBase64
                        )
                        onSave(defect)
                    }
                },
                modifier = Modifier.testTag("save_defect_btn")
            ) {
                Text("Lưu khiếm khuyết")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}
