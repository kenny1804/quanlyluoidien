package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ==========================================
// EVNSPC Corporate Primary & Secondary Colors
// Chuẩn phong cách nhận diện EVNSPC: Xanh dương đậm chủ đạo, cam vàng điểm nhấn
// ==========================================
val SpcNavy = Color(0xFF003366)          // Xanh dương thẫm EVNSPC truyền thống
val SpcNavyDark = Color(0xFF002244)      // Xanh đen header/status bar
val SpcNavyLight = Color(0xFF154E8A)     // Xanh nhấn nhạt hơn

val ElectricBlue = Color(0xFF005BAC)     // Xanh EVN Chuẩn Quốc Gia
val ElectricBlueLight = Color(0xFF2C7BD6)
val ElectricBlueDark = Color(0xFF004080)

val SpcYellow = Color(0xFFE89300)        // Cam vàng ngành điện (Điểm nhấn nhận diện EVNSPC)
val GridAmber = Color(0xFFE89300)
val GridAmberDark = Color(0xFFC77800)
val GridAmberLight = Color(0xFFFFB338)

val SubstationCyan = Color(0xFF007A87)

// Status & Alert Semantic Colors (Tiêu chuẩn kỹ thuật rõ ràng, tương phản cao)
val StatusNormalGreen = Color(0xFF15803D)   // Đang vận hành an toàn (Đậm, dễ đọc)
val StatusNormalBg = Color(0xFFDCFCE7)      // Nền xanh nhạt
val StatusWarningAmber = Color(0xFFB45309)  // Cảnh báo / cần chú ý (Đậm, dễ đọc)
val StatusWarningBg = Color(0xFFFEF3C7)     // Nền vàng cam nhạt
val StatusDangerRed = Color(0xFFB91C1C)     // Khiếm khuyết / Sự cố / Nguy hiểm (Đậm, dễ đọc)
val StatusDangerBg = Color(0xFFFEE2E2)      // Nền đỏ nhạt
val StatusInfoBlue = Color(0xFF0369A1)      // Đang bảo dưỡng / Thông tin (Đậm, dễ đọc)
val StatusInfoBg = Color(0xFFE0F2FE)       // Nền xanh dương nhạt

// Neutral Backgrounds & Card Surfaces (Sạch sẽ, độ tương phản cao sắc nét)
val SpcBackgroundLight = Color(0xFFF1F5F9) // Nền sáng trung tính, làm nổi bật thẻ
val SpcCardBorderLight = Color(0xFFCBD5E1) // Viền thẻ rõ nét 1dp chống tệp màu
val SpcTextPrimaryLight = Color(0xFF020617) // Chữ chính màu đen sâu tuyệt đối (Obsidian/Slate-950) chống chói nắng
val SpcTextSecondaryLight = Color(0xFF1E293B) // Chữ phụ màu Slate-800 đậm rõ, không dùng xám nhạt ngoài trời
val SpcTextMutedLight = Color(0xFF334155)   // Chữ chú thích tương phản cao đạt chuẩn WCAG AAA

val GridSlateDark = Color(0xFF020617)
val GridSlateMedium = Color(0xFF1E293B)
val GridSlateLight = Color(0xFFF8FAFC)
val SurfaceCard = Color(0xFFFFFFFF)
val SurfaceCardDark = Color(0xFF0F172A)

// Outdoor High-Contrast Sunlight Mode (Chế độ ánh sáng mạnh ngoài trời)
val OutdoorBg = Color(0xFFF4F6F8)
val OutdoorSurface = Color(0xFFFFFFFF)
val OutdoorBorder = Color(0xFF64748B)
val OutdoorTextPrimary = Color(0xFF000000)
val OutdoorTextSecondary = Color(0xFF1E293B)
val OutdoorPrimary = Color(0xFF002244)
val OutdoorWarning = Color(0xFF92400E)
val OutdoorDanger = Color(0xFF991B1B)
val OutdoorSuccess = Color(0xFF14532D)

