package com.example.ui.dialogs

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.DefectRecord
import com.example.data.repository.InspectorProfileManager
import com.example.ui.components.PdfQuickShareSection
import com.example.ui.components.SignaturePad
import com.example.util.PdfReportGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DefectPdfReportDialog(
    defect: DefectRecord,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isGenerating by remember { mutableStateOf(false) }
    var generatedFile by remember { mutableStateOf<File?>(null) }
    var renderedBitmaps by remember { mutableStateOf<List<Bitmap>>(emptyList()) }
    var currentPreviewPage by remember { mutableIntStateOf(0) }

    val initialProfile = remember { InspectorProfileManager.getProfile(context) }
    var inspectorName by remember { mutableStateOf(defect.reportedBy.ifBlank { initialProfile.inspectorName }) }
    var teamName by remember { mutableStateOf(initialProfile.teamName) }
    var companyName by remember { mutableStateOf(initialProfile.companyName) }
    var managedArea by remember { mutableStateOf(initialProfile.managedArea) }
    var signatureBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var showSignatureSection by remember { mutableStateOf(true) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.93f),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.background,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFC62828))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = null,
                                tint = Color(0xFFFFD54F),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Báo Cáo Khiếm Khuyết Gửi QLVH",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "EVNSPC • Xuất PDF có ký xác nhận gửi Zalo/Telegram/In",
                                    color = Color(0xFFE0E0E0),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Đóng",
                                tint = Color.White
                            )
                        }
                    }
                }

                if (generatedFile != null && renderedBitmaps.isNotEmpty()) {
                    // PDF Preview Screen
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp)
                    ) {
                        // Action row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    renderedBitmaps = emptyList()
                                    generatedFile = null
                                }
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Chỉnh lại chữ ký", fontSize = 12.sp)
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = {
                                        generatedFile?.let {
                                            PdfReportGenerator.shareSingleRecordToOperationTeam(
                                                context = context,
                                                pdfFile = it,
                                                reportTitle = "Báo cáo khiếm khuyết: ${defect.title}",
                                                teamName = teamName,
                                                inspectorName = inspectorName,
                                                area = managedArea
                                            )
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Gửi Tổ QLVH", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        generatedFile?.let { PdfReportGenerator.openPdfFile(context, it) }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                                ) {
                                    Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Mở File", fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        generatedFile?.let { PdfReportGenerator.sharePdfFile(context, it) }
                                    }
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = "Chia sẻ", modifier = Modifier.size(16.dp))
                                }

                                OutlinedButton(
                                    onClick = {
                                        generatedFile?.let { PdfReportGenerator.printPdfFile(context, it) }
                                    }
                                ) {
                                    Icon(Icons.Default.Print, contentDescription = "In báo cáo", modifier = Modifier.size(16.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Page navigation header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { if (currentPreviewPage > 0) currentPreviewPage-- },
                                enabled = currentPreviewPage > 0
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Trang trước")
                            }

                            Text(
                                text = "Xem trước trang ${currentPreviewPage + 1} / ${renderedBitmaps.size}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )

                            IconButton(
                                onClick = { if (currentPreviewPage < renderedBitmaps.size - 1) currentPreviewPage++ },
                                enabled = currentPreviewPage < renderedBitmaps.size - 1
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Trang sau")
                            }
                        }

                        // Page Rendered View
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .background(Color(0xFFE0E0E0), RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFFBDBDBD), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            val bitmap = renderedBitmaps.getOrNull(currentPreviewPage)
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap.asImageBitmap(),
                                    contentDescription = "Trang ${currentPreviewPage + 1}",
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .aspectRatio(595f / 842f)
                                        .clip(RoundedCornerShape(4.dp))
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        PdfQuickShareSection(
                            onShareZalo = {
                                generatedFile?.let {
                                    PdfReportGenerator.shareReportViaTarget(
                                        context = context,
                                        pdfFile = it,
                                        target = PdfReportGenerator.ShareTarget.ZALO,
                                        reportTitle = "Báo cáo khiếm khuyết: ${defect.title}",
                                        teamName = teamName,
                                        inspectorName = inspectorName,
                                        area = managedArea
                                    )
                                }
                            },
                            onShareGmail = {
                                generatedFile?.let {
                                    PdfReportGenerator.shareReportViaTarget(
                                        context = context,
                                        pdfFile = it,
                                        target = PdfReportGenerator.ShareTarget.GMAIL,
                                        reportTitle = "Báo cáo khiếm khuyết: ${defect.title}",
                                        teamName = teamName,
                                        inspectorName = inspectorName,
                                        area = managedArea
                                    )
                                }
                            },
                            onShareTelegram = {
                                generatedFile?.let {
                                    PdfReportGenerator.shareReportViaTarget(
                                        context = context,
                                        pdfFile = it,
                                        target = PdfReportGenerator.ShareTarget.TELEGRAM,
                                        reportTitle = "Báo cáo khiếm khuyết: ${defect.title}",
                                        teamName = teamName,
                                        inspectorName = inspectorName,
                                        area = managedArea
                                    )
                                }
                            },
                            onShareGeneral = {
                                generatedFile?.let { PdfReportGenerator.sharePdfFile(context, it) }
                            },
                            onPrint = {
                                generatedFile?.let { PdfReportGenerator.printPdfFile(context, it) }
                            },
                            onOpenFile = {
                                generatedFile?.let { PdfReportGenerator.openPdfFile(context, it) }
                            }
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Check,
                                contentDescription = null,
                                tint = Color(0xFF003366),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Bản in PDF có dấu chìm: CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF003366)
                            )
                        }
                    }
                } else {
                    // Defect Details & Signature Setup Screen
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Defect Summary Card
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFCDD2))
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = defect.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = Color(0xFFB71C1C),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFFD32F2F))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(defect.severity.label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                }

                                Text("• Thiết bị / Vị trí: ${defect.equipmentCode ?: "Lưới điện"}", fontSize = 12.sp)
                                Text("• Hiện trạng: ${defect.status.label}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("• Mô tả chi tiết: ${defect.description}", fontSize = 12.sp)
                                if (defect.actionPlan.isNotBlank()) {
                                    Text("• Biện pháp xử lý đề xuất: ${defect.actionPlan}", fontSize = 12.sp, color = Color(0xFF0D47A1))
                                }
                                if (!defect.resolutionNotes.isNullOrBlank()) {
                                    Text("• Ghi nhận khắc phục: ${defect.resolutionNotes}", fontSize = 12.sp, color = Color(0xFF1B5E20))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Card: Thông tin Cán bộ & Chữ ký gửi Tổ QLVH
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { showSignatureSection = !showSignatureSection },
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Send, contentDescription = null, tint = Color(0xFFC62828), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Thông tin Cán bộ phát hiện & Khung ký tên",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color(0xFFC62828)
                                        )
                                    }
                                    Text(
                                        text = if (showSignatureSection) "Thu gọn ▲" else "Mở rộng ▼",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }

                                if (showSignatureSection) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(
                                            value = inspectorName,
                                            onValueChange = { inspectorName = it },
                                            label = { Text("Cán bộ báo cáo / kiểm tra", fontSize = 11.sp) },
                                            placeholder = { Text("VD: Nguyễn Văn A", fontSize = 11.sp) },
                                            modifier = Modifier.weight(1f),
                                            singleLine = true
                                        )
                                        OutlinedTextField(
                                            value = teamName,
                                            onValueChange = { teamName = it },
                                            label = { Text("Đơn vị nhận (Tổ QLVH)", fontSize = 11.sp) },
                                            modifier = Modifier.weight(1f),
                                            singleLine = true
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    OutlinedTextField(
                                        value = managedArea,
                                        onValueChange = { managedArea = it },
                                        label = { Text("Tuyến / Khu vực phụ trách", fontSize = 11.sp) },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    SignaturePad(
                                        inspectorName = inspectorName,
                                        onSignatureChanged = { signatureBitmap = it }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Generate Button
                        Button(
                            onClick = {
                                isGenerating = true
                                coroutineScope.launch {
                                    withContext(Dispatchers.Default) {
                                        val file = PdfReportGenerator.generateDefectPdf(
                                            context = context,
                                            defect = defect,
                                            inspectorName = inspectorName,
                                            teamName = teamName,
                                            companyName = companyName,
                                            managedArea = managedArea,
                                            signatureBitmap = signatureBitmap
                                        )
                                        val bitmaps = PdfReportGenerator.renderPdfPagesToBitmaps(file)
                                        withContext(Dispatchers.Main) {
                                            generatedFile = file
                                            renderedBitmaps = bitmaps
                                            currentPreviewPage = 0
                                            isGenerating = false
                                        }
                                    }
                                }
                            },
                            enabled = !isGenerating,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                        ) {
                            if (isGenerating) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Đang khởi tạo báo cáo PDF...")
                            } else {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Ký & Xuất Báo Cáo Khiếm Khuyết Gửi QLVH",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
