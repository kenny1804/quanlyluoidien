package com.example.ui.dialogs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.EquipmentStatus
import com.example.data.model.EquipmentType
import com.example.data.model.GridEquipment

@Composable
fun AddEquipmentDialog(
    initialEquipment: GridEquipment? = null,
    onDismiss: () -> Unit,
    onSave: (GridEquipment) -> Unit
) {
    var code by remember { mutableStateOf(initialEquipment?.code ?: "") }
    var name by remember { mutableStateOf(initialEquipment?.name ?: "") }
    var type by remember { mutableStateOf(initialEquipment?.type ?: EquipmentType.RECLOSER) }
    var lineName by remember { mutableStateOf(initialEquipment?.lineName ?: "Đường dây 471 E1.1") }
    var poleNumber by remember { mutableStateOf(initialEquipment?.poleNumber ?: "") }
    var substation by remember { mutableStateOf(initialEquipment?.substation ?: "TBA 110kV E1.1") }
    var manufacturer by remember { mutableStateOf(initialEquipment?.manufacturer ?: "") }
    var model by remember { mutableStateOf(initialEquipment?.model ?: "") }
    var ratedVoltage by remember { mutableStateOf(initialEquipment?.ratedVoltage ?: "24 kV") }
    var ratedCurrent by remember { mutableStateOf(initialEquipment?.ratedCurrent ?: "630 A") }
    var breakingCapacity by remember { mutableStateOf(initialEquipment?.breakingCapacity ?: "12.5 kA") }

    // Dây chì
    var fuseType by remember { mutableStateOf(initialEquipment?.fuseType ?: "Type K") }
    var fuseRating by remember { mutableStateOf(initialEquipment?.fuseRating ?: "") }
    var protectedCapacity by remember { mutableStateOf(initialEquipment?.protectedCapacity ?: "") }

    // Recloser / LBS / LA
    var controllerType by remember { mutableStateOf(initialEquipment?.controllerType ?: "") }
    var protectionSettings by remember { mutableStateOf(initialEquipment?.protectionSettings ?: "") }
    var sf6Pressure by remember { mutableStateOf(initialEquipment?.sf6Pressure ?: "") }
    var groundingResistance by remember { mutableStateOf(initialEquipment?.groundingResistance ?: "4.0 Ω") }
    var inspectionIntervalDays by remember { mutableIntStateOf(initialEquipment?.inspectionIntervalDays ?: 30) }
    var maintenanceIntervalDays by remember { mutableIntStateOf(initialEquipment?.maintenanceIntervalDays ?: 180) }
    var notes by remember { mutableStateOf(initialEquipment?.notes ?: "") }

    var typeDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialEquipment == null) "Thêm Thiết Bị Lưới Điện Mới" else "Chỉnh Sửa Thiết Bị",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Loại thiết bị dropdown
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { typeDropdownExpanded = true },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Loại thiết bị (Recloser, LBS, DS, LA, FCO, LBFCO)", style = MaterialTheme.typography.labelSmall)
                        Text(
                            "${type.name} - ${type.vietnameseName}",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        DropdownMenu(
                            expanded = typeDropdownExpanded,
                            onDismissRequest = { typeDropdownExpanded = false }
                        ) {
                            EquipmentType.entries.forEach { entry ->
                                DropdownMenuItem(
                                    text = { Text("${entry.name} - ${entry.vietnameseName}") },
                                    onClick = {
                                        type = entry
                                        typeDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("Mã / Ký hiệu thiết bị (ví dụ: REC-471/15)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("equipment_code_input")
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Tên thiết bị") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = lineName,
                        onValueChange = { lineName = it },
                        label = { Text("Tuyến đường dây") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = poleNumber,
                        onValueChange = { poleNumber = it },
                        label = { Text("Vị trí cột") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = substation,
                    onValueChange = { substation = it },
                    label = { Text("Trạm TBA / Xuất tuyến") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = manufacturer,
                        onValueChange = { manufacturer = it },
                        label = { Text("Hãng sản xuất") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = model,
                        onValueChange = { model = it },
                        label = { Text("Model / Kiểu loại") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = ratedVoltage,
                        onValueChange = { ratedVoltage = it },
                        label = { Text("Điện áp (Un)") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = ratedCurrent,
                        onValueChange = { ratedCurrent = it },
                        label = { Text("Dòng đ/mức (In)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = breakingCapacity,
                    onValueChange = { breakingCapacity = it },
                    label = { Text("Dòng cắt ngắn mạch (Icn)") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Nếu là FCO hoặc LBFCO: hiển thị trường thông số chì
                if (type == EquipmentType.FCO || type == EquipmentType.LBFCO) {
                    Text(
                        "Thông số Dây Chì & Trạm Biến Áp",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Row(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = fuseType,
                            onValueChange = { fuseType = it },
                            label = { Text("Loại chì (Type K/T/H)") },
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedTextField(
                            value = fuseRating,
                            onValueChange = { fuseRating = it },
                            label = { Text("Trị số chì (15K, 25K...)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = protectedCapacity,
                        onValueChange = { protectedCapacity = it },
                        label = { Text("Công suất TBA bảo vệ (kVA)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Nếu là Recloser hoặc LBS
                if (type == EquipmentType.RECLOSER || type == EquipmentType.LBS) {
                    Text(
                        "Thông số Điều Khiển & Giám Sát",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    OutlinedTextField(
                        value = controllerType,
                        onValueChange = { controllerType = it },
                        label = { Text("Tủ điều khiển & Rơle (SEL, RC-10...)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = protectionSettings,
                        onValueChange = { protectionSettings = it },
                        label = { Text("Cài đặt bảo vệ (51P, 51N, 79 đóng lại)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = sf6Pressure,
                        onValueChange = { sf6Pressure = it },
                        label = { Text("Áp lực khí SF6 / Môi chất cách điện") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                OutlinedTextField(
                    value = groundingResistance,
                    onValueChange = { groundingResistance = it },
                    label = { Text("Điện trở tiếp địa Rtd (Ω)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = inspectionIntervalDays.toString(),
                        onValueChange = { inspectionIntervalDays = it.toIntOrNull() ?: 30 },
                        label = { Text("Chu kỳ K/tra (ngày)") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = maintenanceIntervalDays.toString(),
                        onValueChange = { maintenanceIntervalDays = it.toIntOrNull() ?: 180 },
                        label = { Text("Chu kỳ B/dưỡng (ngày)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Ghi chú kỹ thuật") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (code.isNotBlank()) {
                        val toSave = (initialEquipment ?: GridEquipment(
                            code = code,
                            name = if (name.isNotBlank()) name else "${type.displayName} $code",
                            type = type,
                            lineName = lineName,
                            poleNumber = poleNumber,
                            substation = substation,
                            manufacturer = manufacturer,
                            model = model,
                            ratedVoltage = ratedVoltage,
                            ratedCurrent = ratedCurrent,
                            breakingCapacity = breakingCapacity,
                            fuseType = fuseType,
                            fuseRating = fuseRating,
                            protectedCapacity = protectedCapacity,
                            controllerType = controllerType,
                            protectionSettings = protectionSettings,
                            sf6Pressure = sf6Pressure,
                            groundingResistance = groundingResistance,
                            inspectionIntervalDays = inspectionIntervalDays,
                            maintenanceIntervalDays = maintenanceIntervalDays,
                            notes = notes
                        )).copy(
                            code = code,
                            name = if (name.isNotBlank()) name else "${type.displayName} $code",
                            type = type,
                            lineName = lineName,
                            poleNumber = poleNumber,
                            substation = substation,
                            manufacturer = manufacturer,
                            model = model,
                            ratedVoltage = ratedVoltage,
                            ratedCurrent = ratedCurrent,
                            breakingCapacity = breakingCapacity,
                            fuseType = fuseType,
                            fuseRating = fuseRating,
                            protectedCapacity = protectedCapacity,
                            controllerType = controllerType,
                            protectionSettings = protectionSettings,
                            sf6Pressure = sf6Pressure,
                            groundingResistance = groundingResistance,
                            inspectionIntervalDays = inspectionIntervalDays,
                            maintenanceIntervalDays = maintenanceIntervalDays,
                            notes = notes
                        )
                        onSave(toSave)
                    }
                },
                modifier = Modifier.testTag("confirm_save_equipment_btn")
            ) {
                Text("Lưu thiết bị")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Hủy")
            }
        }
    )
}
