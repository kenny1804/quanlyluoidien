package com.example.data.repository

import android.content.Context
import com.example.data.model.InspectorProfile

object InspectorProfileManager {
    private const val PREF_NAME = "evn_inspector_prefs"
    private const val KEY_NAME = "inspector_name"
    private const val KEY_TITLE = "inspector_title"
    private const val KEY_TEAM = "team_name"
    private const val KEY_COMPANY = "company_name"
    private const val KEY_AREA = "managed_area"
    private const val KEY_PHONE = "phone"

    fun getProfile(context: Context): InspectorProfile {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val savedCompany = prefs.getString(KEY_COMPANY, null)
        val finalCompany = if (savedCompany.isNullOrBlank() || savedCompany == "CÔNG TY ĐIỆN LỰC EVN") {
            "CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)"
        } else {
            savedCompany
        }

        val savedTeam = prefs.getString(KEY_TEAM, null)
        val finalTeam = if (savedTeam.isNullOrBlank() || savedTeam == "Tổ Quản Lý Vận Hành Lưới Điện 1") {
            "Tổ Quản Lý Vận Hành Lưới Điện - PCAG"
        } else {
            savedTeam
        }

        val savedArea = prefs.getString(KEY_AREA, null)
        val finalArea = if (savedArea.isNullOrBlank() || savedArea == "Đường dây 471 E1.1") {
            "Đường dây 471 An Giang"
        } else {
            savedArea
        }

        val savedName = prefs.getString(KEY_NAME, null)
        val finalName = if (savedName.isNullOrBlank() || savedName == "Kỹ sư Nguyễn Văn Tuấn" || savedName == "Nguyễn Văn Tuấn") {
            "Nguyễn Văn A"
        } else {
            savedName
        }

        return InspectorProfile(
            inspectorName = finalName,
            inspectorTitle = prefs.getString(KEY_TITLE, "Cán bộ Kỹ thuật Vận hành") ?: "Cán bộ Kỹ thuật Vận hành",
            teamName = finalTeam,
            companyName = finalCompany,
            managedArea = finalArea,
            phone = prefs.getString(KEY_PHONE, "0912.345.678") ?: "0912.345.678"
        )
    }

    fun saveProfile(context: Context, profile: InspectorProfile) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_NAME, profile.inspectorName)
            .putString(KEY_TITLE, profile.inspectorTitle)
            .putString(KEY_TEAM, profile.teamName)
            .putString(KEY_COMPANY, profile.companyName)
            .putString(KEY_AREA, profile.managedArea)
            .putString(KEY_PHONE, profile.phone)
            .apply()
    }
}
