package com.example.data.model

enum class EquipmentType(val displayName: String, val shortName: String, val vietnameseName: String) {
    RECLOSER("Recloser", "REC", "Máy cắt tự đóng lại"),
    LBS("LBS", "LBS", "Cầu dao phụ tải"),
    DS("DS", "DS", "Cầu dao cách ly"),
    LA("LA", "LA", "Chống sét van"),
    FCO("FCO", "FCO", "Cầu chì tự rơi"),
    LBFCO("LBFCO", "LBFCO", "Cầu chì tự rơi cắt có tải")
}

enum class EquipmentStatus(val label: String) {
    OPERATIONAL("Vận hành tốt"),
    WARNING("Cảnh báo đến hạn"),
    DEFECT("Có khiếm khuyết"),
    MAINTENANCE("Đang bảo dưỡng")
}

enum class DefectSeverity(val label: String) {
    CRITICAL("Khẩn cấp - Nguy cơ sự cố"),
    MAJOR("Nghiêm trọng"),
    MINOR("Trung bình"),
    MONITOR("Theo dõi định kỳ")
}

enum class DefectStatus(val label: String) {
    PENDING("Đang tồn tại"),
    IN_PROGRESS("Đang khắc phục"),
    RESOLVED("Đã khắc phục")
}

enum class HazardType(val label: String, val iconName: String) {
    TREE("Cây xanh vi phạm", "Park"),
    HOUSE_BUILDING("Nhà cửa / Công trình", "HomeWork"),
    EQUIPMENT_OTHER("Mái tôn / Biển quảng cáo / Khác", "Warning")
}

enum class HazardRiskLevel(val label: String) {
    HIGH("Nguy hiểm cao"),
    MEDIUM("Nguy cơ vừa"),
    LOW("Thấp")
}

enum class CorridorStatus(val label: String) {
    VIOLATION_EXISTING("Chưa xử lý"),
    PROCESSING("Đang phát quang / xử lý"),
    RESOLVED("Đã xử lý an toàn")
}
