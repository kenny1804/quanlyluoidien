package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "grid_equipments")
data class GridEquipment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val code: String, // Ký hiệu vận hành, e.g. "REC-471/12"
    val name: String, // Tên thiết bị
    val type: EquipmentType, // RECLOSER, LBS, DS, LA, FCO, LBFCO
    val lineName: String, // Tuyến đường dây, e.g. "Đường dây 471 E1.1"
    val poleNumber: String, // Số cột, e.g. "Cột 24"
    val substation: String, // Trạm TBA / Khu vực
    val manufacturer: String, // Hãng SX: Cooper, Schneider, ABB, Daelim...
    val model: String, // Kiểu loại
    val ratedVoltage: String = "22 kV", // Điện áp định mức
    val ratedCurrent: String = "630 A", // Dòng định mức
    val breakingCapacity: String = "12.5 kA", // Dòng cắt ngắn mạch
    val status: EquipmentStatus = EquipmentStatus.OPERATIONAL,
    val installationDate: String = "",

    // Thông số dây chì (đặc biệt cho FCO, LBFCO, TBA)
    val fuseType: String = "Type K", // Loại dây chì: K, T, H
    val fuseRating: String = "", // Trị số chì: 10K, 15K, 25K, 40K, 65K, 100K...
    val protectedCapacity: String = "", // Dung lượng máy biến áp bảo vệ: 100kVA, 160kVA, 250kVA, 400kVA...
    val fuseReplacedDate: String = "", // Ngày thay chì gần nhất

    // Thông số đặc thù Recloser/LBS/LA
    val controllerType: String = "", // Tủ điều khiển: SEL-651R, Nu-Lec, RC-10
    val protectionSettings: String = "", // Chỉnh định bảo vệ: Phase 51P, Ground 51N, 79
    val surgeCounter: Int = 0, // Đếm sét (LA) hoặc số lần đóng cắt REC/LBS
    val sf6Pressure: String = "", // Áp lực khí SF6 (MPa)
    val groundingResistance: String = "", // Trị số điện trở tiếp địa Rtd (Ohm)

    // Chu kỳ và lịch kiểm tra định kỳ
    val inspectionIntervalDays: Int = 30, // Chu kỳ kiểm tra định kỳ (ngày)
    val lastInspectionDate: Long = 0L, // Timestamp lần kiểm tra gần nhất
    val nextInspectionDate: Long = 0L, // Timestamp lần kiểm tra tiếp theo

    // Chu kỳ và lịch bảo dưỡng
    val maintenanceIntervalDays: Int = 180, // Chu kỳ bảo dưỡng (ngày)
    val lastMaintenanceDate: Long = 0L, // Timestamp lần bảo dưỡng gần nhất
    val nextMaintenanceDate: Long = 0L, // Timestamp lần bảo dưỡng tiếp theo

    val notes: String = "", // Ghi chú kỹ thuật khác
    val latitude: Double = 0.0,
    val longitude: Double = 0.0
)
