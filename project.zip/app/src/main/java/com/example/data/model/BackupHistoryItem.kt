package com.example.data.model

data class BackupHistoryItem(
    val id: String,
    val actionType: String, // "EXPORT", "IMPORT", "AUTO_BACKUP"
    val timestamp: Long,
    val description: String,
    val itemCount: Int,
    val success: Boolean = true
)
