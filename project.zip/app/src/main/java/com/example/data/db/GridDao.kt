package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.model.AssignedWorkTask
import com.example.data.model.DefectRecord
import com.example.data.model.EquipmentStatus
import com.example.data.model.EquipmentType
import com.example.data.model.GridEquipment
import com.example.data.model.MaintenanceRecord
import com.example.data.model.PeriodicInspection
import com.example.data.model.SafetyCorridorRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface GridDao {

    // --- Thiết bị lưới điện (Grid Equipment) ---
    @Query("SELECT COUNT(*) FROM grid_equipments")
    suspend fun getEquipmentCount(): Int

    @Query("SELECT * FROM grid_equipments ORDER BY code ASC")
    fun getAllEquipments(): Flow<List<GridEquipment>>

    @Query("SELECT * FROM grid_equipments WHERE id = :id")
    fun getEquipmentById(id: Long): Flow<GridEquipment?>

    @Query("SELECT * FROM grid_equipments WHERE type = :type ORDER BY code ASC")
    fun getEquipmentsByType(type: EquipmentType): Flow<List<GridEquipment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEquipment(equipment: GridEquipment): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllEquipments(equipments: List<GridEquipment>)

    @Update
    suspend fun updateEquipment(equipment: GridEquipment)

    @Query("UPDATE grid_equipments SET status = :status WHERE id IN (:equipmentIds)")
    suspend fun updateEquipmentStatusByIds(equipmentIds: List<Long>, status: EquipmentStatus)

    @Delete
    suspend fun deleteEquipment(equipment: GridEquipment)

    @Query("DELETE FROM periodic_inspections WHERE equipmentId = :equipmentId")
    suspend fun deleteInspectionsForEquipment(equipmentId: Long)

    @Query("DELETE FROM maintenance_records WHERE equipmentId = :equipmentId")
    suspend fun deleteMaintenanceForEquipment(equipmentId: Long)

    @Query("DELETE FROM defect_records WHERE equipmentId = :equipmentId")
    suspend fun deleteDefectsForEquipment(equipmentId: Long)

    /**
     * Xóa thiết bị cùng toàn bộ dữ liệu con liên quan (kiểm tra định kỳ, bảo dưỡng, khiếm khuyết)
     * trong cùng một transaction, tránh để lại bản ghi "mồ côi" tích lũy vĩnh viễn trong DB.
     */
    @Transaction
    suspend fun deleteEquipmentCascade(equipment: GridEquipment) {
        deleteInspectionsForEquipment(equipment.id)
        deleteMaintenanceForEquipment(equipment.id)
        deleteDefectsForEquipment(equipment.id)
        deleteEquipment(equipment)
    }

    // --- Kiểm tra định kỳ (Periodic Inspections) ---
    @Query("SELECT * FROM periodic_inspections ORDER BY inspectionDate DESC")
    fun getAllInspections(): Flow<List<PeriodicInspection>>

    @Query("SELECT * FROM periodic_inspections WHERE equipmentId = :equipmentId ORDER BY inspectionDate DESC")
    fun getInspectionsForEquipment(equipmentId: Long): Flow<List<PeriodicInspection>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInspection(inspection: PeriodicInspection): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllInspections(inspections: List<PeriodicInspection>)

    @Delete
    suspend fun deleteInspection(inspection: PeriodicInspection)

    // --- Nhật ký bảo dưỡng (Maintenance Records) ---
    @Query("SELECT * FROM maintenance_records ORDER BY maintenanceDate DESC")
    fun getAllMaintenanceRecords(): Flow<List<MaintenanceRecord>>

    @Query("SELECT * FROM maintenance_records WHERE equipmentId = :equipmentId ORDER BY maintenanceDate DESC")
    fun getMaintenanceForEquipment(equipmentId: Long): Flow<List<MaintenanceRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaintenance(record: MaintenanceRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllMaintenance(records: List<MaintenanceRecord>)

    @Delete
    suspend fun deleteMaintenance(record: MaintenanceRecord)

    // --- Khiếm khuyết & Khắc phục (Defects & Remediation) ---
    @Query("SELECT * FROM defect_records ORDER BY reportedDate DESC")
    fun getAllDefects(): Flow<List<DefectRecord>>

    @Query("SELECT * FROM defect_records WHERE equipmentId = :equipmentId ORDER BY reportedDate DESC")
    fun getDefectsForEquipment(equipmentId: Long): Flow<List<DefectRecord>>

    @Query("SELECT * FROM defect_records WHERE status != 'RESOLVED' ORDER BY reportedDate DESC")
    fun getActiveDefects(): Flow<List<DefectRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDefect(defect: DefectRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllDefects(defects: List<DefectRecord>)

    @Update
    suspend fun updateDefect(defect: DefectRecord)

    @Delete
    suspend fun deleteDefect(defect: DefectRecord)

    // --- Hành lang an toàn lưới điện (Safety Corridor) ---
    @Query("SELECT * FROM safety_corridor_records ORDER BY discoveredDate DESC")
    fun getAllCorridors(): Flow<List<SafetyCorridorRecord>>

    @Query("SELECT * FROM safety_corridor_records WHERE status != 'RESOLVED' ORDER BY discoveredDate DESC")
    fun getActiveCorridors(): Flow<List<SafetyCorridorRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCorridor(record: SafetyCorridorRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllCorridors(records: List<SafetyCorridorRecord>)

    @Update
    suspend fun updateCorridor(record: SafetyCorridorRecord)

    @Delete
    suspend fun deleteCorridor(record: SafetyCorridorRecord)

    // --- Công việc phân công & Thống kê báo cáo (Assigned Work Tasks) ---
    @Query("SELECT * FROM assigned_work_tasks ORDER BY assignedDate DESC")
    fun getAllAssignedTasks(): Flow<List<AssignedWorkTask>>

    @Query("SELECT * FROM assigned_work_tasks WHERE id = :id")
    fun getAssignedTaskById(id: Long): Flow<AssignedWorkTask?>

    @Query("SELECT * FROM assigned_work_tasks WHERE status != 'SUBMITTED_QLVH' ORDER BY assignedDate DESC")
    fun getActiveAssignedTasks(): Flow<List<AssignedWorkTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssignedTask(task: AssignedWorkTask): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAssignedTasks(tasks: List<AssignedWorkTask>)

    @Update
    suspend fun updateAssignedTask(task: AssignedWorkTask)

    @Delete
    suspend fun deleteAssignedTask(task: AssignedWorkTask)

    @Query("DELETE FROM assigned_work_tasks WHERE id = :id")
    suspend fun deleteAssignedTaskById(id: Long)

    // --- Làm trắng dữ liệu (Clear Data) ---
    @Query("DELETE FROM grid_equipments")
    suspend fun clearAllEquipments()

    @Query("DELETE FROM periodic_inspections")
    suspend fun clearAllInspections()

    @Query("DELETE FROM maintenance_records")
    suspend fun clearAllMaintenance()

    @Query("DELETE FROM defect_records")
    suspend fun clearAllDefects()

    @Query("DELETE FROM safety_corridor_records")
    suspend fun clearAllCorridors()

    @Query("DELETE FROM assigned_work_tasks")
    suspend fun clearAllAssignedTasks()
}
