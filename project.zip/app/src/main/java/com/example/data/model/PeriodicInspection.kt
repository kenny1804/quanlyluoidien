package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "periodic_inspections",
    indices = [Index(value = ["equipmentId"])]
)
data class PeriodicInspection(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val equipmentId: Long,
    val equipmentCode: String,
    val inspectionDate: Long = System.currentTimeMillis(),
    val inspectorName: String, // Người kiểm tra
    val inspectionType: String = "Định kỳ tháng", // Định kỳ ngày, đo phát nhiệt đêm, đột xuất sau bão
    val temperatureJoints: String = "", // Nhiệt độ mối nối tiếp điểm đo camera nhiệt (e.g. 45°C)
    val insulatorCondition: String = "Tốt, sạch sẽ", // Sứ cách điện
    val groundingCondition: String = "Đạt tiêu chuẩn", // Dây tiếp địa, cọc tiếp địa
    val sf6OrOilStatus: String = "Bình thường", // Áp lực khí SF6 / Dầu
    val resultStatus: String = "Đạt yêu cầu", // Đạt yêu cầu / Có khiếm khuyết
    val notes: String = "" // Ghi chú kiểm tra
)
