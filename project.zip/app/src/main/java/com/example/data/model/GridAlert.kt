package com.example.data.model

enum class AlertType(val displayName: String) {
    PERIODIC_INSPECTION_OVERDUE("Quá hạn kiểm tra"),
    PERIODIC_INSPECTION_DUE_SOON("Sắp đến hạn kiểm tra"),
    ACTIVE_DEFECT_CRITICAL("Sự cố khẩn cấp"),
    ACTIVE_DEFECT_NORMAL("Khiếm khuyết lưới điện"),
    MAINTENANCE_DUE("Đến hạn bảo dưỡng"),
    MAINTENANCE_OPERATION_COUNT("Số lần thao tác cao"),
    FUSE_CHECK_NEEDED("Kiểm tra dây chì"),
    CORRIDOR_VIOLATION("Vi phạm hành lang an toàn")
}

enum class AlertSeverity(val displayName: String) {
    CRITICAL("Nguy cấp"),
    WARNING("Cảnh báo"),
    INFO("Nhắc nhở")
}

enum class AlertActionType {
    INSPECT,
    RESOLVE_DEFECT,
    MAINTAIN,
    REPLACE_FUSE,
    RESOLVE_CORRIDOR,
    VIEW_DETAILS
}

data class GridAlert(
    val id: String,
    val equipmentId: Long,
    val equipmentCode: String,
    val equipmentName: String,
    val equipmentType: EquipmentType,
    val lineName: String,
    val poleNumber: String,
    val alertType: AlertType,
    val severity: AlertSeverity,
    val title: String,
    val description: String,
    val details: String,
    val timestamp: Long,
    val recommendedAction: String,
    val actionType: AlertActionType
)
