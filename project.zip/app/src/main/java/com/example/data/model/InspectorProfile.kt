package com.example.data.model

data class InspectorProfile(
    val inspectorName: String = "Nguyễn Văn A",
    val inspectorTitle: String = "Cán bộ Kỹ thuật Vận hành",
    val teamName: String = "Tổ Quản Lý Vận Hành Lưới Điện - PCAG",
    val companyName: String = "CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)",
    val managedArea: String = "Đường dây 471 An Giang",
    val phone: String = "0912.345.678"
)
