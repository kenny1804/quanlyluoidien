package com.example.data.repository

import com.example.data.db.GridDao
import com.example.data.model.AssignedWorkTask
import com.example.data.model.DefectRecord
import com.example.data.model.EquipmentType
import com.example.data.model.GridEquipment
import com.example.data.model.MaintenanceRecord
import com.example.data.model.PeriodicInspection
import com.example.data.model.SafetyCorridorRecord
import kotlinx.coroutines.flow.Flow

class GridRepository(private val dao: GridDao) {

    val allEquipments: Flow<List<GridEquipment>> = dao.getAllEquipments()
    val allInspections: Flow<List<PeriodicInspection>> = dao.getAllInspections()
    val allMaintenanceRecords: Flow<List<MaintenanceRecord>> = dao.getAllMaintenanceRecords()
    val allDefects: Flow<List<DefectRecord>> = dao.getAllDefects()
    val activeDefects: Flow<List<DefectRecord>> = dao.getActiveDefects()
    val allCorridors: Flow<List<SafetyCorridorRecord>> = dao.getAllCorridors()
    val activeCorridors: Flow<List<SafetyCorridorRecord>> = dao.getActiveCorridors()
    val allAssignedTasks: Flow<List<AssignedWorkTask>> = dao.getAllAssignedTasks()
    val activeAssignedTasks: Flow<List<AssignedWorkTask>> = dao.getActiveAssignedTasks()

    fun getEquipmentById(id: Long): Flow<GridEquipment?> = dao.getEquipmentById(id)

    fun getEquipmentsByType(type: EquipmentType): Flow<List<GridEquipment>> = dao.getEquipmentsByType(type)

    fun getInspectionsForEquipment(equipmentId: Long): Flow<List<PeriodicInspection>> =
        dao.getInspectionsForEquipment(equipmentId)

    fun getMaintenanceForEquipment(equipmentId: Long): Flow<List<MaintenanceRecord>> =
        dao.getMaintenanceForEquipment(equipmentId)

    fun getDefectsForEquipment(equipmentId: Long): Flow<List<DefectRecord>> =
        dao.getDefectsForEquipment(equipmentId)

    fun getAssignedTaskById(id: Long): Flow<AssignedWorkTask?> = dao.getAssignedTaskById(id)

    suspend fun insertEquipment(equipment: GridEquipment): Long = dao.insertEquipment(equipment)

    suspend fun updateEquipment(equipment: GridEquipment) = dao.updateEquipment(equipment)

    suspend fun updateEquipmentStatusByIds(equipmentIds: List<Long>, status: com.example.data.model.EquipmentStatus) =
        dao.updateEquipmentStatusByIds(equipmentIds, status)

    suspend fun deleteEquipment(equipment: GridEquipment) = dao.deleteEquipmentCascade(equipment)

    suspend fun insertInspection(inspection: PeriodicInspection): Long = dao.insertInspection(inspection)

    suspend fun deleteInspection(inspection: PeriodicInspection) = dao.deleteInspection(inspection)

    suspend fun insertMaintenance(record: MaintenanceRecord): Long = dao.insertMaintenance(record)

    suspend fun deleteMaintenance(record: MaintenanceRecord) = dao.deleteMaintenance(record)

    suspend fun insertDefect(defect: DefectRecord): Long = dao.insertDefect(defect)

    suspend fun updateDefect(defect: DefectRecord) = dao.updateDefect(defect)

    suspend fun deleteDefect(defect: DefectRecord) = dao.deleteDefect(defect)

    suspend fun insertCorridor(record: SafetyCorridorRecord): Long = dao.insertCorridor(record)

    suspend fun updateCorridor(record: SafetyCorridorRecord) = dao.updateCorridor(record)

    suspend fun deleteCorridor(record: SafetyCorridorRecord) = dao.deleteCorridor(record)

    suspend fun insertAssignedTask(task: AssignedWorkTask): Long = dao.insertAssignedTask(task)

    suspend fun updateAssignedTask(task: AssignedWorkTask) = dao.updateAssignedTask(task)

    suspend fun deleteAssignedTask(task: AssignedWorkTask) = dao.deleteAssignedTask(task)

    suspend fun deleteAssignedTaskById(id: Long) = dao.deleteAssignedTaskById(id)

    suspend fun clearAllData() {
        dao.clearAllAssignedTasks()
        dao.clearAllCorridors()
        dao.clearAllDefects()
        dao.clearAllMaintenance()
        dao.clearAllInspections()
        dao.clearAllEquipments()
    }

    suspend fun importAllData(
        equipments: List<GridEquipment>,
        tasks: List<AssignedWorkTask>,
        defects: List<DefectRecord>,
        corridors: List<SafetyCorridorRecord>,
        inspections: List<PeriodicInspection> = emptyList(),
        maintenance: List<MaintenanceRecord> = emptyList()
    ) {
        if (equipments.isNotEmpty()) dao.insertAllEquipments(equipments)
        if (tasks.isNotEmpty()) dao.insertAllAssignedTasks(tasks)
        if (defects.isNotEmpty()) dao.insertAllDefects(defects)
        if (corridors.isNotEmpty()) dao.insertAllCorridors(corridors)
        if (inspections.isNotEmpty()) dao.insertAllInspections(inspections)
        if (maintenance.isNotEmpty()) dao.insertAllMaintenance(maintenance)
    }
}
