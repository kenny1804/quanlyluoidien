package com.example.data.repository

import android.content.Context
import com.example.util.SubstationLocation
import org.json.JSONArray
import org.json.JSONObject

object SubstationManager {
    private const val PREF_NAME = "evn_substation_prefs"
    private const val KEY_SUBSTATIONS = "saved_substations_json"

    val DEFAULT_SUBSTATIONS = listOf(
        SubstationLocation(
            id = 1L,
            name = "TBA 110kV E1.1 An Giang",
            code = "TBA-E1.1",
            voltage = "110/22kV - 2x63MVA",
            latitude = 10.3700,
            longitude = 105.4150,
            isLocked = false
        ),
        SubstationLocation(
            id = 2L,
            name = "TBA 110kV Châu Đốc (E1.2)",
            code = "TBA-E1.2",
            voltage = "110/22kV - 40MVA",
            latitude = 10.7000,
            longitude = 105.1200,
            isLocked = false
        )
    )

    fun getSubstations(context: Context): List<SubstationLocation> {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_SUBSTATIONS, null)
        if (jsonStr.isNullOrBlank()) {
            return DEFAULT_SUBSTATIONS
        }
        return try {
            val jsonArray = JSONArray(jsonStr)
            val list = mutableListOf<SubstationLocation>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    SubstationLocation(
                        id = obj.optLong("id", System.currentTimeMillis() + i),
                        name = obj.optString("name", "Trạm 110kV"),
                        code = obj.optString("code", "TBA-XX"),
                        voltage = obj.optString("voltage", "110/22kV"),
                        latitude = obj.optDouble("latitude", 10.3700),
                        longitude = obj.optDouble("longitude", 105.4150),
                        isLocked = obj.optBoolean("isLocked", false)
                    )
                )
            }
            if (list.isEmpty()) DEFAULT_SUBSTATIONS else list
        } catch (e: Exception) {
            DEFAULT_SUBSTATIONS
        }
    }

    fun saveSubstations(context: Context, list: List<SubstationLocation>) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val jsonArray = JSONArray()
        list.forEach { sub ->
            val obj = JSONObject().apply {
                put("id", sub.id)
                put("name", sub.name)
                put("code", sub.code)
                put("voltage", sub.voltage)
                put("latitude", sub.latitude)
                put("longitude", sub.longitude)
                put("isLocked", sub.isLocked)
            }
            jsonArray.put(obj)
        }
        prefs.edit().putString(KEY_SUBSTATIONS, jsonArray.toString()).apply()
    }
}
