package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class WorkTaskStatus(val label: String) {
    NEW("Mới phân công"),
    IN_PROGRESS("Đang thực hiện"),
    COMPLETED("Đã thống kê xong"),
    SUBMITTED_QLVH("Đã gửi về QLVH")
}

@Entity(tableName = "assigned_work_tasks")
data class AssignedWorkTask(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String, // Tiêu đề công việc cá nhân được giao (Ví dụ: Thống kê tiếp địa bị mất tuyến 471)
    val assignedBy: String = "Tổ Kỹ thuật / Đội QLVH", // Đơn vị / Sổ sách phân công
    val assignee: String, // Cá nhân được phân công
    val category: String = "Tiếp địa & Nối đất", // Tiếp địa & Nối đất, Biển báo an toàn, Dây néo & Móng cột, Phụ kiện xà sứ, v.v.
    val lineName: String, // Tuyến đường dây (Ví dụ: Tuyến 471 E1.1)
    val spanLocation: String = "", // Đoạn cột / Vị trí (Ví dụ: Cột 12 đến 48)
    val targetScope: String = "", // Quy mô kiểm tra (Ví dụ: 36 vị trí cột)
    val recordedCount: Int = 0, // Số lượng thống kê được (Ví dụ: 4)
    val unit: String = "vị trí", // Đơn vị tính (bộ, vị trí, mét, chiếc)
    val description: String = "", // Mô tả yêu cầu công việc
    val detailedStatistics: String = "", // Chi tiết thống kê hiện trường (Ví dụ: Cột 15: mất 3.5m dây tiếp địa...)
    val proposedRemedy: String = "", // Đề xuất xử lý / dự trù vật tư
    val assignedDate: Long = System.currentTimeMillis(),
    val deadlineDate: Long? = null,
    val status: WorkTaskStatus = WorkTaskStatus.IN_PROGRESS,
    val submittedDate: Long? = null, // Thời gian gửi về QLVH
    val reportCode: String? = null, // Mã số phiếu gửi QLVH (Ví dụ: BC-QLVH-2026-042)
    val qlvhRecipient: String = "Tổ Kỹ thuật & Quản lý vận hành", // Bộ phận nhận báo cáo
    val priority: String = "Quan trọng" // Khẩn cấp, Quan trọng, Thường
)
