package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "defect_records",
    indices = [Index(value = ["equipmentId"])]
)
data class DefectRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val equipmentId: Long? = null,
    val equipmentCode: String? = null,
    val title: String, // Tiêu đề khiếm khuyết
    val severity: DefectSeverity = DefectSeverity.MAJOR, // Khẩn cấp, Nghiêm trọng, Trung bình, Theo dõi
    val category: String = "Thiết bị", // Thiết bị, Mối nối tiếp xúc, Cách điện sứ, Tiếp địa, Tủ điều khiển, Dây chì
    val reportedDate: Long = System.currentTimeMillis(),
    val reportedBy: String, // Người phát hiện
    val description: String, // Mô tả chi tiết khiếm khuyết
    val actionPlan: String = "", // Biện pháp xử lý dự kiến
    val status: DefectStatus = DefectStatus.PENDING, // PENDING, IN_PROGRESS, RESOLVED
    val resolvedDate: Long? = null, // Ngày hoàn thành khắc phục
    val resolvedBy: String? = null, // Người / Đội thực hiện khắc phục
    val resolutionNotes: String? = null, // Biên bản / Nội dung đã khắc phục
    val photoBase64: String? = null // Ảnh chụp hiện trường đính kèm (Base64)
)
