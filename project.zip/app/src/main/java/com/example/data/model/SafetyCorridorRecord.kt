package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "safety_corridor_records")
data class SafetyCorridorRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val lineName: String, // Tuyến đường dây (e.g. 471 E1.1)
    val spanLocation: String, // Vị trí khoảng cột (e.g. Khoảng cột 18 - 19)
    val hazardType: HazardType = HazardType.TREE, // Cây xanh, Nhà cửa công trình, Thiết bị & Khác
    val description: String, // Mô tả vi phạm
    val currentDistance: String, // Khoảng cách hiện tại tới dây pha (e.g. "1.2m (yêu cầu >= 2.0m)")
    val riskLevel: HazardRiskLevel = HazardRiskLevel.HIGH,
    val discoveredDate: Long = System.currentTimeMillis(),
    val status: CorridorStatus = CorridorStatus.VIOLATION_EXISTING, // Chưa xử lý, Đang xử lý, Đã xử lý an toàn
    val clearedDate: Long? = null, // Ngày hoàn thành phát quang / xử lý
    val clearedBy: String? = null, // Đội xử lý / Đơn vị thực hiện
    val clearanceActionTaken: String? = null, // Nội dung biện pháp đã thực hiện
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val photoBase64: String? = null // Ảnh chụp hiện trường đính kèm (Base64)
)
