package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "maintenance_records",
    indices = [Index(value = ["equipmentId"])]
)
data class MaintenanceRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val equipmentId: Long,
    val equipmentCode: String,
    val maintenanceDate: Long = System.currentTimeMillis(),
    val maintenanceType: String = "Bảo dưỡng định kỳ", // Bảo dưỡng định kỳ, Sửa chữa lớn, Hotline, Thí nghiệm
    val workUnit: String, // Đội công tác / Đơn vị thực hiện
    val content: String, // Nội dung công việc thực hiện
    val partsReplaced: String = "", // Vật tư phụ kiện thay thế
    val outcome: String = "Đạt tiêu chuẩn vận hành", // Kết quả nghiệm thu
    val supervisor: String = "" // Người giám sát an toàn / Chỉ huy trực tiếp
)
