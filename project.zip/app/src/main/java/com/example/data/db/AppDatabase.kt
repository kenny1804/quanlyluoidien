package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.AssignedWorkTask
import com.example.data.model.CorridorStatus
import com.example.data.model.DefectRecord
import com.example.data.model.DefectSeverity
import com.example.data.model.DefectStatus
import com.example.data.model.EquipmentStatus
import com.example.data.model.EquipmentType
import com.example.data.model.GridEquipment
import com.example.data.model.HazardRiskLevel
import com.example.data.model.HazardType
import com.example.data.model.MaintenanceRecord
import com.example.data.model.PeriodicInspection
import com.example.data.model.SafetyCorridorRecord
import com.example.data.model.WorkTaskStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        GridEquipment::class,
        PeriodicInspection::class,
        MaintenanceRecord::class,
        DefectRecord::class,
        SafetyCorridorRecord::class,
        AssignedWorkTask::class
    ],
    version = 5,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun gridDao(): GridDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Migration 4 -> 5: chỉ CREATE INDEX (thuần bổ sung, không đụng tới dữ liệu hiện có)
         * để tăng tốc các truy vấn lọc/tra cứu theo equipmentId (lịch sử kiểm tra, bảo dưỡng,
         * khiếm khuyết của từng thiết bị) và làm nền tảng cho cascade delete ở tầng DAO.
         * Tên index dùng đúng quy ước mặc định của Room: index_<table>_<column>.
         */
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_periodic_inspections_equipmentId` " +
                        "ON `periodic_inspections` (`equipmentId`)"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_maintenance_records_equipmentId` " +
                        "ON `maintenance_records` (`equipmentId`)"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_defect_records_equipmentId` " +
                        "ON `defect_records` (`equipmentId`)"
                )
            }
        }

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "power_grid_management.db"
                )
                    .addMigrations(MIGRATION_4_5)
                    // CHÚ Ý: chỉ giữ lại như phương án cuối cùng cho các version cũ hơn 4 chưa
                    // từng có Migration tường minh (nợ kỹ thuật từ trước). Từ version 4 trở đi,
                    // MỌI thay đổi schema phải có Migration riêng — không được xóa dòng dưới
                    // một cách chủ quan vì sẽ làm mất toàn bộ dữ liệu ngoài hiện trường của
                    // người dùng nếu thiếu migration cho version mới.
                    .fallbackToDestructiveMigrationFrom(true, 1, 2, 3)
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(private val scope: CoroutineScope) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.gridDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: GridDao) {
            val now = System.currentTimeMillis()
            val oneDayMs = 24 * 3600 * 1000L

            val equipments = listOf(
                GridEquipment(
                    id = 1L,
                    code = "REC-471/12",
                    name = "Recloser Phân Đoạn Xuất Tuyến 471",
                    type = EquipmentType.RECLOSER,
                    lineName = "Đường dây 471 E1.1",
                    poleNumber = "Cột 24",
                    substation = "TBA 110kV E1.1",
                    manufacturer = "Cooper Power Systems",
                    model = "FXB 3 Pha Chân Không",
                    ratedVoltage = "24 kV",
                    ratedCurrent = "630 A",
                    breakingCapacity = "12.5 kA",
                    status = EquipmentStatus.OPERATIONAL,
                    installationDate = "10/04/2021",
                    controllerType = "SEL-651R Advanced Controller",
                    protectionSettings = "51P: 320A (td=0.15s), 51N: 60A (td=0.2s), 79: 3 lần (0.5s - 2s - 15s)",
                    surgeCounter = 8,
                    sf6Pressure = "Không (Chân không)",
                    groundingResistance = "4.2 Ω",
                    inspectionIntervalDays = 30,
                    lastInspectionDate = now - 12 * oneDayMs,
                    nextInspectionDate = now + 18 * oneDayMs,
                    maintenanceIntervalDays = 180,
                    lastMaintenanceDate = now - 90 * oneDayMs,
                    nextMaintenanceDate = now + 90 * oneDayMs,
                    notes = "Kết nối SCADA Trung tâm Điều độ A1 ổn định, tủ nạp ắc quy 24VDC tốt.",
                    latitude = 21.0352,
                    longitude = 105.8550
                ),
                GridEquipment(
                    id = 2L,
                    code = "LBS-473/08",
                    name = "Cầu Dao Phụ Tải Nhánh Rẽ KCN",
                    type = EquipmentType.LBS,
                    lineName = "Đường dây 473 E1.2",
                    poleNumber = "Cột 45",
                    substation = "TBA 110kV E1.2",
                    manufacturer = "Schneider Electric",
                    model = "Flusarc 24kV",
                    ratedVoltage = "24 kV",
                    ratedCurrent = "630 A",
                    breakingCapacity = "16 kA (dòng ngắn mạch chịu đựng)",
                    status = EquipmentStatus.WARNING,
                    installationDate = "15/09/2020",
                    controllerType = "Tủ RTU T200 Schneider thao tác từ xa",
                    protectionSettings = "Thao tác cắt tải dòng định mức 630A",
                    sf6Pressure = "0.048 MPa (Đang ở ngưỡng thấp cảnh báo)",
                    groundingResistance = "6.5 Ω",
                    inspectionIntervalDays = 30,
                    lastInspectionDate = now - 35 * oneDayMs, // QUÁ HẠN KIỂM TRA
                    nextInspectionDate = now - 5 * oneDayMs, // Cảnh báo quá hạn 5 ngày
                    maintenanceIntervalDays = 180,
                    lastMaintenanceDate = now - 170 * oneDayMs,
                    nextMaintenanceDate = now + 10 * oneDayMs,
                    notes = "Áp lực khí SF6 gần mức 0.045 MPa, cần chuẩn bị bình khí nạp bổ sung.",
                    latitude = 21.0495,
                    longitude = 105.8475
                ),
                GridEquipment(
                    id = 3L,
                    code = "DS-471/01",
                    name = "Cầu Dao Cách Ly Phân Pha Đầu Tuyến",
                    type = EquipmentType.DS,
                    lineName = "Đường dây 471 E1.1",
                    poleNumber = "Cột 02",
                    substation = "TBA 110kV E1.1",
                    manufacturer = "Tuấn Ân Group",
                    model = "DS 3 Pha Ngoài Trời Chém Ngang",
                    ratedVoltage = "24 kV",
                    ratedCurrent = "630 A",
                    breakingCapacity = "20 kA/1s",
                    status = EquipmentStatus.DEFECT,
                    installationDate = "05/01/2019",
                    groundingResistance = "5.1 Ω",
                    inspectionIntervalDays = 30,
                    lastInspectionDate = now - 5 * oneDayMs,
                    nextInspectionDate = now + 25 * oneDayMs,
                    maintenanceIntervalDays = 365,
                    lastMaintenanceDate = now - 200 * oneDayMs,
                    nextMaintenanceDate = now + 165 * oneDayMs,
                    notes = "Tiếp xúc ngàm pha B có vết phát nhiệt oxy hóa, đã lập phiếu khiếm khuyết xử lý.",
                    latitude = 21.0298,
                    longitude = 105.8472
                ),
                GridEquipment(
                    id = 4L,
                    code = "LA-REC-471",
                    name = "Bộ Chống Sét Van Bảo Vệ Recloser 471",
                    type = EquipmentType.LA,
                    lineName = "Đường dây 471 E1.1",
                    poleNumber = "Cột 24",
                    substation = "TBA 110kV E1.1",
                    manufacturer = "Hubbell / Ohio Brass",
                    model = "Metal Oxide Arrester (ZnO) Polymer",
                    ratedVoltage = "24 kV",
                    ratedCurrent = "10 kA (Dòng phóng xung định mức)",
                    breakingCapacity = "Class 1 Heavy Duty",
                    status = EquipmentStatus.OPERATIONAL,
                    installationDate = "10/04/2021",
                    surgeCounter = 19,
                    groundingResistance = "3.8 Ω",
                    inspectionIntervalDays = 60,
                    lastInspectionDate = now - 15 * oneDayMs,
                    nextInspectionDate = now + 45 * oneDayMs,
                    maintenanceIntervalDays = 365,
                    lastMaintenanceDate = now - 100 * oneDayMs,
                    nextMaintenanceDate = now + 265 * oneDayMs,
                    notes = "Đo dòng rò 180 uA trong giới hạn cho phép (<300 uA), tiếp địa nối đất tốt.",
                    latitude = 21.0355,
                    longitude = 105.8552
                ),
                GridEquipment(
                    id = 5L,
                    code = "FCO-TBA-DANSINH",
                    name = "Cầu Chì Tự Rơi Trạm BA Dân Sinh 250kVA",
                    type = EquipmentType.FCO,
                    lineName = "Đường dây 473 E1.2",
                    poleNumber = "Cột 18 TBA",
                    substation = "Trạm BA Dân Sinh Phường 9",
                    manufacturer = "ABB / Cooper",
                    model = "FCO 24kV 100A Polymer",
                    ratedVoltage = "24 kV",
                    ratedCurrent = "100 A",
                    breakingCapacity = "10 kA",
                    status = EquipmentStatus.OPERATIONAL,
                    installationDate = "12/08/2022",
                    fuseType = "Type K (Nóng chảy nhanh)",
                    fuseRating = "15K",
                    protectedCapacity = "250 kVA",
                    fuseReplacedDate = "15/06/2024",
                    groundingResistance = "4.0 Ω",
                    inspectionIntervalDays = 30,
                    lastInspectionDate = now - 28 * oneDayMs, // Sắp đến hạn kiểm tra (còn 2 ngày)
                    nextInspectionDate = now + 2 * oneDayMs,
                    maintenanceIntervalDays = 180,
                    lastMaintenanceDate = now - 120 * oneDayMs,
                    nextMaintenanceDate = now + 60 * oneDayMs,
                    notes = "Ống chì còn nguyên vẹn, ngàm tiếp xúc sạch, lắp đúng trị số chì 15K cho TBA 250kVA.",
                    latitude = 21.0445,
                    longitude = 105.8390
                ),
                GridEquipment(
                    id = 6L,
                    code = "LBFCO-472/05",
                    name = "Cầu Chì Cắt Có Tải Trạm Bơm Tiêu Úng",
                    type = EquipmentType.LBFCO,
                    lineName = "Đường dây 472 E1.1",
                    poleNumber = "Cột 33",
                    substation = "TBA Trạm Bơm Nông Nghiệp",
                    manufacturer = "S&C Electric Company",
                    model = "LBFCO 24kV 200A Có Buồng Phụ",
                    ratedVoltage = "24 kV",
                    ratedCurrent = "200 A",
                    breakingCapacity = "12.5 kA",
                    status = EquipmentStatus.OPERATIONAL,
                    installationDate = "22/11/2021",
                    fuseType = "Type T (Nóng chảy chậm)",
                    fuseRating = "25K",
                    protectedCapacity = "400 kVA",
                    fuseReplacedDate = "10/01/2024",
                    groundingResistance = "4.5 Ω",
                    inspectionIntervalDays = 30,
                    lastInspectionDate = now - 8 * oneDayMs,
                    nextInspectionDate = now + 22 * oneDayMs,
                    maintenanceIntervalDays = 180,
                    lastMaintenanceDate = now - 80 * oneDayMs,
                    nextMaintenanceDate = now + 100 * oneDayMs,
                    notes = "Buồng dập hồ quang phụ hoạt động tốt, cơ cấu lẫy bật trơn tru.",
                    latitude = 21.0210,
                    longitude = 105.8620
                )
            )
            dao.insertAllEquipments(equipments)

            // Phiếu kiểm tra định kỳ mẫu
            val inspections = listOf(
                PeriodicInspection(
                    id = 1L,
                    equipmentId = 1L,
                    equipmentCode = "REC-471/12",
                    inspectionDate = now - 12 * oneDayMs,
                    inspectorName = "Nguyễn Văn A - Tổ QLVH 1",
                    inspectionType = "Đo phát nhiệt đêm bằng Camera hồng ngoại",
                    temperatureJoints = "Pha A: 38°C, Pha B: 41°C, Pha C: 39°C (Môi trường 29°C)",
                    insulatorCondition = "Sứ Polymer sạch, không phóng điện bề mặt",
                    groundingCondition = "Tiếp địa chắc chắn, trị số đo 4.2 Ω",
                    sf6OrOilStatus = "Cơ cấu chân không hoạt động bình thường",
                    resultStatus = "Đạt yêu cầu",
                    notes = "Bộ đếm đóng cắt tăng thêm 2 lần do sự cố thoáng qua hôm 10/08."
                ),
                PeriodicInspection(
                    id = 2L,
                    equipmentId = 3L,
                    equipmentCode = "DS-471/01",
                    inspectionDate = now - 5 * oneDayMs,
                    inspectorName = "Trần Đình Khang - Kỹ sư Giám sát",
                    inspectionType = "Kiểm tra định kỳ tháng",
                    temperatureJoints = "Pha B ngàm tiếp xúc nhiệt độ 78°C (Cảnh báo quá nhiệt)",
                    insulatorCondition = "Sứ gốm bám bụi nhiều",
                    groundingCondition = "Đạt tiêu chuẩn",
                    sf6OrOilStatus = "Cơ khí bình thường",
                    resultStatus = "Có khiếm khuyết",
                    notes = "Ngàm tiếp xúc pha B bị phát nhiệt cao hơn pha A và C 37°C. Đã lập phiếu khiếm khuyết khẩn cấp."
                ),
                PeriodicInspection(
                    id = 3L,
                    equipmentId = 5L,
                    equipmentCode = "FCO-TBA-DANSINH",
                    inspectionDate = now - 28 * oneDayMs,
                    inspectorName = "Lê Quốc Bảo - Thợ bậc 5",
                    inspectionType = "Kiểm tra định kỳ TBA & Cầu chì",
                    temperatureJoints = "Các mối nối kẹp cực < 40°C",
                    insulatorCondition = "Polymer tốt",
                    groundingCondition = "Đạt (4.0 Ω)",
                    sf6OrOilStatus = "Bình thường",
                    resultStatus = "Đạt yêu cầu",
                    notes = "Dây chì 15K Type K đúng chủng loại thiết kế."
                )
            )
            dao.insertAllInspections(inspections)

            // Lịch sử bảo dưỡng
            val maintenance = listOf(
                MaintenanceRecord(
                    id = 1L,
                    equipmentId = 1L,
                    equipmentCode = "REC-471/12",
                    maintenanceDate = now - 90 * oneDayMs,
                    maintenanceType = "Bảo dưỡng định kỳ & Thí nghiệm Rơle",
                    workUnit = "Đội Thí nghiệm Điện Lưới phân phối",
                    content = "Vệ sinh cách điện hotline, kiểm tra nguồn nuôi UPS tủ điều khiển, thí nghiệm thông số bảo vệ quá dòng pha & chạm đất, đo thời gian đóng cắt.",
                    partsReplaced = "Thay thế bộ ắc quy dự phòng 24VDC 12Ah",
                    outcome = "Đạt tiêu chuẩn kỹ thuật vận hành EVN",
                    supervisor = "Nguyễn Hoàng Nam - Tổ Kỹ thuật"
                ),
                MaintenanceRecord(
                    id = 2L,
                    equipmentId = 6L,
                    equipmentCode = "LBFCO-472/05",
                    maintenanceDate = now - 80 * oneDayMs,
                    maintenanceType = "Bảo dưỡng cơ cấu cắt có tải",
                    workUnit = "Tổ Quản lý Lưới điện Khu vực 2",
                    content = "Bôi mỡ chuyên dụng dẫn điện tại ngàm tiếp xúc, tra dầu mỡ cơ cấu khớp xoay buồng dập hồ quang phụ, kiểm tra thử nghiệm thao tác đóng cắt không tải.",
                    partsReplaced = "Thay mới 01 ống chì dự phòng và dây chì 25K",
                    outcome = "Thao tác nhẹ nhàng, tiếp xúc điện trở thấp < 120 uΩ",
                    supervisor = "Hoàng Trọng Nghĩa - Đội trưởng"
                )
            )
            dao.insertAllMaintenance(maintenance)

            // Khiếm khuyết đang có & Đã khắc phục
            val defects = listOf(
                DefectRecord(
                    id = 1L,
                    equipmentId = 3L,
                    equipmentCode = "DS-471/01",
                    title = "Ngàm tiếp xúc pha B cầu dao cách ly phát nhiệt 78°C",
                    severity = DefectSeverity.CRITICAL,
                    category = "Mối nối tiếp xúc",
                    reportedDate = now - 5 * oneDayMs,
                    reportedBy = "Trần Đình Khang - Kỹ sư Giám sát",
                    description = "Phát hiện qua đo nhiệt độ ban đêm: ngàm kẹp cực pha B chênh lệch nhiệt độ >35°C so với các pha còn lại, có nguy cơ đánh hồ quang đứt lèo dây dẫn.",
                    actionPlan = "Đăng ký lịch cắt điện đột xuất ngày chủ nhật để ép lại đầu cốt, đánh bóng bề mặt tiếp xúc và bôi mỡ dẫn điện trung tính.",
                    status = DefectStatus.PENDING,
                    resolvedDate = null,
                    resolvedBy = null,
                    resolutionNotes = null
                ),
                DefectRecord(
                    id = 2L,
                    equipmentId = 2L,
                    equipmentCode = "LBS-473/08",
                    title = "Áp lực khí SF6 giảm dần về ngưỡng 0.048 MPa",
                    severity = DefectSeverity.MAJOR,
                    category = "Thiết bị",
                    reportedDate = now - 10 * oneDayMs,
                    reportedBy = "Nguyễn Văn A - Tổ QLVH",
                    description = "Đồng hồ đo áp lực khí SF6 tại thân buồng dập LBS giảm từ 0.052 xuống 0.048 MPa, sắp chạm ngưỡng lockout khóa thao tác (0.045 MPa).",
                    actionPlan = "Chuẩn bị van kết nối và bình khí SF6 chuyên dụng để nạp bổ sung đạt 0.055 MPa.",
                    status = DefectStatus.IN_PROGRESS,
                    resolvedDate = null,
                    resolvedBy = null,
                    resolutionNotes = null
                ),
                DefectRecord(
                    id = 3L,
                    equipmentId = 5L,
                    equipmentCode = "FCO-TBA-DANSINH",
                    title = "Dây chì FCO bị phóng điện rám đen tại đầu kẹp",
                    severity = DefectSeverity.MINOR,
                    category = "Dây chì",
                    reportedDate = now - 45 * oneDayMs,
                    reportedBy = "Lê Quốc Bảo",
                    description = "Ống chì pha C có hiện tượng phóng điện vầng quang nhẹ, bề mặt kẹp ốc siết bị oxy hóa.",
                    actionPlan = "Thay mới cụm dây chì Type K 15K và làm sạch tiếp điểm.",
                    status = DefectStatus.RESOLVED,
                    resolvedDate = now - 43 * oneDayMs,
                    resolvedBy = "Tổ sửa chữa cơ động ĐL",
                    resolutionNotes = "Đã thay mới bộ dây chì Cooper 15K đạt chuẩn, xiết lực theo quy định, đo điện trở tiếp xúc 95 uΩ đạt yêu cầu đóng điện."
                )
            )
            dao.insertAllDefects(defects)

            // Hành lang an toàn lưới điện (Cây xanh, Nhà cửa, Thiết bị khác)
            val corridorRecords = listOf(
                SafetyCorridorRecord(
                    id = 1L,
                    lineName = "Đường dây 471 E1.1",
                    spanLocation = "Khoảng cột 18 - 19",
                    hazardType = HazardType.TREE,
                    description = "Hàng cây xà cừ cổ thụ của dân cành lá vươn gần dây dẫn pha bìa, khi có gió lắc khoảng cách chỉ còn 1.2 mét.",
                    currentDistance = "1.2 m (Quy định an toàn >= 2.0 m)",
                    riskLevel = HazardRiskLevel.HIGH,
                    discoveredDate = now - 7 * oneDayMs,
                    status = CorridorStatus.PROCESSING,
                    clearedDate = null,
                    clearedBy = null,
                    clearanceActionTaken = "Đã làm việc với chủ hộ và chính quyền địa phương, cử tổ phát quang mang cưa máy chuyên dụng tỉa hạ ngọn.",
                    latitude = 21.0335,
                    longitude = 105.8525
                ),
                SafetyCorridorRecord(
                    id = 2L,
                    lineName = "Đường dây 473 E1.2",
                    spanLocation = "Khoảng cột 32 - 33",
                    hazardType = HazardType.HOUSE_BUILDING,
                    description = "Nhà dân số 124 đang dựng giàn giáo sắt cải tạo ban công tầng 3 vi phạm hành lang an toàn phóng điện.",
                    currentDistance = "1.8 m (Quy định an toàn tĩnh >= 3.0 m)",
                    riskLevel = HazardRiskLevel.HIGH,
                    discoveredDate = now - 3 * oneDayMs,
                    status = CorridorStatus.VIOLATION_EXISTING,
                    clearedDate = null,
                    clearedBy = null,
                    clearanceActionTaken = "Đã phát thông báo tạm đình chỉ thi công, yêu cầu hạ giàn giáo bọc bạt cách điện an toàn.",
                    latitude = 21.0470,
                    longitude = 105.8430
                ),
                SafetyCorridorRecord(
                    id = 3L,
                    lineName = "Đường dây 472 E1.1",
                    spanLocation = "Cột 27",
                    hazardType = HazardType.EQUIPMENT_OTHER,
                    description = "Mái tôn lợp tạm của bãi trông xe có nguy cơ bị gió lốc cuốn vào đường dây điện trung thế.",
                    currentDistance = "Khoảng cách cách ly 2.5 m",
                    riskLevel = HazardRiskLevel.MEDIUM,
                    discoveredDate = now - 20 * oneDayMs,
                    status = CorridorStatus.RESOLVED,
                    clearedDate = now - 18 * oneDayMs,
                    clearedBy = "Tổ Thanh tra An toàn & Chủ bãi xe",
                    clearanceActionTaken = "Chủ bãi xe đã tháo dỡ toàn bộ phần mái tôn cơi nới vươn ra ngoài ranh giới an toàn, nghiệm thu an toàn tuyệt đối.",
                    latitude = 21.0230,
                    longitude = 105.8580
                )
            )
            dao.insertAllCorridors(corridorRecords)

            // Công việc phân công & Thống kê báo cáo cho cá nhân (Ví dụ: Thống kê tiếp địa bị mất, biển báo...)
            val assignedTasks = listOf(
                AssignedWorkTask(
                    id = 1L,
                    title = "Thống kê hệ thống tiếp địa bị mất & cắt trộm",
                    assignedBy = "Tổ Kỹ thuật QLVH",
                    assignee = "Nguyễn Văn A",
                    category = "Tiếp địa & Nối đất",
                    lineName = "Đường dây 471 E1.1",
                    spanLocation = "Cột 12 đến Cột 48",
                    targetScope = "36 vị trí cột phân đoạn",
                    recordedCount = 4,
                    unit = "vị trí",
                    description = "Kiểm tra thực tế toàn bộ dây tiếp địa mạ đồng/đồng trần từ lèo xà xuống cọc đất. Thống kê cụ thể các vị trí bị cắt trộm để báo cáo QLVH làm phương án hoàn trả trước mùa mưa bão.",
                    detailedStatistics = "- Cột 15: Mất dây đồng trần M50 dài 3.2m từ đầu cosse xuống chân cột.\n- Cột 24: Bị cạy nắp bảo vệ, mất dây tiếp địa Recloser.\n- Cột 31: Mất 01 cọc tiếp địa bằng đồng phi 16 dài 2.4m.\n- Cột 38: Dây tiếp địa bị cắt đứt lèo tiếp xúc lưng chừng thân cột.",
                    proposedRemedy = "Cấp bổ sung 15 mét cáp đồng M50, 04 kẹp siết tiếp địa 2 bu-lông và 02 cọc tiếp địa thép mạ đồng để phục hồi tiếp đất an toàn.",
                    assignedDate = now - 4 * oneDayMs,
                    deadlineDate = now + 3 * oneDayMs,
                    status = WorkTaskStatus.IN_PROGRESS,
                    submittedDate = null,
                    reportCode = null,
                    qlvhRecipient = "Tổ QLVH Lưới Điện",
                    priority = "Khẩn cấp"
                ),
                AssignedWorkTask(
                    id = 2L,
                    title = "Rà soát bổ sung biển cảnh báo an toàn & số cột mờ",
                    assignedBy = "Tổ An toàn Chuyên trách",
                    assignee = "Trần Đình Khang",
                    category = "Biển báo an toàn",
                    lineName = "Đường dây 473 E1.2",
                    spanLocation = "Khu Công Nghiệp Hòa Bình",
                    targetScope = "25 vị trí cột qua khu dân cư",
                    recordedCount = 7,
                    unit = "vị trí",
                    description = "Rà soát hiện trạng biển 'CẤM TRÈO! ĐIỆN ÁP CAO NGUY HIỂM CHẾT NGƯỜI' và số sơn nhận diện cột bị mờ hoặc bong tróc do mưa nắng.",
                    detailedStatistics = "- Cột 04, 08, 11: Mất hẳn biển tam giác cảnh báo nguy hiểm.\n- Cột 14, 19: Sơn số cột bị phai mờ không thể nhận diện từ xa.\n- Cột 21, 23: Biển báo bị gãy tai bắt bu-lông.",
                    proposedRemedy = "Đề nghị cấp 05 biển tam giác phản quang 'CẤM TRÈO', 02 hộp sơn phản quang màu đỏ và 10 bộ đai kẹp inox.",
                    assignedDate = now - 9 * oneDayMs,
                    deadlineDate = now - 2 * oneDayMs,
                    status = WorkTaskStatus.SUBMITTED_QLVH,
                    submittedDate = now - 2 * oneDayMs,
                    reportCode = "BC-QLVH-473-018",
                    qlvhRecipient = "Tổ Kỹ thuật & Quản lý vận hành",
                    priority = "Quan trọng"
                ),
                AssignedWorkTask(
                    id = 3L,
                    title = "Kiểm tra hiện trạng bu-lông gông xà & rỉ sét phụ kiện",
                    assignedBy = "Tổ Quản lý Lưới điện Khu vực 1",
                    assignee = "Lê Quốc Bảo",
                    category = "Phụ kiện xà sứ",
                    lineName = "Đường dây 472 E1.1",
                    spanLocation = "Khoảng cột 20 đến cột 35",
                    targetScope = "15 vị trí cột vượt sông",
                    recordedCount = 2,
                    unit = "vị trí",
                    description = "Kiểm tra độ rỉ sét của bu-lông gông xà đỡ và néo qua vùng trũng ngập nước phèn chua, ghi nhận các vị trí ăn mòn nặng.",
                    detailedStatistics = "- Cột 26: Bu-lông gông xà néo pha giữa bị rỉ sét ăn mòn >30% tiết diện.\n- Cột 29: Tai giữ chuỗi cách điện néo có dấu hiệu rỗ kim loại.",
                    proposedRemedy = "Cần thay thế 02 bộ gông xà mạ kẽm nhúng nóng chịu mặn phèn trong đợt cắt điện định kỳ sắp tới.",
                    assignedDate = now - 1 * oneDayMs,
                    deadlineDate = now + 5 * oneDayMs,
                    status = WorkTaskStatus.NEW,
                    submittedDate = null,
                    reportCode = null,
                    qlvhRecipient = "Tổ Quản Lý Vận Hành Lưới Điện",
                    priority = "Bình thường"
                )
            )
            dao.insertAllAssignedTasks(assignedTasks)
        }
    }
}
