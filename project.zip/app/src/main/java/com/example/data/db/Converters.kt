package com.example.data.db

import androidx.room.TypeConverter
import com.example.data.model.CorridorStatus
import com.example.data.model.DefectSeverity
import com.example.data.model.DefectStatus
import com.example.data.model.EquipmentStatus
import com.example.data.model.EquipmentType
import com.example.data.model.HazardRiskLevel
import com.example.data.model.HazardType

class Converters {
    @TypeConverter
    fun fromEquipmentType(value: EquipmentType?): String = value?.name ?: EquipmentType.RECLOSER.name

    @TypeConverter
    fun toEquipmentType(value: String?): EquipmentType =
        try {
            value?.let { EquipmentType.valueOf(it) } ?: EquipmentType.RECLOSER
        } catch (e: Exception) {
            EquipmentType.RECLOSER
        }

    @TypeConverter
    fun fromEquipmentStatus(value: EquipmentStatus?): String = value?.name ?: EquipmentStatus.OPERATIONAL.name

    @TypeConverter
    fun toEquipmentStatus(value: String?): EquipmentStatus =
        try {
            value?.let { EquipmentStatus.valueOf(it) } ?: EquipmentStatus.OPERATIONAL
        } catch (e: Exception) {
            EquipmentStatus.OPERATIONAL
        }

    @TypeConverter
    fun fromDefectSeverity(value: DefectSeverity?): String = value?.name ?: DefectSeverity.MAJOR.name

    @TypeConverter
    fun toDefectSeverity(value: String?): DefectSeverity =
        try {
            value?.let { DefectSeverity.valueOf(it) } ?: DefectSeverity.MAJOR
        } catch (e: Exception) {
            DefectSeverity.MAJOR
        }

    @TypeConverter
    fun fromDefectStatus(value: DefectStatus?): String = value?.name ?: DefectStatus.PENDING.name

    @TypeConverter
    fun toDefectStatus(value: String?): DefectStatus =
        try {
            value?.let { DefectStatus.valueOf(it) } ?: DefectStatus.PENDING
        } catch (e: Exception) {
            DefectStatus.PENDING
        }

    @TypeConverter
    fun fromHazardType(value: HazardType?): String = value?.name ?: HazardType.TREE.name

    @TypeConverter
    fun toHazardType(value: String?): HazardType =
        try {
            value?.let { HazardType.valueOf(it) } ?: HazardType.TREE
        } catch (e: Exception) {
            HazardType.TREE
        }

    @TypeConverter
    fun fromHazardRiskLevel(value: HazardRiskLevel?): String = value?.name ?: HazardRiskLevel.HIGH.name

    @TypeConverter
    fun toHazardRiskLevel(value: String?): HazardRiskLevel =
        try {
            value?.let { HazardRiskLevel.valueOf(it) } ?: HazardRiskLevel.HIGH
        } catch (e: Exception) {
            HazardRiskLevel.HIGH
        }

    @TypeConverter
    fun fromCorridorStatus(value: CorridorStatus?): String = value?.name ?: CorridorStatus.VIOLATION_EXISTING.name

    @TypeConverter
    fun toCorridorStatus(value: String?): CorridorStatus =
        try {
            value?.let { CorridorStatus.valueOf(it) } ?: CorridorStatus.VIOLATION_EXISTING
        } catch (e: Exception) {
            CorridorStatus.VIOLATION_EXISTING
        }

    @TypeConverter
    fun fromWorkTaskStatus(value: com.example.data.model.WorkTaskStatus?): String =
        value?.name ?: com.example.data.model.WorkTaskStatus.NEW.name

    @TypeConverter
    fun toWorkTaskStatus(value: String?): com.example.data.model.WorkTaskStatus =
        try {
            value?.let { com.example.data.model.WorkTaskStatus.valueOf(it) } ?: com.example.data.model.WorkTaskStatus.NEW
        } catch (e: Exception) {
            com.example.data.model.WorkTaskStatus.NEW
        }
}
