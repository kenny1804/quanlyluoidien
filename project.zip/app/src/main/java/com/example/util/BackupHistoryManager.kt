package com.example.util

import android.content.Context
import com.example.data.model.BackupHistoryItem
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object BackupHistoryManager {
    private const val PREFS_NAME = "power_grid_backup_prefs"
    private const val KEY_HISTORY = "backup_history_json"
    private const val KEY_LAST_BACKUP_TIME = "last_backup_timestamp"
    private const val KEY_LAST_AUTO_BACKUP_TIME = "last_auto_backup_timestamp"

    // Tên file lưu snapshot Auto-Backup trong bộ nhớ riêng của app (context.filesDir).
    // TRƯỚC ĐÂY: chuỗi JSON toàn bộ DB (có thể chứa ảnh Base64, tới vài MB) được nhét thẳng
    // vào một key SharedPreferences — SharedPreferences không thiết kế cho blob lớn: toàn bộ
    // file XML backing bị nạp vào RAM mỗi lần truy cập BẤT KỲ key nào trong cùng file prefs,
    // khiến app càng dùng lâu càng ì, dễ giật/ANR. Nay chuyển sang lưu bằng file thường,
    // SharedPreferences chỉ giữ thời điểm backup gần nhất (dữ liệu nhỏ, hợp lý).
    private const val AUTO_BACKUP_FILE_NAME = "local_auto_backup_snapshot.json"

    fun recordAction(
        context: Context,
        actionType: String,
        description: String,
        itemCount: Int,
        success: Boolean = true
    ): BackupHistoryItem {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val item = BackupHistoryItem(
            id = "LOG_${now}_${(100..999).random()}",
            actionType = actionType,
            timestamp = now,
            description = description,
            itemCount = itemCount,
            success = success
        )

        val history = getHistory(context).toMutableList()
        history.add(0, item) // Thêm mới lên đầu

        // Giữ lại tối đa 30 logs gần nhất
        val trimmed = history.take(30)
        val jsonArray = JSONArray()
        trimmed.forEach { log ->
            val obj = JSONObject()
            obj.put("id", log.id)
            obj.put("actionType", log.actionType)
            obj.put("timestamp", log.timestamp)
            obj.put("description", log.description)
            obj.put("itemCount", log.itemCount)
            obj.put("success", log.success)
            jsonArray.put(obj)
        }

        prefs.edit()
            .putString(KEY_HISTORY, jsonArray.toString())
            .putLong(KEY_LAST_BACKUP_TIME, now)
            .apply()

        return item
    }

    fun getHistory(context: Context): List<BackupHistoryItem> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val rawJson = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val array = JSONArray(rawJson)
            val list = mutableListOf<BackupHistoryItem>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    BackupHistoryItem(
                        id = obj.optString("id", ""),
                        actionType = obj.optString("actionType", "EXPORT"),
                        timestamp = obj.optLong("timestamp", 0L),
                        description = obj.optString("description", ""),
                        itemCount = obj.optInt("itemCount", 0),
                        success = obj.optBoolean("success", true)
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun getLastBackupTime(context: Context): Long {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getLong(KEY_LAST_BACKUP_TIME, 0L)
    }

    // Auto-save: lưu snapshot trạng thái cục bộ định kỳ.
    // LƯU Ý: hàm này làm I/O (ghi file) — gọi từ Dispatchers.IO, không gọi trực tiếp từ Main thread.
    fun saveLocalAutoBackup(context: Context, jsonState: String, itemCount: Int) {
        try {
            File(context.filesDir, AUTO_BACKUP_FILE_NAME).writeText(jsonState, Charsets.UTF_8)
        } catch (e: Exception) {
            // Không để lỗi ghi file làm crash vòng lặp auto-save nền
            return
        }

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        prefs.edit()
            .putLong(KEY_LAST_AUTO_BACKUP_TIME, now)
            .apply()

        recordAction(
            context = context,
            actionType = "AUTO_BACKUP",
            description = "Tự động lưu sao lưu trạng thái cục bộ (Auto-Save)",
            itemCount = itemCount,
            success = true
        )
    }

    fun getLastAutoBackupTime(context: Context): Long {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getLong(KEY_LAST_AUTO_BACKUP_TIME, 0L)
    }

    // LƯU Ý: hàm này làm I/O (đọc file) — gọi từ Dispatchers.IO, không gọi trực tiếp từ Main thread.
    fun getLocalAutoBackup(context: Context): String? {
        val file = File(context.filesDir, AUTO_BACKUP_FILE_NAME)
        if (!file.exists()) return null
        return try {
            file.readText(Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
}
