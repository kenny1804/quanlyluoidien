package com.example.util

import com.example.data.model.GridEquipment
import com.example.data.model.SafetyCorridorRecord

data class SubstationLocation(
    val id: Long = 0L,
    val name: String,
    val code: String = "",
    val voltage: String,
    val latitude: Double,
    val longitude: Double,
    val isLocked: Boolean = false
)

data class FeederLine(
    val id: String,
    val name: String,
    val voltage: String,
    val colorHex: Long,
    val waypoints: List<Pair<Double, Double>>
)

object GeoCoordinates {

    val substations = listOf(
        SubstationLocation(id = 1L, name = "TBA 110kV E1.1", code = "TBA-E1.1", voltage = "110/22kV", latitude = 21.0285, longitude = 105.8450),
        SubstationLocation(id = 2L, name = "TBA 110kV E1.2", code = "TBA-E1.2", voltage = "110/22kV", latitude = 21.0420, longitude = 105.8350)
    )

    // Feeder lines route
    val feederLines = listOf(
        FeederLine(
            id = "471",
            name = "Xuất tuyến 471 E1.1",
            voltage = "22 kV",
            colorHex = 0xFF0066CC, // Electric Blue
            waypoints = listOf(
                Pair(21.0285, 105.8450), // TBA E1.1
                Pair(21.0298, 105.8472), // Cột 02 - DS-471/01
                Pair(21.0315, 105.8495), // Cột 10
                Pair(21.0335, 105.8525), // Khoảng cột 18-19 (Hành lang cây)
                Pair(21.0352, 105.8550), // Cột 24 - REC-471/12 & LA-REC-471
                Pair(21.0370, 105.8580)  // Cột 30 Cuối tuyến
            )
        ),
        FeederLine(
            id = "472",
            name = "Xuất tuyến 472 E1.1",
            voltage = "22 kV",
            colorHex = 0xFF00838F, // Substation Cyan
            waypoints = listOf(
                Pair(21.0285, 105.8450), // TBA E1.1
                Pair(21.0260, 105.8490), // Cột 12
                Pair(21.0230, 105.8580), // Cột 27 (Hành lang mái tôn)
                Pair(21.0210, 105.8620)  // Cột 33 - LBFCO-472/05
            )
        ),
        FeederLine(
            id = "473",
            name = "Xuất tuyến 473 E1.2",
            voltage = "22 kV",
            colorHex = 0xFFFF8F00, // Grid Amber
            waypoints = listOf(
                Pair(21.0420, 105.8350), // TBA E1.2
                Pair(21.0445, 105.8390), // Cột 18 TBA - FCO-TBA-DANSINH
                Pair(21.0470, 105.8430), // Khoảng cột 32-33 (Hành lang giàn giáo)
                Pair(21.0495, 105.8475), // Cột 45 - LBS-473/08
                Pair(21.0520, 105.8520)  // Cuối tuyến KCN
            )
        )
    )

    fun getEquipmentCoordinates(equipment: GridEquipment): Pair<Double, Double> {
        if (equipment.latitude != 0.0 && equipment.longitude != 0.0) {
            return Pair(equipment.latitude, equipment.longitude)
        }
        val base = when {
            equipment.lineName.contains("471") -> Pair(21.0285, 105.8450)
            equipment.lineName.contains("472") -> Pair(21.0285, 105.8450)
            equipment.lineName.contains("473") -> Pair(21.0420, 105.8350)
            else -> Pair(21.0300, 105.8400)
        }
        val poleNum = equipment.poleNumber.filter { it.isDigit() }.toIntOrNull() ?: (equipment.id.toInt() * 4)
        val lat = base.first + (poleNum * 0.00030)
        val lon = base.second + (poleNum * 0.00042)
        return Pair(lat, lon)
    }

    fun getCorridorCoordinates(corridor: SafetyCorridorRecord): Pair<Double, Double> {
        if (corridor.latitude != 0.0 && corridor.longitude != 0.0) {
            return Pair(corridor.latitude, corridor.longitude)
        }
        val base = when {
            corridor.lineName.contains("471") -> Pair(21.0285, 105.8450)
            corridor.lineName.contains("472") -> Pair(21.0285, 105.8450)
            corridor.lineName.contains("473") -> Pair(21.0420, 105.8350)
            else -> Pair(21.0300, 105.8400)
        }
        val poleNum = corridor.spanLocation.filter { it.isDigit() }.take(2).toIntOrNull() ?: (corridor.id.toInt() * 6)
        val lat = base.first + (poleNum * 0.00028)
        val lon = base.second + (poleNum * 0.00040)
        return Pair(lat, lon)
    }

    // Default geographic bounds
    const val MIN_LAT = 21.0150
    const val MAX_LAT = 21.0560
    const val MIN_LNG = 105.8300
    const val MAX_LNG = 105.8700
}
