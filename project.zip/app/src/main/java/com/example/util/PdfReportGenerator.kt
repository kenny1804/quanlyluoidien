package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.AssignedWorkTask
import com.example.data.model.DefectRecord
import com.example.data.model.EquipmentStatus
import com.example.data.model.GridEquipment
import com.example.data.model.MaintenanceRecord
import com.example.data.model.PeriodicInspection
import com.example.data.model.SafetyCorridorRecord
import android.print.PrintAttributes
import android.print.PrintManager
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfReportGenerator {

    private const val PAGE_WIDTH = 595 // A4 width at 72 dpi
    private const val PAGE_HEIGHT = 842 // A4 height at 72 dpi

    private fun hex(colorHex: Long): Int = colorHex.toInt()

    fun generateDeviceSummaryPdf(
        context: Context,
        selectedEquipments: List<GridEquipment>,
        allMaintenance: List<MaintenanceRecord>,
        allInspections: List<PeriodicInspection>,
        allDefects: List<DefectRecord>,
        allCorridors: List<SafetyCorridorRecord> = emptyList(),
        inspectorName: String = "Nguyễn Văn A",
        teamName: String = "Tổ Quản Lý Vận Hành Lưới Điện - PCAG",
        companyName: String = "CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)",
        managedArea: String = "Đường dây 471, 472",
        signatureBitmap: Bitmap? = null
    ): File {
        val pdfDocument = PdfDocument()
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val dayFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val currentTimeStr = dateFormat.format(Date())

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val totalPages = selectedEquipments.size.coerceAtLeast(1)

        selectedEquipments.forEachIndexed { index, equipment ->
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, index + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            // Background
            paint.color = Color.WHITE
            canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), PAGE_HEIGHT.toFloat(), paint)

            // DẤU CHÌM (WATERMARK): Tạo bởi Cty Điện lực An Giang (PCAG) - SPC
            canvas.save()
            canvas.rotate(-32f, PAGE_WIDTH / 2f, PAGE_HEIGHT / 2f)

            val watermarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            // Dòng 1: TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM - EVNSPC
            watermarkPaint.color = Color.argb(18, 0, 51, 102)
            watermarkPaint.textSize = 17f
            canvas.drawText("TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM - EVNSPC", PAGE_WIDTH / 2f, PAGE_HEIGHT / 2f - 70f, watermarkPaint)

            // Dòng 2: CÔNG TY ĐIỆN LỰC AN GIANG
            watermarkPaint.color = Color.argb(32, 0, 51, 102)
            watermarkPaint.textSize = 32f
            canvas.drawText("CÔNG TY ĐIỆN LỰC AN GIANG", PAGE_WIDTH / 2f, PAGE_HEIGHT / 2f - 24f, watermarkPaint)

            // Dòng 3: Dấu chữ tắt lớn PCAG
            watermarkPaint.color = Color.argb(40, 0, 51, 102)
            watermarkPaint.textSize = 54f
            canvas.drawText("PCAG", PAGE_WIDTH / 2f, PAGE_HEIGHT / 2f + 32f, watermarkPaint)

            // Dòng 4: Dấu chìm tạo bởi Cty Điện lực An Giang
            watermarkPaint.color = Color.argb(26, 0, 51, 102)
            watermarkPaint.textSize = 16f
            canvas.drawText("TẠO BỞI CTY ĐIỆN LỰC AN GIANG (PCAG)", PAGE_WIDTH / 2f, PAGE_HEIGHT / 2f + 64f, watermarkPaint)

            // Dòng 5: Bản quyền dữ liệu lưới điện
            watermarkPaint.color = Color.argb(18, 0, 51, 102)
            watermarkPaint.textSize = 12f
            canvas.drawText("HỆ THỐNG QUẢN LÝ VẬN HÀNH THIẾT BỊ LƯỚI ĐIỆN PHÂN PHỐI", PAGE_WIDTH / 2f, PAGE_HEIGHT / 2f + 88f, watermarkPaint)

            canvas.restore()

            // Header SPC banner
            paint.color = hex(0xFF003366) // SPC Dark Blue
            canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), 62f, paint)

            // SPC Title text
            paint.color = Color.WHITE
            paint.textSize = 10f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM - EVNSPC", 24f, 18f, paint)

            paint.textSize = 11f
            paint.color = hex(0xFFFFF9C4) // Soft yellow gold
            val compTitle = if (companyName.isNotBlank()) companyName else "CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)"
            canvas.drawText(compTitle, 24f, 32f, paint)

            paint.textSize = 8.2f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.color = Color.WHITE
            canvas.drawText("HỆ THỐNG QUẢN LÝ VẬN HÀNH THIẾT BỊ LƯỚI ĐIỆN PHÂN PHỐI", 24f, 45f, paint)

            paint.textSize = 7.8f
            paint.color = hex(0xFFE0E0E0)
            val areaInfo = "Đơn vị: $teamName  |  Khu vực phụ trách: ${managedArea.ifBlank { equipment.lineName }}"
            canvas.drawText(areaInfo, 24f, 56f, paint)

            // Sub-header title
            paint.color = hex(0xFF0D47A1)
            paint.textSize = 13.5f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val titleText = "BÁO CÁO KỸ THUẬT & KIỂM TRA ĐỊNH KỲ THIẾT BỊ"
            val titleWidth = paint.measureText(titleText)
            canvas.drawText(titleText, (PAGE_WIDTH - titleWidth) / 2f, 82f, paint)

            paint.color = hex(0xFF555555)
            paint.textSize = 8.5f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            val subText = "Người lập: $inspectorName | Thời điểm: $currentTimeStr | Dấu chìm: PCAG"
            val subWidth = paint.measureText(subText)
            canvas.drawText(subText, (PAGE_WIDTH - subWidth) / 2f, 96f, paint)

            // Horizontal line
            paint.color = hex(0xFF003366)
            paint.strokeWidth = 1.5f
            canvas.drawLine(24f, 103f, PAGE_WIDTH - 24f, 103f, paint)
            paint.strokeWidth = 1f

            var currentY = 125f

            // 1. Equipment Identity Header Card
            val statusColor = when (equipment.status) {
                EquipmentStatus.OPERATIONAL -> hex(0xFF2E7D32)
                EquipmentStatus.WARNING -> hex(0xFFE65100)
                EquipmentStatus.DEFECT -> hex(0xFFC62828)
                else -> hex(0xFF1565C0)
            }
            val statusText = when (equipment.status) {
                EquipmentStatus.OPERATIONAL -> "VẬN HÀNH BÌNH THƯỜNG"
                EquipmentStatus.WARNING -> "CẢNH BÁO SẮP ĐẾN HẠN"
                EquipmentStatus.DEFECT -> "CÓ KHIẾM KHUYẾT"
                else -> "ĐANG XỬ LÝ"
            }

            paint.color = hex(0xFFF0F4F8)
            val headerRect = RectF(24f, currentY, PAGE_WIDTH - 24f, currentY + 45f)
            canvas.drawRoundRect(headerRect, 6f, 6f, paint)

            paint.color = hex(0xFF0D47A1)
            paint.textSize = 13f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("[${equipment.code}] ${equipment.name}", 36f, currentY + 22f, paint)

            paint.color = hex(0xFF555555)
            paint.textSize = 9.5f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            canvas.drawText("Chủng loại: ${equipment.type.displayName}  |  Tuyến: ${equipment.lineName}  |  Vị trí: ${equipment.poleNumber}", 36f, currentY + 38f, paint)

            // Status Badge on the right
            paint.color = statusColor
            val badgeRect = RectF(PAGE_WIDTH - 170f, currentY + 12f, PAGE_WIDTH - 36f, currentY + 34f)
            canvas.drawRoundRect(badgeRect, 4f, 4f, paint)
            paint.color = Color.WHITE
            paint.textSize = 8.5f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            val stWidth = paint.measureText(statusText)
            canvas.drawText(statusText, badgeRect.left + (badgeRect.width() - stWidth) / 2f, badgeRect.top + 15f, paint)

            currentY += 60f

            // 2. Section: Thông Số Kỹ Thuật (Technical Specifications Table)
            paint.color = hex(0xFF003366)
            paint.textSize = 11f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("1. THÔNG SỐ KỸ THUẬT CHI TIẾT", 24f, currentY, paint)
            currentY += 10f

            val techParams = mutableListOf(
                "Điện áp định mức (Un)" to equipment.ratedVoltage,
                "Dòng điện định mức (In)" to equipment.ratedCurrent,
                "Dòng cắt ngắn mạch (Icn)" to equipment.breakingCapacity,
                "Trạm TBA / Xuất tuyến" to equipment.substation,
                "Hãng sản xuất" to equipment.manufacturer,
                "Kiểu loại (Model)" to equipment.model,
                "Ngày đưa vào vận hành" to equipment.installationDate.ifBlank { "Không có" },
                "Trị số tiếp địa Rtd" to equipment.groundingResistance.ifBlank { "4.0 Ω (Đạt)" }
            )

            // Special fields
            if (equipment.fuseRating.isNotBlank()) {
                techParams.add("Loại dây chì & Trị số" to "${equipment.fuseType} - ${equipment.fuseRating}")
                techParams.add("Dung lượng TBA bảo vệ" to equipment.protectedCapacity.ifBlank { "250 kVA" })
                techParams.add("Ngày thay chì gần nhất" to equipment.fuseReplacedDate.ifBlank { "Chưa ghi nhận" })
            }
            if (equipment.controllerType.isNotBlank()) {
                techParams.add("Tủ điều khiển & RTU" to equipment.controllerType)
                techParams.add("Chỉnh định bảo vệ" to equipment.protectionSettings.take(45))
            }
            if (equipment.sf6Pressure.isNotBlank()) {
                techParams.add("Áp lực khí SF6" to equipment.sf6Pressure)
            }
            if (equipment.surgeCounter > 0) {
                techParams.add("Bộ đếm sét / Đóng cắt" to "${equipment.surgeCounter} lần")
            }

            // Draw table
            val colWidth = (PAGE_WIDTH - 48f) / 2f
            val rowHeight = 18f
            val numRows = (techParams.size + 1) / 2

            // Table background & border
            paint.color = hex(0xFFFAFAFA)
            canvas.drawRect(24f, currentY, PAGE_WIDTH - 24f, currentY + numRows * rowHeight, paint)
            paint.color = hex(0xFFD0D7DE)
            paint.style = Paint.Style.STROKE
            canvas.drawRect(24f, currentY, PAGE_WIDTH - 24f, currentY + numRows * rowHeight, paint)

            for (r in 0 until numRows) {
                val yLine = currentY + (r + 1) * rowHeight
                if (r < numRows - 1) {
                    canvas.drawLine(24f, yLine, PAGE_WIDTH - 24f, yLine, paint)
                }
                // Vertical divider
                canvas.drawLine(24f + colWidth, currentY, 24f + colWidth, currentY + numRows * rowHeight, paint)

                // Left cell
                val idx1 = r * 2
                if (idx1 < techParams.size) {
                    val item = techParams[idx1]
                    boldPaint.textSize = 8.5f
                    canvas.drawText(item.first + ":", 28f, currentY + r * rowHeight + 13f, boldPaint)
                    textPaint.textSize = 8.5f
                    canvas.drawText(item.second, 28f + 115f, currentY + r * rowHeight + 13f, textPaint)
                }

                // Right cell
                val idx2 = r * 2 + 1
                if (idx2 < techParams.size) {
                    val item = techParams[idx2]
                    boldPaint.textSize = 8.5f
                    canvas.drawText(item.first + ":", 24f + colWidth + 6f, currentY + r * rowHeight + 13f, boldPaint)
                    textPaint.textSize = 8.5f
                    canvas.drawText(item.second, 24f + colWidth + 120f, currentY + r * rowHeight + 13f, textPaint)
                }
            }
            paint.style = Paint.Style.FILL

            currentY += numRows * rowHeight + 18f

            // 3. Section: Lịch Sử Bảo Dưỡng Gần Nhất (Recent Maintenance History)
            paint.color = hex(0xFF003366)
            paint.textSize = 11f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("2. LỊCH SỬ BẢO DƯỠNG & SỬA CHỮA GẦN NHẤT", 24f, currentY, paint)
            currentY += 12f

            val eqMaintenance = allMaintenance.filter { it.equipmentId == equipment.id }

            if (eqMaintenance.isEmpty()) {
                paint.color = hex(0xFFF9F9F9)
                canvas.drawRect(24f, currentY, PAGE_WIDTH - 24f, currentY + 32f, paint)
                textPaint.color = hex(0xFF666666)
                textPaint.textSize = 9f
                canvas.drawText("• Chưa có dữ liệu ghi nhận đợt bảo dưỡng lớn cho thiết bị này. Chu kỳ bảo dưỡng: ${equipment.maintenanceIntervalDays} ngày/lần.", 32f, currentY + 18f, textPaint)
                textPaint.color = Color.BLACK
                currentY += 40f
            } else {
                // Table header for maintenance
                paint.color = hex(0xFFE3F2FD)
                canvas.drawRect(24f, currentY, PAGE_WIDTH - 24f, currentY + 20f, paint)
                boldPaint.textSize = 8f
                boldPaint.color = hex(0xFF0D47A1)
                canvas.drawText("NGÀY", 28f, currentY + 14f, boldPaint)
                canvas.drawText("LOẠI HÌNH BẢO DƯỠNG", 90f, currentY + 14f, boldPaint)
                canvas.drawText("ĐƠN VỊ THỰC HIỆN", 230f, currentY + 14f, boldPaint)
                canvas.drawText("NỘI DUNG & LINH KIỆN THAY MỚI", 340f, currentY + 14f, boldPaint)
                boldPaint.color = Color.BLACK

                currentY += 20f

                eqMaintenance.take(3).forEach { m ->
                    paint.color = hex(0xFFFAFAFA)
                    canvas.drawRect(24f, currentY, PAGE_WIDTH - 24f, currentY + 34f, paint)
                    paint.color = hex(0xFFE0E0E0)
                    paint.style = Paint.Style.STROKE
                    canvas.drawRect(24f, currentY, PAGE_WIDTH - 24f, currentY + 34f, paint)
                    paint.style = Paint.Style.FILL

                    textPaint.textSize = 8f
                    canvas.drawText(dayFormat.format(Date(m.maintenanceDate)), 28f, currentY + 14f, textPaint)
                    canvas.drawText(m.maintenanceType.take(28), 90f, currentY + 14f, textPaint)
                    canvas.drawText(m.workUnit.take(24), 230f, currentY + 14f, textPaint)

                    val summaryContent = "${m.content.take(45)}... (LK: ${m.partsReplaced ?: "Không"})"
                    canvas.drawText(summaryContent, 340f, currentY + 14f, textPaint)

                    boldPaint.textSize = 7.5f
                    boldPaint.color = hex(0xFF2E7D32)
                    canvas.drawText("Nghiệm thu: ${m.outcome}", 90f, currentY + 26f, boldPaint)
                    boldPaint.color = Color.BLACK

                    currentY += 36f
                }
                currentY += 10f
            }

            // 4. Section: Phiếu Kiểm Tra Định Kỳ & Nhiệt Độ Gần Nhất
            paint.color = hex(0xFF003366)
            paint.textSize = 11f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("3. KẾT QUẢ KIỂM TRA ĐỊNH KỲ & ĐO NHIỆT ĐỘ HỒNG NGOẠI", 24f, currentY, paint)
            currentY += 12f

            val eqInspections = allInspections.filter { it.equipmentId == equipment.id }
            val latestInspection = eqInspections.firstOrNull()

            if (latestInspection != null) {
                paint.color = hex(0xFFF4F6F8)
                val inspRect = RectF(24f, currentY, PAGE_WIDTH - 24f, currentY + 58f)
                canvas.drawRoundRect(inspRect, 4f, 4f, paint)

                boldPaint.textSize = 8.5f
                canvas.drawText("Lần kiểm tra gần nhất:", 34f, currentY + 16f, boldPaint)
                textPaint.textSize = 8.5f
                canvas.drawText("${dayFormat.format(Date(latestInspection.inspectionDate))} (${latestInspection.inspectorName})", 140f, currentY + 16f, textPaint)

                boldPaint.textSize = 8.5f
                canvas.drawText("Nhiệt độ mối nối pha:", 34f, currentY + 30f, boldPaint)
                textPaint.textSize = 8.5f
                canvas.drawText(latestInspection.temperatureJoints, 140f, currentY + 30f, textPaint)

                boldPaint.textSize = 8.5f
                canvas.drawText("Tình trạng cách điện/sứ:", 34f, currentY + 44f, boldPaint)
                textPaint.textSize = 8.5f
                canvas.drawText("${latestInspection.insulatorCondition} | Tiếp địa: ${latestInspection.groundingCondition}", 140f, currentY + 44f, textPaint)

                currentY += 66f
            } else {
                paint.color = hex(0xFFF9F9F9)
                canvas.drawRect(24f, currentY, PAGE_WIDTH - 24f, currentY + 26f, paint)
                textPaint.color = hex(0xFF666666)
                textPaint.textSize = 9f
                canvas.drawText("• Chưa có phiếu kiểm tra định kỳ trong hệ thống. Lịch kiểm tra tiếp theo: ${if (equipment.nextInspectionDate > 0) dayFormat.format(Date(equipment.nextInspectionDate)) else "Chưa đặt"}", 32f, currentY + 16f, textPaint)
                textPaint.color = Color.BLACK
                currentY += 32f
            }

            // 4. Section: Sự Cố / Khiếm Khuyết Đã Ghi Nhận & Tình Trạng Khắc Phục
            val eqDefects = allDefects.filter { it.equipmentId == equipment.id }
            if (eqDefects.isNotEmpty()) {
                paint.color = hex(0xFFC62828)
                paint.textSize = 10f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("4. SỰ CỐ / KHIẾM KHUYẾT & TÌNH TRẠNG KHẮC PHỤC (${eqDefects.size} mục)", 24f, currentY, paint)
                currentY += 12f

                eqDefects.take(2).forEach { defect ->
                    paint.color = hex(0xFFFFEBEE)
                    val defRect = RectF(24f, currentY, PAGE_WIDTH - 24f, currentY + 28f)
                    canvas.drawRoundRect(defRect, 4f, 4f, paint)

                    boldPaint.textSize = 8f
                    boldPaint.color = hex(0xFFC62828)
                    canvas.drawText("[${defect.severity.label}] ${defect.title} (${defect.status.label})", 32f, currentY + 12f, boldPaint)
                    textPaint.textSize = 7.5f
                    canvas.drawText("BP khắc phục: ${defect.actionPlan ?: "Đang xử lý"} ${if (defect.resolutionNotes != null) "• Đã xử lý: ${defect.resolutionNotes}" else ""}", 32f, currentY + 22f, textPaint)
                    boldPaint.color = Color.BLACK

                    currentY += 32f
                }
            }

            // 5. Section: Hành Lang An Toàn, Cây Xanh, Nhà Cửa Liên Quan
            val relatedCorridors = allCorridors.filter {
                it.lineName.contains(equipment.lineName, ignoreCase = true) || equipment.lineName.contains(it.lineName, ignoreCase = true)
            }
            if (relatedCorridors.isNotEmpty()) {
                paint.color = hex(0xFF007A87)
                paint.textSize = 10f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("5. HÀNH LANG AN TOÀN, CÂY XANH & CÔNG TRÌNH LIÊN QUAN (${relatedCorridors.size} điểm)", 24f, currentY, paint)
                currentY += 12f

                relatedCorridors.take(2).forEach { corridor ->
                    paint.color = hex(0xFFE0F2F1)
                    val corRect = RectF(24f, currentY, PAGE_WIDTH - 24f, currentY + 26f)
                    canvas.drawRoundRect(corRect, 4f, 4f, paint)

                    boldPaint.textSize = 7.8f
                    boldPaint.color = hex(0xFF004D40)
                    canvas.drawText("[${corridor.hazardType.label}] ${corridor.spanLocation} • KC: ${corridor.currentDistance}", 32f, currentY + 11f, boldPaint)
                    textPaint.textSize = 7.2f
                    canvas.drawText("${corridor.description} • Tiến độ: ${corridor.status.label}", 32f, currentY + 21f, textPaint)
                    boldPaint.color = Color.BLACK

                    currentY += 30f
                }
            }

            // Signatures footer
            val signY = PAGE_HEIGHT - 105f
            val leftColCenter = 150f
            val rightColCenter = PAGE_WIDTH - 150f

            boldPaint.textSize = 9f
            boldPaint.color = hex(0xFF212121)
            val leftTitle = "CÁN BỘ KIỂM TRA / LẬP BÁO CÁO"
            val leftTitleW = boldPaint.measureText(leftTitle)
            canvas.drawText(leftTitle, leftColCenter - (leftTitleW / 2f), signY, boldPaint)

            val rightTitle = "TỔ TRƯỞNG TỔ QLVH PHÊ DUYỆT"
            val rightTitleW = boldPaint.measureText(rightTitle)
            canvas.drawText(rightTitle, rightColCenter - (rightTitleW / 2f), signY, boldPaint)

            textPaint.textSize = 7.5f
            textPaint.color = Color.GRAY
            val leftSub = "(Ký và ghi rõ họ tên)"
            val leftSubW = textPaint.measureText(leftSub)
            canvas.drawText(leftSub, leftColCenter - (leftSubW / 2f), signY + 12f, textPaint)

            val rightSub = "(Ký duyệt và ghi ý kiến tiếp nhận)"
            val rightSubW = textPaint.measureText(rightSub)
            canvas.drawText(rightSub, rightColCenter - (rightSubW / 2f), signY + 12f, textPaint)

            // Vùng chữ ký của cán bộ kiểm tra căn giữa
            val sigW = 120f
            val sigH = 46f
            val sigLeft = leftColCenter - (sigW / 2f)
            val sigTop = signY + 14f

            if (signatureBitmap != null) {
                val sigRect = RectF(sigLeft, sigTop, sigLeft + sigW, sigTop + sigH)
                canvas.drawBitmap(signatureBitmap, null, sigRect, null)
            } else {
                // Khung chữ ký điện tử xác nhận
                paint.color = hex(0xFFE3F2FD)
                val eRect = RectF(sigLeft, sigTop + 6f, sigLeft + sigW, sigTop + 38f)
                canvas.drawRoundRect(eRect, 4f, 4f, paint)
                boldPaint.textSize = 7.5f
                boldPaint.color = hex(0xFF0D47A1)
                val eText = "✓ ĐÃ XÁC THỰC KÝ ĐIỆN TỬ"
                val eW = boldPaint.measureText(eText)
                canvas.drawText(eText, leftColCenter - (eW / 2f), sigTop + 25f, boldPaint)
            }

            // Họ tên cán bộ kiểm tra căn giữa
            boldPaint.textSize = 9f
            boldPaint.color = hex(0xFF1B5E20)
            val nameW = boldPaint.measureText(inspectorName)
            canvas.drawText(inspectorName, leftColCenter - (nameW / 2f), signY + 68f, boldPaint)

            // Page footer
            paint.color = hex(0xFFCCCCCC)
            canvas.drawLine(24f, PAGE_HEIGHT - 32f, PAGE_WIDTH - 24f, PAGE_HEIGHT - 32f, paint)
            textPaint.color = hex(0xFF777777)
            textPaint.textSize = 7.5f
            canvas.drawText("Hệ Thống Lưới Điện SPC • Tạo bởi Cty Điện lực An Giang (PCAG) • Trang ${index + 1}/$totalPages", 24f, PAGE_HEIGHT - 18f, textPaint)
            val timeFoot = "Thời gian: $currentTimeStr"
            val tFootWidth = textPaint.measureText(timeFoot)
            canvas.drawText(timeFoot, PAGE_WIDTH - 24f - tFootWidth, PAGE_HEIGHT - 18f, textPaint)

            pdfDocument.finishPage(page)
        }

        val cacheDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val outputFile = File(cacheDir, "BaoCao_ThietBi_LuoiDien_PCAG_${System.currentTimeMillis()}.pdf")
        val outputStream = FileOutputStream(outputFile)
        pdfDocument.writeTo(outputStream)
        outputStream.flush()
        outputStream.close()
        pdfDocument.close()

        return outputFile
    }

    fun renderPdfPagesToBitmaps(pdfFile: File): List<Bitmap> {
        val bitmaps = mutableListOf<Bitmap>()
        try {
            val fileDescriptor = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(fileDescriptor)
            val pageCount = renderer.pageCount

            for (i in 0 until pageCount) {
                val page = renderer.openPage(i)
                val width = (page.width * 1.5f).toInt()
                val height = (page.height * 1.5f).toInt()
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bitmaps.add(bitmap)
                page.close()
            }
            renderer.close()
            fileDescriptor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return bitmaps
    }

    fun sharePdfFile(context: Context, pdfFile: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "[SPC - PCAG] Báo cáo tổng hợp thiết bị lưới điện")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Chia sẻ Báo cáo PDF Lưới điện (PCAG)"))
        } catch (e: Exception) {
            Toast.makeText(context, "Không thể chia sẻ PDF: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun sharePdfToOperationTeam(
        context: Context,
        pdfFile: File,
        teamName: String,
        inspectorName: String,
        area: String
    ) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )
            val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
            val messageBody = """
                Kính gửi: $teamName
                Đơn vị: CÔNG TY ĐIỆN LỰC AN GIANG (PCAG) - SPC
                Cán bộ kiểm tra: $inspectorName
                Khu vực quản lý: $area
                Thời gian lập báo cáo: $dateStr
                
                Kính gửi Tổ Quản Lý Vận Hành báo cáo kỹ thuật và kiểm tra định kỳ thiết bị lưới điện (file PDF đính kèm có đóng dấu chìm PCAG và chữ ký xác nhận của cán bộ kiểm tra).
            """.trimIndent()

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "[BÁO CÁO QLVH - PCAG] Báo cáo thiết bị lưới điện - $area - $inspectorName")
                putExtra(Intent.EXTRA_TEXT, messageBody)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Gửi báo cáo về Tổ Quản Lý Vận Hành"))
        } catch (e: Exception) {
            Toast.makeText(context, "Không thể gửi báo cáo: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareSingleRecordToOperationTeam(
        context: Context,
        pdfFile: File,
        reportTitle: String,
        teamName: String,
        inspectorName: String,
        area: String
    ) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )
            val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
            val messageBody = """
                Kính gửi: $teamName
                Đơn vị: CÔNG TY ĐIỆN LỰC AN GIANG (PCAG) - SPC
                Cán bộ báo cáo / kiểm tra: $inspectorName
                Khu vực quản lý: $area
                Thời gian lập: $dateStr
                
                Kính gửi Tổ Quản Lý Vận Hành $reportTitle (file PDF đính kèm có đóng dấu chìm PCAG và chữ ký xác nhận của cán bộ thực hiện).
            """.trimIndent()

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "[BÁO CÁO QLVH - PCAG] $reportTitle - $inspectorName")
                putExtra(Intent.EXTRA_TEXT, messageBody)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Gửi báo cáo qua Zalo, Telegram, Gmail..."))
        } catch (e: Exception) {
            Toast.makeText(context, "Không thể gửi báo cáo: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    enum class ShareTarget(val label: String) {
        SYSTEM_CHOOSER("Chia Sẻ Nhanh"),
        ZALO("Zalo"),
        GMAIL("Gmail"),
        TELEGRAM("Telegram")
    }

    fun sharePdfTargeted(
        context: Context,
        pdfFile: File,
        target: ShareTarget,
        subject: String,
        messageBody: String
    ) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )

            when (target) {
                ShareTarget.ZALO -> {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, subject)
                        putExtra(Intent.EXTRA_TEXT, messageBody)
                        setPackage("com.zing.zalo")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        // If Zalo is not installed, open standard chooser
                        val fallback = Intent(Intent.ACTION_SEND).apply {
                            type = "application/pdf"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            putExtra(Intent.EXTRA_SUBJECT, subject)
                            putExtra(Intent.EXTRA_TEXT, messageBody)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(fallback, "Gửi qua Zalo hoặc ứng dụng khác"))
                    }
                }
                ShareTarget.GMAIL -> {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, subject)
                        putExtra(Intent.EXTRA_TEXT, messageBody)
                        setPackage("com.google.android.gm")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        val fallback = Intent(Intent.ACTION_SEND).apply {
                            type = "application/pdf"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            putExtra(Intent.EXTRA_SUBJECT, subject)
                            putExtra(Intent.EXTRA_TEXT, messageBody)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(fallback, "Gửi qua Gmail hoặc ứng dụng email"))
                    }
                }
                ShareTarget.TELEGRAM -> {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, subject)
                        putExtra(Intent.EXTRA_TEXT, messageBody)
                        setPackage("org.telegram.messenger")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        val fallback = Intent(Intent.ACTION_SEND).apply {
                            type = "application/pdf"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            putExtra(Intent.EXTRA_SUBJECT, subject)
                            putExtra(Intent.EXTRA_TEXT, messageBody)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(fallback, "Gửi qua Telegram hoặc ứng dụng khác"))
                    }
                }
                ShareTarget.SYSTEM_CHOOSER -> {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, subject)
                        putExtra(Intent.EXTRA_TEXT, messageBody)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(intent, "Gửi báo cáo qua Zalo, Telegram, Gmail..."))
                }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Không thể gửi báo cáo: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareReportViaTarget(
        context: Context,
        pdfFile: File,
        target: ShareTarget,
        reportTitle: String,
        teamName: String,
        inspectorName: String,
        area: String
    ) {
        val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
        val messageBody = """
            Kính gửi: $teamName
            Đơn vị: CÔNG TY ĐIỆN LỰC AN GIANG (PCAG) - SPC
            Cán bộ báo cáo / kiểm tra: $inspectorName
            Khu vực quản lý: $area
            Thời gian lập: $dateStr
            
            Kính gửi Tổ Quản Lý Vận Hành $reportTitle (file PDF đính kèm có đóng dấu chìm PCAG và chữ ký xác nhận của cán bộ thực hiện).
        """.trimIndent()
        val subject = "[BÁO CÁO QLVH - PCAG] $reportTitle - $inspectorName"
        sharePdfTargeted(context, pdfFile, target, subject, messageBody)
    }

    private fun drawWatermarkAndHeader(
        canvas: Canvas,
        companyName: String,
        teamName: String,
        area: String,
        titleText: String,
        subTitleText: String
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.WHITE
        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), PAGE_HEIGHT.toFloat(), paint)

        canvas.save()
        canvas.rotate(-32f, PAGE_WIDTH / 2f, PAGE_HEIGHT / 2f)
        val watermarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        watermarkPaint.color = Color.argb(18, 0, 51, 102)
        watermarkPaint.textSize = 17f
        canvas.drawText("TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM - EVNSPC", PAGE_WIDTH / 2f, PAGE_HEIGHT / 2f - 70f, watermarkPaint)

        watermarkPaint.color = Color.argb(32, 0, 51, 102)
        watermarkPaint.textSize = 32f
        canvas.drawText("CÔNG TY ĐIỆN LỰC AN GIANG", PAGE_WIDTH / 2f, PAGE_HEIGHT / 2f - 24f, watermarkPaint)

        watermarkPaint.color = Color.argb(40, 0, 51, 102)
        watermarkPaint.textSize = 54f
        canvas.drawText("PCAG", PAGE_WIDTH / 2f, PAGE_HEIGHT / 2f + 32f, watermarkPaint)

        watermarkPaint.color = Color.argb(26, 0, 51, 102)
        watermarkPaint.textSize = 16f
        canvas.drawText("TẠO BỞI CTY ĐIỆN LỰC AN GIANG (PCAG)", PAGE_WIDTH / 2f, PAGE_HEIGHT / 2f + 64f, watermarkPaint)

        watermarkPaint.color = Color.argb(18, 0, 51, 102)
        watermarkPaint.textSize = 12f
        canvas.drawText("HỆ THỐNG QUẢN LÝ VẬN HÀNH THIẾT BỊ LƯỚI ĐIỆN PHÂN PHỐI", PAGE_WIDTH / 2f, PAGE_HEIGHT / 2f + 88f, watermarkPaint)
        canvas.restore()

        paint.color = hex(0xFF003366)
        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), 62f, paint)

        paint.color = Color.WHITE
        paint.textSize = 10f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM - EVNSPC", 24f, 18f, paint)

        paint.textSize = 11f
        paint.color = hex(0xFFFFF9C4)
        val compTitle = if (companyName.isNotBlank()) companyName else "CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)"
        canvas.drawText(compTitle, 24f, 32f, paint)

        paint.textSize = 8.2f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        paint.color = Color.WHITE
        canvas.drawText("HỆ THỐNG QUẢN LÝ VẬN HÀNH THIẾT BỊ LƯỚI ĐIỆN PHÂN PHỐI", 24f, 45f, paint)

        paint.textSize = 7.8f
        paint.color = hex(0xFFE0E0E0)
        val areaInfo = "Đơn vị: $teamName  |  Khu vực: $area"
        canvas.drawText(areaInfo, 24f, 56f, paint)

        paint.color = hex(0xFF0D47A1)
        paint.textSize = 13.5f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        val titleWidth = paint.measureText(titleText)
        canvas.drawText(titleText, (PAGE_WIDTH - titleWidth) / 2f, 82f, paint)

        if (subTitleText.isNotBlank()) {
            paint.color = hex(0xFF555555)
            paint.textSize = 8.5f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            val subWidth = paint.measureText(subTitleText)
            canvas.drawText(subTitleText, (PAGE_WIDTH - subWidth) / 2f, 95f, paint)
        }
    }

    private fun drawSignaturesAndFooter(
        canvas: Canvas,
        inspectorName: String,
        teamName: String,
        signatureBitmap: Bitmap?,
        pageText: String = "Trang 1/1"
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        val signY = PAGE_HEIGHT - 105f
        val leftColCenter = 150f
        val rightColCenter = PAGE_WIDTH - 150f

        // CỘT TRÁI: CÁN BỘ BÁO CÁO / THỰC HIỆN
        boldPaint.textSize = 9f
        boldPaint.color = hex(0xFF212121)
        val leftTitle = "CÁN BỘ BÁO CÁO / THỰC HIỆN"
        val leftTitleW = boldPaint.measureText(leftTitle)
        canvas.drawText(leftTitle, leftColCenter - (leftTitleW / 2f), signY, boldPaint)

        textPaint.textSize = 7.5f
        textPaint.color = Color.GRAY
        val leftSub = "(Ký và ghi rõ họ tên)"
        val leftSubW = textPaint.measureText(leftSub)
        canvas.drawText(leftSub, leftColCenter - (leftSubW / 2f), signY + 12f, textPaint)

        // CHỮ KÝ CĂN GIỮA TUYỆT ĐỐI THEO TRỤC CỘT
        val sigW = 120f
        val sigH = 46f
        val sigLeft = leftColCenter - (sigW / 2f)
        val sigTop = signY + 14f

        if (signatureBitmap != null) {
            val sigRect = RectF(sigLeft, sigTop, sigLeft + sigW, sigTop + sigH)
            canvas.drawBitmap(signatureBitmap, null, sigRect, null)
        } else {
            paint.color = hex(0xFFE3F2FD)
            val eRect = RectF(sigLeft, sigTop + 6f, sigLeft + sigW, sigTop + 38f)
            canvas.drawRoundRect(eRect, 4f, 4f, paint)
            boldPaint.textSize = 7.5f
            boldPaint.color = hex(0xFF0D47A1)
            val eText = "✓ ĐÃ XÁC THỰC KÝ ĐIỆN TỬ"
            val eW = boldPaint.measureText(eText)
            canvas.drawText(eText, leftColCenter - (eW / 2f), sigTop + 25f, boldPaint)
        }

        // HỌ TÊN CÁN BỘ CĂN GIỮA
        boldPaint.textSize = 9f
        boldPaint.color = hex(0xFF1B5E20)
        val nameW = boldPaint.measureText(inspectorName)
        canvas.drawText(inspectorName, leftColCenter - (nameW / 2f), signY + 68f, boldPaint)

        // CỘT PHẢI: TỔ QUẢN LÝ VẬN HÀNH TIẾP NHẬN
        boldPaint.textSize = 9f
        boldPaint.color = hex(0xFF212121)
        val rightTitle = "TỔ QUẢN LÝ VẬN HÀNH TIẾP NHẬN"
        val rightTitleW = boldPaint.measureText(rightTitle)
        canvas.drawText(rightTitle, rightColCenter - (rightTitleW / 2f), signY, boldPaint)

        textPaint.textSize = 7.5f
        textPaint.color = Color.GRAY
        val rightSub = "(Ký duyệt và ghi ý kiến tiếp nhận)"
        val rightSubW = textPaint.measureText(rightSub)
        canvas.drawText(rightSub, rightColCenter - (rightSubW / 2f), signY + 12f, textPaint)

        // Bỏ dòng Đơn vị tiếp nhận không cần thiết

        paint.color = hex(0xFFCCCCCC)
        canvas.drawLine(24f, PAGE_HEIGHT - 32f, PAGE_WIDTH - 24f, PAGE_HEIGHT - 32f, paint)
        textPaint.color = hex(0xFF777777)
        textPaint.textSize = 7.5f
        canvas.drawText("Hệ Thống Lưới Điện SPC • Tạo bởi Cty Điện lực An Giang (PCAG) • $pageText", 24f, PAGE_HEIGHT - 18f, textPaint)
        val timeFoot = "Thời gian: " + SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
        val tFootWidth = textPaint.measureText(timeFoot)
        canvas.drawText(timeFoot, PAGE_WIDTH - 24f - tFootWidth, PAGE_HEIGHT - 18f, textPaint)
    }

    private fun drawCardSection(
        canvas: Canvas,
        startY: Float,
        title: String,
        items: List<Pair<String, String>>,
        accentColor: Int = hex(0xFF003366)
    ): Float {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = 9.5f
            color = accentColor
        }
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8.5f
            color = hex(0xFF555555)
        }
        val valPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textSize = 8.5f
            color = hex(0xFF212121)
        }

        var curY = startY

        paint.color = accentColor
        paint.style = Paint.Style.FILL
        canvas.drawRect(24f, curY, 28f, curY + 14f, paint)
        canvas.drawText(title, 34f, curY + 11f, boldPaint)
        curY += 20f

        val rowHeight = 22f
        val boxHeight = items.size * rowHeight
        paint.color = hex(0xFFF9FAFB)
        canvas.drawRoundRect(RectF(24f, curY, PAGE_WIDTH - 24f, curY + boxHeight), 6f, 6f, paint)

        paint.color = hex(0xFFE5E7EB)
        paint.style = Paint.Style.STROKE
        canvas.drawRoundRect(RectF(24f, curY, PAGE_WIDTH - 24f, curY + boxHeight), 6f, 6f, paint)

        items.forEachIndexed { i, pair ->
            val rowY = curY + i * rowHeight
            if (i > 0) {
                canvas.drawLine(24f, rowY, PAGE_WIDTH - 24f, rowY, paint)
            }
            canvas.drawText(pair.first, 34f, rowY + 14f, labelPaint)
            val valText = if (pair.second.length > 65) pair.second.take(65) + "..." else pair.second
            canvas.drawText(valText, 185f, rowY + 14f, valPaint)
        }

        return curY + boxHeight + 14f
    }

    fun generateAssignedTaskPdf(
        context: Context,
        task: AssignedWorkTask,
        inspectorName: String = "Nguyễn Văn A",
        teamName: String = "Tổ Quản Lý Vận Hành Lưới Điện - PCAG",
        companyName: String = "CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)",
        managedArea: String = "Toàn tuyến lưới điện",
        signatureBitmap: Bitmap? = null
    ): File {
        val pdfDocument = PdfDocument()
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val dayFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val reportCode = task.reportCode ?: "BC-NV-${task.id}"
        drawWatermarkAndHeader(
            canvas = canvas,
            companyName = companyName,
            teamName = teamName,
            area = managedArea,
            titleText = "BÁO CÁO KẾT QUẢ THỰC HIỆN CÔNG VIỆC GIAO",
            subTitleText = "Mã phiếu: $reportCode • Ngày lập: ${dateFormat.format(Date(task.assignedDate))}"
        )

        var curY = 112f
        val taskItems = listOf(
            "Tiêu đề công việc" to task.title,
            "Đơn vị giao việc" to task.assignedBy,
            "Cán bộ được giao" to task.assignee,
            "Hạn hoàn thành" to (task.deadlineDate?.let { dayFormat.format(Date(it)) } ?: "Đúng tiến độ"),
            "Nội dung công việc" to task.description
        )
        curY = drawCardSection(canvas, curY, "I. THÔNG TIN PHÂN CÔNG CÔNG VIỆC", taskItems, hex(0xFF003366))

        val resultItems = mutableListOf(
            "Khối lượng ghi nhận" to "${task.recordedCount} ${task.unit}",
            "Chi tiết thống kê" to task.detailedStatistics.ifBlank { "Đã hoàn thành đúng chỉ tiêu" },
            "Đề xuất vật tư / giải pháp" to task.proposedRemedy.ifBlank { "Không có đề xuất thêm" },
            "Hiện trạng thực hiện" to task.status.label
        )
        curY = drawCardSection(canvas, curY, "II. KẾT QUẢ HIỆN TRƯỜNG & KIẾN NGHỊ", resultItems, hex(0xFF0277BD))

        drawSignaturesAndFooter(canvas, inspectorName, teamName, signatureBitmap, "Trang 1/1")

        pdfDocument.finishPage(page)

        val cacheDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val outputFile = File(cacheDir, "BaoCao_CongViec_${task.id}_${System.currentTimeMillis()}.pdf")
        val outputStream = FileOutputStream(outputFile)
        pdfDocument.writeTo(outputStream)
        outputStream.flush()
        outputStream.close()
        pdfDocument.close()

        return outputFile
    }

    fun generateDefectPdf(
        context: Context,
        defect: DefectRecord,
        inspectorName: String = "Nguyễn Văn A",
        teamName: String = "Tổ Quản Lý Vận Hành Lưới Điện - PCAG",
        companyName: String = "CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)",
        managedArea: String = "Toàn tuyến lưới điện",
        signatureBitmap: Bitmap? = null
    ): File {
        val pdfDocument = PdfDocument()
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val eqCode = defect.equipmentCode ?: "Thiết bị lưới điện"
        drawWatermarkAndHeader(
            canvas = canvas,
            companyName = companyName,
            teamName = teamName,
            area = managedArea,
            titleText = "PHIẾU BÁO CÁO KHIẾM KHUYẾT LƯỚI ĐIỆN VẬN HÀNH",
            subTitleText = "Thiết bị: $eqCode • Mức độ: ${defect.severity.label}"
        )

        var curY = 112f
        val defectItems = listOf(
            "Tiêu đề khiếm khuyết" to defect.title,
            "Thiết bị / Vị trí" to eqCode,
            "Hạng mục khiếm khuyết" to defect.category,
            "Mức độ rủi ro" to defect.severity.label,
            "Cán bộ phát hiện" to defect.reportedBy,
            "Thời điểm ghi nhận" to dateFormat.format(Date(defect.reportedDate))
        )
        curY = drawCardSection(canvas, curY, "I. THÔNG TIN PHÁT HIỆN KHIẾM KHUYẾT", defectItems, hex(0xFFC62828))

        val solutionItems = mutableListOf(
            "Mô tả chi tiết" to defect.description,
            "Biện pháp xử lý dự kiến" to defect.actionPlan.ifBlank { "Chờ Tổ QLVH bố trí phương án khắc phục" },
            "Tình trạng hiện tại" to defect.status.label
        )
        if (defect.resolvedDate != null) {
            solutionItems.add("Ngày hoàn thành khắc phục" to dateFormat.format(Date(defect.resolvedDate)))
        }
        if (!defect.resolvedBy.isNullOrBlank()) {
            solutionItems.add("Đơn vị khắc phục" to defect.resolvedBy)
        }
        if (!defect.resolutionNotes.isNullOrBlank()) {
            solutionItems.add("Nội dung biên bản hoàn tất" to defect.resolutionNotes)
        }

        curY = drawCardSection(canvas, curY, "II. PHƯƠNG ÁN XỬ LÝ & KẾT QUẢ KHẮC PHỤC", solutionItems, hex(0xFFD84315))

        drawSignaturesAndFooter(canvas, inspectorName, teamName, signatureBitmap, "Trang 1/1")

        pdfDocument.finishPage(page)

        val cacheDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val outputFile = File(cacheDir, "BaoCao_KhiemKhuyet_${defect.id}_${System.currentTimeMillis()}.pdf")
        val outputStream = FileOutputStream(outputFile)
        pdfDocument.writeTo(outputStream)
        outputStream.flush()
        outputStream.close()
        pdfDocument.close()

        return outputFile
    }

    fun generateCorridorPdf(
        context: Context,
        corridor: SafetyCorridorRecord,
        inspectorName: String = "Nguyễn Văn A",
        teamName: String = "Tổ Quản Lý Vận Hành Lưới Điện - PCAG",
        companyName: String = "CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)",
        managedArea: String = "Toàn tuyến lưới điện",
        signatureBitmap: Bitmap? = null
    ): File {
        val pdfDocument = PdfDocument()
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        drawWatermarkAndHeader(
            canvas = canvas,
            companyName = companyName,
            teamName = teamName,
            area = managedArea,
            titleText = "PHIẾU BÁO CÁO HÀNH LANG AN TOÀN LƯỚI ĐIỆN",
            subTitleText = "Tuyến: ${corridor.lineName} • Khoảng cột: ${corridor.spanLocation}"
        )

        var curY = 112f
        val corridorItems = listOf(
            "Tuyến đường dây" to corridor.lineName,
            "Vị trí khoảng cột" to corridor.spanLocation,
            "Loại vi phạm / Nguy cơ" to corridor.hazardType.label,
            "Mức độ rủi ro" to corridor.riskLevel.label,
            "Khoảng cách đến dây pha" to corridor.currentDistance,
            "Thời điểm phát hiện" to dateFormat.format(Date(corridor.discoveredDate))
        )
        curY = drawCardSection(canvas, curY, "I. THÔNG TIN ĐIỂM VI PHẠM HÀNH LANG", corridorItems, hex(0xFF00695C))

        val actionItems = mutableListOf(
            "Mô tả vi phạm" to corridor.description,
            "Tọa độ vị trí (GPS)" to if (corridor.latitude != 0.0) "${corridor.latitude}, ${corridor.longitude}" else "Đã ghi nhận trên bản đồ",
            "Hiện trạng xử lý" to corridor.status.label
        )
        if (corridor.clearedDate != null) {
            actionItems.add("Ngày hoàn thành phát quang" to dateFormat.format(Date(corridor.clearedDate)))
        }
        if (!corridor.clearedBy.isNullOrBlank()) {
            actionItems.add("Đơn vị thực hiện phát quang" to corridor.clearedBy)
        }
        if (!corridor.clearanceActionTaken.isNullOrBlank()) {
            actionItems.add("Nội dung biện pháp đã xử lý" to corridor.clearanceActionTaken)
        }

        curY = drawCardSection(canvas, curY, "II. NỘI DUNG XỬ LÝ & GIẢI PHÁP AN TOÀN", actionItems, hex(0xFF004D40))

        drawSignaturesAndFooter(canvas, inspectorName, teamName, signatureBitmap, "Trang 1/1")

        pdfDocument.finishPage(page)

        val cacheDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val outputFile = File(cacheDir, "BaoCao_HanhLang_${corridor.id}_${System.currentTimeMillis()}.pdf")
        val outputStream = FileOutputStream(outputFile)
        pdfDocument.writeTo(outputStream)
        outputStream.flush()
        outputStream.close()
        pdfDocument.close()

        return outputFile
    }

    fun openPdfFile(context: Context, pdfFile: File) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Mở Báo cáo PDF"))
        } catch (e: Exception) {
            Toast.makeText(context, "Không có ứng dụng đọc PDF phù hợp", Toast.LENGTH_SHORT).show()
        }
    }

    fun printPdfFile(context: Context, pdfFile: File) {
        try {
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
            if (printManager == null) {
                Toast.makeText(context, "Thiết bị không hỗ trợ dịch vụ in", Toast.LENGTH_SHORT).show()
                return
            }
            val printAdapter = object : android.print.PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: PrintAttributes?,
                    newAttributes: PrintAttributes?,
                    cancellationSignal: android.os.CancellationSignal?,
                    callback: LayoutResultCallback?,
                    extras: android.os.Bundle?
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback?.onLayoutCancelled()
                        return
                    }
                    val info = android.print.PrintDocumentInfo.Builder(pdfFile.name)
                        .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .build()
                    callback?.onLayoutFinished(info, newAttributes != oldAttributes)
                }

                override fun onWrite(
                    pages: Array<out android.print.PageRange>?,
                    destination: ParcelFileDescriptor?,
                    cancellationSignal: android.os.CancellationSignal?,
                    callback: WriteResultCallback?
                ) {
                    var input: FileInputStream? = null
                    var output: FileOutputStream? = null
                    try {
                        input = FileInputStream(pdfFile)
                        output = destination?.fileDescriptor?.let { FileOutputStream(it) }
                        if (output != null) {
                            val buf = ByteArray(8192)
                            var bytesRead: Int
                            while (input.read(buf).also { bytesRead = it } > 0) {
                                if (cancellationSignal?.isCanceled == true) {
                                    callback?.onWriteCancelled()
                                    return
                                }
                                output.write(buf, 0, bytesRead)
                            }
                            callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                        } else {
                            callback?.onWriteFailed("Không thể tạo luồng xuất file in")
                        }
                    } catch (e: Exception) {
                        callback?.onWriteFailed(e.message)
                    } finally {
                        try { input?.close() } catch (_: Exception) {}
                        try { output?.close() } catch (_: Exception) {}
                    }
                }
            }
            printManager.print("Báo cáo lưới điện - ${pdfFile.name}", printAdapter, PrintAttributes.Builder().build())
        } catch (e: Exception) {
            Toast.makeText(context, "Lỗi khi gửi lệnh in: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }
}
