package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.DefectRecord
import com.example.data.model.EquipmentStatus
import com.example.data.model.GridEquipment

object GridNotificationManager {
    const val CHANNEL_ID_EQUIPMENT_DUE = "evn_equipment_due_channel"
    const val CHANNEL_ID_DEFECT_ALERT = "evn_defect_hazard_channel"
    const val EXTRA_EQUIPMENT_ID = "extra_equipment_id"

    fun initChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return

            // Kênh cảnh báo thiết bị sắp đến hạn hoặc quá hạn kiểm tra / bảo dưỡng
            val dueChannel = NotificationChannel(
                CHANNEL_ID_EQUIPMENT_DUE,
                "Lịch Đến Hạn Kiểm Tra & Bảo Dưỡng (EVN SPC)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Cảnh báo tự động thiết bị lưới điện đến hạn kiểm tra định kỳ hoặc bảo dưỡng"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 350, 150, 350)
                setShowBadge(true)
            }

            // Kênh cảnh báo khiếm khuyết khẩn cấp
            val defectChannel = NotificationChannel(
                CHANNEL_ID_DEFECT_ALERT,
                "Cảnh Báo Khiếm Khuyết & Sự Cố Lưới Điện",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Cảnh báo khiếm khuyết thiết bị, nguy cơ sự cố hoặc vi phạm hành lang an toàn"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500)
                setShowBadge(true)
            }

            notificationManager.createNotificationChannel(dueChannel)
            notificationManager.createNotificationChannel(defectChannel)
        }
    }

    /**
     * Gửi thông báo đẩy cảnh báo thiết bị đến hạn kiểm tra hoặc bảo dưỡng
     */
    fun sendEquipmentDueNotification(
        context: Context,
        equipment: GridEquipment,
        daysRemaining: Int,
        isOverdue: Boolean
    ) {
        initChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_EQUIPMENT_ID, equipment.id)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            equipment.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isOverdue) {
            "⚠️ QUÁ HẠN: ${equipment.code} (${equipment.type.shortName})"
        } else {
            "⏰ SẮP ĐẾN HẠN: ${equipment.code} (Còn $daysRemaining ngày)"
        }

        val body = buildString {
            append("Tuyến: ${equipment.lineName} | Cột: ${equipment.poleNumber}\n")
            if (isOverdue) {
                append("Thiết bị đã quá hạn kiểm tra/bảo dưỡng. Cần lập phiếu công tác xử lý gấp.")
            } else {
                append("Hạn kiểm tra kế tiếp cần thực hiện trong vòng $daysRemaining ngày tới.")
            }
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_EQUIPMENT_DUE)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText("Tuyến ${equipment.lineName} - Cột ${equipment.poleNumber}")
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .addAction(
                R.drawable.ic_launcher_foreground,
                "Xem Chi Tiết",
                pendingIntent
            )
            .build()

        try {
            NotificationManagerCompat.from(context).notify(
                1000 + equipment.id.toInt(),
                notification
            )
        } catch (e: SecurityException) {
            // Permission not yet granted
        }
    }

    /**
     * Gửi thông báo tổng hợp cảnh báo thiết bị đến hạn định kỳ
     */
    fun sendBatchSummaryNotification(
        context: Context,
        overdueCount: Int,
        dueSoonCount: Int
    ) {
        initChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            9999,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = "⚡ EVNSPC: Cảnh Báo Thiết Bị Lưới Điện Định Kỳ"
        val body = "Phát hiện $overdueCount thiết bị quá hạn và $dueSoonCount thiết bị sắp đến hạn kiểm tra trong 7 ngày tới. Vui lòng kiểm tra danh sách trên ứng dụng."

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_EQUIPMENT_DUE)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText("Có $overdueCount thiết bị quá hạn, $dueSoonCount thiết bị sắp đến hạn.")
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(9999, notification)
        } catch (e: SecurityException) {
            // Ignore if notification permission is pending
        }
    }

    /**
     * Kiểm tra thời gian thực và tự động kích hoạt thông báo đẩy cho các thiết bị cần can thiệp
     */
    fun checkAndTriggerRealtimeAlerts(
        context: Context,
        equipments: List<GridEquipment>
    ): Int {
        val now = System.currentTimeMillis()
        val sevenDaysMs = 7L * 24 * 60 * 60 * 1000
        var triggeredCount = 0
        var overdueCount = 0
        var dueSoonCount = 0

        for (eq in equipments) {
            val nextInspection = eq.nextInspectionDate
            if (nextInspection > 0) {
                if (nextInspection < now) {
                    overdueCount++
                    val overdueDays = ((now - nextInspection) / (24 * 60 * 60 * 1000)).toInt().coerceAtLeast(1)
                    sendEquipmentDueNotification(context, eq, overdueDays, isOverdue = true)
                    triggeredCount++
                } else if (nextInspection <= now + sevenDaysMs) {
                    dueSoonCount++
                    val daysRemaining = ((nextInspection - now) / (24 * 60 * 60 * 1000)).toInt().coerceAtLeast(1)
                    sendEquipmentDueNotification(context, eq, daysRemaining, isOverdue = false)
                    triggeredCount++
                }
            } else if (eq.status == EquipmentStatus.WARNING || eq.status == EquipmentStatus.DEFECT) {
                sendEquipmentDueNotification(context, eq, 0, isOverdue = true)
                triggeredCount++
            }
        }

        if (overdueCount > 0 || dueSoonCount > 0) {
            sendBatchSummaryNotification(context, overdueCount, dueSoonCount)
        }

        return triggeredCount
    }
}
