package com.example.util

import com.example.data.model.AssignedWorkTask
import com.example.data.model.CorridorStatus
import com.example.data.model.DefectRecord
import com.example.data.model.DefectSeverity
import com.example.data.model.DefectStatus
import com.example.data.model.EquipmentStatus
import com.example.data.model.EquipmentType
import com.example.data.model.GridEquipment
import com.example.data.model.HazardRiskLevel
import com.example.data.model.HazardType
import com.example.data.model.MaintenanceRecord
import com.example.data.model.PeriodicInspection
import com.example.data.model.SafetyCorridorRecord
import com.example.data.model.WorkTaskStatus
import org.json.JSONArray
import org.json.JSONObject

data class BackupData(
    val exportTimestamp: Long = System.currentTimeMillis(),
    val appVersion: String = "1.0.0",
    val equipments: List<GridEquipment> = emptyList(),
    val tasks: List<AssignedWorkTask> = emptyList(),
    val defects: List<DefectRecord> = emptyList(),
    val corridors: List<SafetyCorridorRecord> = emptyList(),
    val inspections: List<PeriodicInspection> = emptyList(),
    val maintenance: List<MaintenanceRecord> = emptyList()
)

object GridJsonBackupHelper {

    fun exportToJson(
        equipments: List<GridEquipment>,
        tasks: List<AssignedWorkTask>,
        defects: List<DefectRecord>,
        corridors: List<SafetyCorridorRecord>,
        inspections: List<PeriodicInspection> = emptyList(),
        maintenance: List<MaintenanceRecord> = emptyList()
    ): String {
        val root = JSONObject()
        root.put("exportTimestamp", System.currentTimeMillis())
        root.put("app", "PowerGridManagerEVN")
        root.put("version", "1.0.0")

        // 1. Equipments
        val eqArray = JSONArray()
        equipments.forEach { eq ->
            val obj = JSONObject()
            obj.put("id", eq.id)
            obj.put("code", eq.code)
            obj.put("name", eq.name)
            obj.put("type", eq.type.name)
            obj.put("lineName", eq.lineName)
            obj.put("poleNumber", eq.poleNumber)
            obj.put("substation", eq.substation)
            obj.put("manufacturer", eq.manufacturer)
            obj.put("model", eq.model)
            obj.put("ratedVoltage", eq.ratedVoltage)
            obj.put("ratedCurrent", eq.ratedCurrent)
            obj.put("breakingCapacity", eq.breakingCapacity)
            obj.put("status", eq.status.name)
            obj.put("installationDate", eq.installationDate)
            obj.put("fuseType", eq.fuseType)
            obj.put("fuseRating", eq.fuseRating)
            obj.put("protectedCapacity", eq.protectedCapacity)
            obj.put("fuseReplacedDate", eq.fuseReplacedDate)
            obj.put("controllerType", eq.controllerType)
            obj.put("protectionSettings", eq.protectionSettings)
            obj.put("surgeCounter", eq.surgeCounter)
            obj.put("sf6Pressure", eq.sf6Pressure)
            obj.put("groundingResistance", eq.groundingResistance)
            obj.put("inspectionIntervalDays", eq.inspectionIntervalDays)
            obj.put("lastInspectionDate", eq.lastInspectionDate)
            obj.put("nextInspectionDate", eq.nextInspectionDate)
            obj.put("maintenanceIntervalDays", eq.maintenanceIntervalDays)
            obj.put("lastMaintenanceDate", eq.lastMaintenanceDate)
            obj.put("nextMaintenanceDate", eq.nextMaintenanceDate)
            obj.put("notes", eq.notes)
            obj.put("latitude", eq.latitude)
            obj.put("longitude", eq.longitude)
            eqArray.put(obj)
        }
        root.put("equipments", eqArray)

        // 2. Tasks
        val taskArray = JSONArray()
        tasks.forEach { t ->
            val obj = JSONObject()
            obj.put("id", t.id)
            obj.put("title", t.title)
            obj.put("assignedBy", t.assignedBy)
            obj.put("assignee", t.assignee)
            obj.put("category", t.category)
            obj.put("lineName", t.lineName)
            obj.put("spanLocation", t.spanLocation)
            obj.put("targetScope", t.targetScope)
            obj.put("recordedCount", t.recordedCount)
            obj.put("unit", t.unit)
            obj.put("description", t.description)
            obj.put("detailedStatistics", t.detailedStatistics)
            obj.put("proposedRemedy", t.proposedRemedy)
            obj.put("assignedDate", t.assignedDate)
            t.deadlineDate?.let { obj.put("deadlineDate", it) }
            obj.put("status", t.status.name)
            t.submittedDate?.let { obj.put("submittedDate", it) }
            t.reportCode?.let { obj.put("reportCode", it) }
            obj.put("qlvhRecipient", t.qlvhRecipient)
            obj.put("priority", t.priority)
            taskArray.put(obj)
        }
        root.put("tasks", taskArray)

        // 3. Defects
        val defectArray = JSONArray()
        defects.forEach { d ->
            val obj = JSONObject()
            obj.put("id", d.id)
            d.equipmentId?.let { obj.put("equipmentId", it) }
            d.equipmentCode?.let { obj.put("equipmentCode", it) }
            obj.put("title", d.title)
            obj.put("severity", d.severity.name)
            obj.put("category", d.category)
            obj.put("reportedDate", d.reportedDate)
            obj.put("reportedBy", d.reportedBy)
            obj.put("description", d.description)
            obj.put("actionPlan", d.actionPlan)
            obj.put("status", d.status.name)
            d.resolvedDate?.let { obj.put("resolvedDate", it) }
            d.resolvedBy?.let { obj.put("resolvedBy", it) }
            d.resolutionNotes?.let { obj.put("resolutionNotes", it) }
            d.photoBase64?.let { obj.put("photoBase64", it) }
            defectArray.put(obj)
        }
        root.put("defects", defectArray)

        // 4. Corridors
        val corridorArray = JSONArray()
        corridors.forEach { c ->
            val obj = JSONObject()
            obj.put("id", c.id)
            obj.put("lineName", c.lineName)
            obj.put("spanLocation", c.spanLocation)
            obj.put("hazardType", c.hazardType.name)
            obj.put("description", c.description)
            obj.put("currentDistance", c.currentDistance)
            obj.put("riskLevel", c.riskLevel.name)
            obj.put("discoveredDate", c.discoveredDate)
            obj.put("status", c.status.name)
            c.clearedDate?.let { obj.put("clearedDate", it) }
            c.clearedBy?.let { obj.put("clearedBy", it) }
            c.clearanceActionTaken?.let { obj.put("clearanceActionTaken", it) }
            obj.put("latitude", c.latitude)
            obj.put("longitude", c.longitude)
            c.photoBase64?.let { obj.put("photoBase64", it) }
            corridorArray.put(obj)
        }
        root.put("corridors", corridorArray)

        // 5. Inspections
        val inspArray = JSONArray()
        inspections.forEach { ins ->
            val obj = JSONObject()
            obj.put("id", ins.id)
            obj.put("equipmentId", ins.equipmentId)
            obj.put("equipmentCode", ins.equipmentCode)
            obj.put("inspectionDate", ins.inspectionDate)
            obj.put("inspectorName", ins.inspectorName)
            obj.put("inspectionType", ins.inspectionType)
            obj.put("temperatureJoints", ins.temperatureJoints)
            obj.put("insulatorCondition", ins.insulatorCondition)
            obj.put("groundingCondition", ins.groundingCondition)
            obj.put("sf6OrOilStatus", ins.sf6OrOilStatus)
            obj.put("resultStatus", ins.resultStatus)
            obj.put("notes", ins.notes)
            inspArray.put(obj)
        }
        root.put("inspections", inspArray)

        // 6. Maintenance
        val maintArray = JSONArray()
        maintenance.forEach { m ->
            val obj = JSONObject()
            obj.put("id", m.id)
            obj.put("equipmentId", m.equipmentId)
            obj.put("equipmentCode", m.equipmentCode)
            obj.put("maintenanceDate", m.maintenanceDate)
            obj.put("maintenanceType", m.maintenanceType)
            obj.put("workUnit", m.workUnit)
            obj.put("content", m.content)
            obj.put("partsReplaced", m.partsReplaced)
            obj.put("outcome", m.outcome)
            obj.put("supervisor", m.supervisor)
            maintArray.put(obj)
        }
        root.put("maintenance", maintArray)

        return root.toString(2)
    }

    fun parseFromJson(jsonString: String): BackupData {
        val root = JSONObject(jsonString)
        val timestamp = root.optLong("exportTimestamp", System.currentTimeMillis())
        val version = root.optString("version", "1.0.0")

        // Parse Equipments
        val eqList = mutableListOf<GridEquipment>()
        val eqArray = root.optJSONArray("equipments")
        if (eqArray != null) {
            for (i in 0 until eqArray.length()) {
                val obj = eqArray.getJSONObject(i)
                val typeStr = obj.optString("type", EquipmentType.RECLOSER.name)
                val type = try { EquipmentType.valueOf(typeStr) } catch (e: Exception) { EquipmentType.RECLOSER }
                val statusStr = obj.optString("status", EquipmentStatus.OPERATIONAL.name)
                val status = try { EquipmentStatus.valueOf(statusStr) } catch (e: Exception) { EquipmentStatus.OPERATIONAL }

                val eq = GridEquipment(
                    id = obj.optLong("id", 0L),
                    code = obj.optString("code", ""),
                    name = obj.optString("name", ""),
                    type = type,
                    lineName = obj.optString("lineName", ""),
                    poleNumber = obj.optString("poleNumber", ""),
                    substation = obj.optString("substation", ""),
                    manufacturer = obj.optString("manufacturer", ""),
                    model = obj.optString("model", ""),
                    ratedVoltage = obj.optString("ratedVoltage", "22 kV"),
                    ratedCurrent = obj.optString("ratedCurrent", "630 A"),
                    breakingCapacity = obj.optString("breakingCapacity", "12.5 kA"),
                    status = status,
                    installationDate = obj.optString("installationDate", ""),
                    fuseType = obj.optString("fuseType", "Type K"),
                    fuseRating = obj.optString("fuseRating", ""),
                    protectedCapacity = obj.optString("protectedCapacity", ""),
                    fuseReplacedDate = obj.optString("fuseReplacedDate", ""),
                    controllerType = obj.optString("controllerType", ""),
                    protectionSettings = obj.optString("protectionSettings", ""),
                    surgeCounter = obj.optInt("surgeCounter", 0),
                    sf6Pressure = obj.optString("sf6Pressure", ""),
                    groundingResistance = obj.optString("groundingResistance", ""),
                    inspectionIntervalDays = obj.optInt("inspectionIntervalDays", 30),
                    lastInspectionDate = obj.optLong("lastInspectionDate", 0L),
                    nextInspectionDate = obj.optLong("nextInspectionDate", 0L),
                    maintenanceIntervalDays = obj.optInt("maintenanceIntervalDays", 180),
                    lastMaintenanceDate = obj.optLong("lastMaintenanceDate", 0L),
                    nextMaintenanceDate = obj.optLong("nextMaintenanceDate", 0L),
                    notes = obj.optString("notes", ""),
                    latitude = obj.optDouble("latitude", 0.0),
                    longitude = obj.optDouble("longitude", 0.0)
                )
                eqList.add(eq)
            }
        }

        // Parse Tasks
        val taskList = mutableListOf<AssignedWorkTask>()
        val taskArray = root.optJSONArray("tasks")
        if (taskArray != null) {
            for (i in 0 until taskArray.length()) {
                val obj = taskArray.getJSONObject(i)
                val statusStr = obj.optString("status", WorkTaskStatus.IN_PROGRESS.name)
                val status = try { WorkTaskStatus.valueOf(statusStr) } catch (e: Exception) { WorkTaskStatus.IN_PROGRESS }

                val task = AssignedWorkTask(
                    id = obj.optLong("id", 0L),
                    title = obj.optString("title", ""),
                    assignedBy = obj.optString("assignedBy", "Tổ Kỹ thuật / Đội QLVH"),
                    assignee = obj.optString("assignee", ""),
                    category = obj.optString("category", "Tiếp địa & Nối đất"),
                    lineName = obj.optString("lineName", ""),
                    spanLocation = obj.optString("spanLocation", ""),
                    targetScope = obj.optString("targetScope", ""),
                    recordedCount = obj.optInt("recordedCount", 0),
                    unit = obj.optString("unit", "vị trí"),
                    description = obj.optString("description", ""),
                    detailedStatistics = obj.optString("detailedStatistics", ""),
                    proposedRemedy = obj.optString("proposedRemedy", ""),
                    assignedDate = obj.optLong("assignedDate", System.currentTimeMillis()),
                    deadlineDate = if (obj.has("deadlineDate")) obj.optLong("deadlineDate") else null,
                    status = status,
                    submittedDate = if (obj.has("submittedDate")) obj.optLong("submittedDate") else null,
                    reportCode = if (obj.has("reportCode")) obj.optString("reportCode") else null,
                    qlvhRecipient = obj.optString("qlvhRecipient", "Tổ Kỹ thuật & Quản lý vận hành"),
                    priority = obj.optString("priority", "Quan trọng")
                )
                taskList.add(task)
            }
        }

        // Parse Defects
        val defectList = mutableListOf<DefectRecord>()
        val defectArray = root.optJSONArray("defects")
        if (defectArray != null) {
            for (i in 0 until defectArray.length()) {
                val obj = defectArray.getJSONObject(i)
                val sevStr = obj.optString("severity", DefectSeverity.MAJOR.name)
                val sev = try { DefectSeverity.valueOf(sevStr) } catch (e: Exception) { DefectSeverity.MAJOR }
                val statStr = obj.optString("status", DefectStatus.PENDING.name)
                val status = try { DefectStatus.valueOf(statStr) } catch (e: Exception) { DefectStatus.PENDING }

                val defect = DefectRecord(
                    id = obj.optLong("id", 0L),
                    equipmentId = if (obj.has("equipmentId")) obj.optLong("equipmentId") else null,
                    equipmentCode = if (obj.has("equipmentCode")) obj.optString("equipmentCode") else null,
                    title = obj.optString("title", ""),
                    severity = sev,
                    category = obj.optString("category", "Thiết bị"),
                    reportedDate = obj.optLong("reportedDate", System.currentTimeMillis()),
                    reportedBy = obj.optString("reportedBy", ""),
                    description = obj.optString("description", ""),
                    actionPlan = obj.optString("actionPlan", ""),
                    status = status,
                    resolvedDate = if (obj.has("resolvedDate")) obj.optLong("resolvedDate") else null,
                    resolvedBy = if (obj.has("resolvedBy")) obj.optString("resolvedBy") else null,
                    resolutionNotes = if (obj.has("resolutionNotes")) obj.optString("resolutionNotes") else null,
                    photoBase64 = if (obj.has("photoBase64")) obj.optString("photoBase64") else null
                )
                defectList.add(defect)
            }
        }

        // Parse Corridors
        val corridorList = mutableListOf<SafetyCorridorRecord>()
        val corridorArray = root.optJSONArray("corridors")
        if (corridorArray != null) {
            for (i in 0 until corridorArray.length()) {
                val obj = corridorArray.getJSONObject(i)
                val hazStr = obj.optString("hazardType", HazardType.TREE.name)
                val haz = try { HazardType.valueOf(hazStr) } catch (e: Exception) { HazardType.TREE }
                val riskStr = obj.optString("riskLevel", HazardRiskLevel.HIGH.name)
                val risk = try { HazardRiskLevel.valueOf(riskStr) } catch (e: Exception) { HazardRiskLevel.HIGH }
                val statStr = obj.optString("status", CorridorStatus.VIOLATION_EXISTING.name)
                val stat = try { CorridorStatus.valueOf(statStr) } catch (e: Exception) { CorridorStatus.VIOLATION_EXISTING }

                val corridor = SafetyCorridorRecord(
                    id = obj.optLong("id", 0L),
                    lineName = obj.optString("lineName", ""),
                    spanLocation = obj.optString("spanLocation", ""),
                    hazardType = haz,
                    description = obj.optString("description", ""),
                    currentDistance = obj.optString("currentDistance", ""),
                    riskLevel = risk,
                    discoveredDate = obj.optLong("discoveredDate", System.currentTimeMillis()),
                    status = stat,
                    clearedDate = if (obj.has("clearedDate")) obj.optLong("clearedDate") else null,
                    clearedBy = if (obj.has("clearedBy")) obj.optString("clearedBy") else null,
                    clearanceActionTaken = if (obj.has("clearanceActionTaken")) obj.optString("clearanceActionTaken") else null,
                    latitude = obj.optDouble("latitude", 0.0),
                    longitude = obj.optDouble("longitude", 0.0),
                    photoBase64 = if (obj.has("photoBase64")) obj.optString("photoBase64") else null
                )
                corridorList.add(corridor)
            }
        }

        // Parse Inspections
        val inspList = mutableListOf<PeriodicInspection>()
        val inspArray = root.optJSONArray("inspections")
        if (inspArray != null) {
            for (i in 0 until inspArray.length()) {
                val obj = inspArray.getJSONObject(i)
                val ins = PeriodicInspection(
                    id = obj.optLong("id", 0L),
                    equipmentId = obj.optLong("equipmentId", 0L),
                    equipmentCode = obj.optString("equipmentCode", ""),
                    inspectionDate = obj.optLong("inspectionDate", System.currentTimeMillis()),
                    inspectorName = obj.optString("inspectorName", ""),
                    inspectionType = obj.optString("inspectionType", "Định kỳ tháng"),
                    temperatureJoints = obj.optString("temperatureJoints", ""),
                    insulatorCondition = obj.optString("insulatorCondition", "Tốt, sạch sẽ"),
                    groundingCondition = obj.optString("groundingCondition", "Đạt tiêu chuẩn"),
                    sf6OrOilStatus = obj.optString("sf6OrOilStatus", "Bình thường"),
                    resultStatus = obj.optString("resultStatus", "Đạt yêu cầu"),
                    notes = obj.optString("notes", "")
                )
                inspList.add(ins)
            }
        }

        // Parse Maintenance
        val maintList = mutableListOf<MaintenanceRecord>()
        val maintArray = root.optJSONArray("maintenance")
        if (maintArray != null) {
            for (i in 0 until maintArray.length()) {
                val obj = maintArray.getJSONObject(i)
                val m = MaintenanceRecord(
                    id = obj.optLong("id", 0L),
                    equipmentId = obj.optLong("equipmentId", 0L),
                    equipmentCode = obj.optString("equipmentCode", ""),
                    maintenanceDate = obj.optLong("maintenanceDate", System.currentTimeMillis()),
                    maintenanceType = obj.optString("maintenanceType", "Bảo dưỡng định kỳ"),
                    workUnit = obj.optString("workUnit", ""),
                    content = obj.optString("content", ""),
                    partsReplaced = obj.optString("partsReplaced", ""),
                    outcome = obj.optString("outcome", "Đạt tiêu chuẩn vận hành"),
                    supervisor = obj.optString("supervisor", "")
                )
                maintList.add(m)
            }
        }

        return BackupData(
            exportTimestamp = timestamp,
            appVersion = version,
            equipments = eqList,
            tasks = taskList,
            defects = defectList,
            corridors = corridorList,
            inspections = inspList,
            maintenance = maintList
        )
    }
}
