package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.AssignedTasksScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DefectsScreen
import com.example.ui.screens.EquipmentDetailScreen
import com.example.ui.screens.GridMapScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.QrScannerScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SafetyCorridorScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SpcNavy
import com.example.ui.theme.StatusDangerRed
import com.example.ui.theme.SubstationCyan
import com.example.ui.viewmodel.GridViewModel
import com.example.util.GridNotificationManager

class MainActivity : ComponentActivity() {
    private val initialEquipmentId = mutableStateOf<Long?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIntent(intent)
        setContent {
            var isOutdoorMode by remember { mutableStateOf(false) }
            MyApplicationTheme(outdoorHighContrast = isOutdoorMode) {
                MainApp(
                    initialEquipmentId = initialEquipmentId.value,
                    onClearInitialEquipmentId = { initialEquipmentId.value = null },
                    isOutdoorMode = isOutdoorMode,
                    onToggleOutdoorMode = { isOutdoorMode = !isOutdoorMode }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val eqId = intent?.getLongExtra(GridNotificationManager.EXTRA_EQUIPMENT_ID, -1L) ?: -1L
        if (eqId > 0) {
            initialEquipmentId.value = eqId
        }
    }
}

enum class ScreenTab(val title: String) {
    DASHBOARD("Tổng quan"),
    EQUIPMENT("Thiết bị"),
    DEFECTS("Khiếm khuyết"),
    TASKS("Việc giao"),
    CORRIDOR("Hành lang"),
    MAP("Bản đồ"),
    REPORTS("Báo cáo")
}

@Composable
fun MainApp(
    viewModel: GridViewModel = viewModel(),
    initialEquipmentId: Long? = null,
    onClearInitialEquipmentId: () -> Unit = {},
    isOutdoorMode: Boolean = false,
    onToggleOutdoorMode: () -> Unit = {}
) {
    val context = LocalContext.current
    var currentTab by remember { mutableStateOf(ScreenTab.DASHBOARD) }
    var inDetailView by remember { mutableStateOf(false) }
    var inQrScanner by remember { mutableStateOf(false) }

    val stats by viewModel.gridStats.collectAsStateWithLifecycle()
    val allEquipments by viewModel.allEquipments.collectAsStateWithLifecycle()

    // Notification Permission Launcher (Android 13+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            GridNotificationManager.initChannels(context)
            GridNotificationManager.checkAndTriggerRealtimeAlerts(context, allEquipments)
        }
    }

    LaunchedEffect(Unit) {
        GridNotificationManager.initChannels(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                GridNotificationManager.checkAndTriggerRealtimeAlerts(context, allEquipments)
            }
        } else {
            GridNotificationManager.checkAndTriggerRealtimeAlerts(context, allEquipments)
        }
    }

    // Handle incoming intent from push notification click
    LaunchedEffect(initialEquipmentId) {
        if (initialEquipmentId != null && initialEquipmentId > 0) {
            viewModel.selectedEquipmentId.value = initialEquipmentId
            inDetailView = true
            currentTab = ScreenTab.EQUIPMENT
            onClearInitialEquipmentId()
        }
    }

    BackHandler(enabled = inQrScanner || inDetailView || currentTab != ScreenTab.DASHBOARD) {
        if (inQrScanner) {
            inQrScanner = false
        } else if (inDetailView) {
            inDetailView = false
        } else {
            currentTab = ScreenTab.DASHBOARD
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (!inDetailView && !inQrScanner) {
                NavigationBar(
                    containerColor = Color.White,
                    tonalElevation = androidx.compose.ui.unit.Dp(8f)
                ) {
                    // Tab 0: Tổng quan (Dashboard)
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.DASHBOARD,
                        onClick = { currentTab = ScreenTab.DASHBOARD },
                        icon = {
                            Icon(Icons.Filled.Assessment, contentDescription = "Tổng quan")
                        },
                        label = { Text("Tổng quan", fontWeight = FontWeight.SemiBold, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SpcNavy,
                            selectedTextColor = SpcNavy,
                            indicatorColor = SpcNavy.copy(alpha = 0.12f)
                        ),
                        modifier = Modifier.testTag("nav_tab_dashboard")
                    )

                    // Tab 1: Thiết bị
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.EQUIPMENT,
                        onClick = { currentTab = ScreenTab.EQUIPMENT },
                        icon = {
                            Icon(Icons.Filled.Build, contentDescription = "Thiết bị")
                        },
                        label = { Text("Thiết bị", fontWeight = FontWeight.SemiBold, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SpcNavy,
                            selectedTextColor = SpcNavy,
                            indicatorColor = SpcNavy.copy(alpha = 0.12f)
                        ),
                        modifier = Modifier.testTag("nav_tab_equipment")
                    )

                    // Tab 2: Khiếm khuyết
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.DEFECTS,
                        onClick = { currentTab = ScreenTab.DEFECTS },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (stats.activeDefects > 0) {
                                        Badge(containerColor = StatusDangerRed) {
                                            Text("${stats.activeDefects}")
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Filled.Warning, contentDescription = "Khiếm khuyết")
                            }
                        },
                        label = { Text("Khiếm khuyết", fontWeight = FontWeight.SemiBold, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = StatusDangerRed,
                            selectedTextColor = StatusDangerRed,
                            indicatorColor = StatusDangerRed.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_tab_defects")
                    )

                    // Tab 3: Việc phân công & Báo cáo cá nhân
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.TASKS,
                        onClick = { currentTab = ScreenTab.TASKS },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (stats.activeAssignedTasks > 0) {
                                        Badge(containerColor = Color(0xFFEF6C00)) {
                                            Text("${stats.activeAssignedTasks}")
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Filled.Assignment, contentDescription = "Việc giao")
                            }
                        },
                        label = { Text("Việc giao", fontWeight = FontWeight.SemiBold, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFEF6C00),
                            selectedTextColor = Color(0xFFEF6C00),
                            indicatorColor = Color(0xFFEF6C00).copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_tab_tasks")
                    )

                    // Tab 4: Hành lang an toàn
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.CORRIDOR,
                        onClick = { currentTab = ScreenTab.CORRIDOR },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (stats.activeCorridorHazards > 0) {
                                        Badge(containerColor = SubstationCyan) {
                                            Text("${stats.activeCorridorHazards}")
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Filled.Security, contentDescription = "Hành lang")
                            }
                        },
                        label = { Text("Hành lang", fontWeight = FontWeight.SemiBold, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = SubstationCyan,
                            selectedTextColor = SubstationCyan,
                            indicatorColor = SubstationCyan.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_tab_corridor")
                    )

                    // Tab 5: Bản đồ GIS
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.MAP,
                        onClick = { currentTab = ScreenTab.MAP },
                        icon = {
                            Icon(Icons.Filled.Map, contentDescription = "Bản đồ")
                        },
                        label = { Text("Bản đồ", fontWeight = FontWeight.SemiBold, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF2E7D32),
                            selectedTextColor = Color(0xFF2E7D32),
                            indicatorColor = Color(0xFF2E7D32).copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_tab_map")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (inQrScanner) {
                QrScannerScreen(
                    viewModel = viewModel,
                    onNavigateToEquipment = { eqId ->
                        viewModel.selectedEquipmentId.value = eqId
                        inDetailView = true
                        inQrScanner = false
                    },
                    onBack = { inQrScanner = false }
                )
            } else if (inDetailView) {
                EquipmentDetailScreen(
                    viewModel = viewModel,
                    onBack = { inDetailView = false }
                )
            } else {
                when (currentTab) {
                    ScreenTab.DASHBOARD -> DashboardScreen(
                        viewModel = viewModel,
                        onNavigateToEquipment = { eqId ->
                            viewModel.selectedEquipmentId.value = eqId
                            inDetailView = true
                        },
                        onNavigateToMap = { currentTab = ScreenTab.MAP },
                        onNavigateToDefects = { currentTab = ScreenTab.DEFECTS },
                        onNavigateToTasks = { currentTab = ScreenTab.TASKS },
                        onNavigateToCorridor = { currentTab = ScreenTab.CORRIDOR },
                        onNavigateToReports = { currentTab = ScreenTab.REPORTS },
                        onNavigateToQrScanner = { inQrScanner = true },
                        isOutdoorMode = isOutdoorMode,
                        onToggleOutdoorMode = onToggleOutdoorMode
                    )
                    ScreenTab.EQUIPMENT -> HomeScreen(
                        viewModel = viewModel,
                        onNavigateToDetail = { eqId ->
                            viewModel.selectedEquipmentId.value = eqId
                            inDetailView = true
                        },
                        onNavigateToQrScanner = { inQrScanner = true },
                        onNavigateToTasks = { currentTab = ScreenTab.TASKS },
                        onNavigateToCorridor = { currentTab = ScreenTab.CORRIDOR },
                        onNavigateToDefects = { currentTab = ScreenTab.DEFECTS }
                    )
                    ScreenTab.DEFECTS -> DefectsScreen(
                        viewModel = viewModel
                    )
                    ScreenTab.TASKS -> AssignedTasksScreen(
                        viewModel = viewModel
                    )
                    ScreenTab.CORRIDOR -> SafetyCorridorScreen(
                        viewModel = viewModel
                    )
                    ScreenTab.MAP -> GridMapScreen(
                        viewModel = viewModel,
                        onNavigateToEquipment = { eqId ->
                            viewModel.selectedEquipmentId.value = eqId
                            inDetailView = true
                        },
                        onNavigateToCorridor = { currentTab = ScreenTab.CORRIDOR }
                    )
                    ScreenTab.REPORTS -> ReportsScreen(
                        viewModel = viewModel,
                        onNavigateToEquipment = { eqId ->
                            viewModel.selectedEquipmentId.value = eqId
                            inDetailView = true
                        }
                    )
                }
            }
        }
    }
}
