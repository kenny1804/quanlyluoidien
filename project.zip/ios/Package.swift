// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "GridInspectorPCAG",
    platforms: [
        .iOS(.v16)
    ],
    products: [
        .library(
            name: "GridInspectorPCAG",
            targets: ["GridInspectorPCAG"]
        ),
    ],
    targets: [
        .target(
            name: "GridInspectorPCAG",
            path: "GridInspectorPCAG"
        )
    ]
)
