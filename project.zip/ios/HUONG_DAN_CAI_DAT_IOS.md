# HƯỚNG DẪN SỬ DỤNG & CÀI ĐẶT ỨNG DỤNG CHO IOS (IPHONE / IPAD)
**ĐƠN VỊ: CÔNG TY ĐIỆN LỰC AN GIANG (PCAG) - TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM (SPC)**

---

## 1. DÙNG NGAY TRÊN IPHONE / IPAD (KHÔNG CẦN MAC / XCODE)
Cán bộ kỹ thuật có thể sử dụng ứng dụng ngay trên iPhone hoặc iPad thông qua trình duyệt Safari:

1. **Mở đường link ứng dụng trên iPhone/iPad bằng Safari:**
   `https://ais-dev-j7y5kmqwyirkgiwuaeoies-267475064780.asia-southeast1.run.app`
2. **Thêm vào màn hình chính (Dùng như App iOS thật):**
   - Bấm nút **Chia sẻ (Share)** hình ô vuông có mũi tên hướng lên ở thanh dưới Safari.
   - Chọn **"Thêm vào MH chính" (Add to Home Screen)**.
   - Đặt tên app: **QLVH Lưới Điện PCAG** và bấm **Thêm**.
3. **Trải nghiệm mượt mà:**
   - Ứng dụng chạy toàn màn hình (Full Screen), cảm ứng mượt mà.
   - Ký tên cảm ứng bằng ngón tay / Apple Pencil.
   - Xuất PDF có dấu chìm PCAG và chia sẻ trực tiếp về Tổ QLVH.

---

## 2. PHIÊN BẢN IOS NATIVE (SWIFT & SWIFTUI):
Mã nguồn native cho iOS đã được xây dựng hoàn chỉnh trong thư mục `/ios/GridInspectorPCAG` và đóng gói sẵn tại `public/GridInspectorPCAG_iOS.zip`.

### Các cải tiến mới nhất đã được cập nhật đồng bộ:
- **Chuẩn hóa chữ ký cán bộ**: Chữ ký tay và họ tên cán bộ báo cáo đã được **căn giữa ngay ngắn tuyệt đối theo trục cột**, không còn bị xô lệch.
- **Lược bỏ thông tin không cần thiết**: Đã bỏ hoàn toàn dòng `Đơn vị tiếp nhận: Đội Sửa chữa cơ động`. Khu vực tiếp nhận để thông thoáng cho Tổ QLVH ký duyệt.
- **Đầy đủ phân hệ**:
  - Quản lý Thiết bị (Recloser, LBS, DS, LA, FCO, LBFCO) & Khiếm khuyết.
  - Phân công việc giao & Thống kê hiện trường (Assigned Work Tasks).
  - Hành lang an toàn lưới điện (Safety Corridors).
  - Dấu chìm bản quyền: `CÔNG TY ĐIỆN LỰC AN GIANG (PCAG) • SPC`.

### Cách biên dịch bằng Xcode trên máy Mac:
1. Tải file mã nguồn: `GridInspectorPCAG_iOS.zip` (hoặc copy toàn bộ thư mục `/ios`).
2. Mở **Xcode**, chọn `File -> Open` thư mục `/ios/GridInspectorPCAG`.
3. Chọn thiết bị đích (iPhone / iPad thật hoặc máy ảo mô phỏng).
4. Bấm **Cmd + R (Run)** để cài đặt ứng dụng native trực tiếp lên thiết bị.
