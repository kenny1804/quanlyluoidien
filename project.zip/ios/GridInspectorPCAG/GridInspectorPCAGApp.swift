//
//  GridInspectorPCAGApp.swift
//  GridInspectorPCAG
//
//  Tạo bởi: CÔNG TY ĐIỆN LỰC AN GIANG (PCAG) - TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM (SPC)
//  Tương thích iOS 16.0+ (iPhone & iPad)
//

import SwiftUI

@main
struct GridInspectorPCAGApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
