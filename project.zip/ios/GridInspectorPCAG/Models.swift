//
//  Models.swift
//  GridInspectorPCAG
//
//  Tạo bởi: CÔNG TY ĐIỆN LỰC AN GIANG (PCAG) - TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM (SPC)
//  Hệ thống Quản lý Vận hành & Kiểm tra Thiết bị Lưới điện Phân phối
//

import Foundation

public enum EquipmentType: String, CaseIterable, Codable, Identifiable {
    case recloser = "RECLOSER"
    case lbs = "LBS"
    case ds = "DS"
    case la = "LA"
    case fco = "FCO"
    case lbfco = "LBFCO"
    
    public var id: String { rawValue }
    
    public var displayName: String {
        switch self {
        case .recloser: return "Máy Cắt Recloser Tự Đóng Lại"
        case .lbs: return "Dao Cắt Có Tải (LBS)"
        case .ds: return "Dao Cách Ly Phân Đoạn (DS)"
        case .la: return "Chống Sét Van (LA)"
        case .fco: return "Cầu Chì Tự Rơi (FCO)"
        case .lbfco: return "Cầu Chì Cắt Có Tải (LBFCO)"
        }
    }
    
    public var shortName: String {
        switch self {
        case .recloser: return "Recloser"
        case .lbs: return "LBS"
        case .ds: return "DS"
        case .la: return "LA"
        case .fco: return "FCO"
        case .lbfco: return "LBFCO"
        }
    }
    
    public var tagColorHex: String {
        switch self {
        case .recloser: return "#0D47A1"
        case .lbs: return "#00897B"
        case .ds: return "#F57C00"
        case .la: return "#D32F2F"
        case .fco: return "#7B1FA2"
        case .lbfco: return "#C2185B"
        }
    }
}

public enum OperatingStatus: String, CaseIterable, Codable, Identifiable {
    case normal = "NORMAL"
    case warning = "WARNING"
    case maintenanceRequired = "MAINTENANCE_REQUIRED"
    case defect = "DEFECT"
    
    public var id: String { rawValue }
    
    public var displayName: String {
        switch self {
        case .normal: return "Bình thường"
        case .warning: return "Cảnh báo"
        case .maintenanceRequired: return "Cần bảo dưỡng"
        case .defect: return "Khiếm khuyết"
        }
    }
    
    public var colorHex: String {
        switch self {
        case .normal: return "#2E7D32"
        case .warning: return "#ED6C02"
        case .maintenanceRequired: return "#0288D1"
        case .defect: return "#D32F2F"
        }
    }
}

public enum DefectSeverity: String, CaseIterable, Codable, Identifiable {
    case low = "LOW"
    case medium = "MEDIUM"
    case high = "HIGH"
    case critical = "CRITICAL"
    
    public var id: String { rawValue }
    
    public var displayName: String {
        switch self {
        case .low: return "Nhẹ"
        case .medium: return "Vừa"
        case .high: return "Nặng"
        case .critical: return "Nguy hiểm"
        }
    }
    
    public var colorHex: String {
        switch self {
        case .low: return "#43A047"
        case .medium: return "#FB8C00"
        case .high: return "#E53935"
        case .critical: return "#B71C1C"
        }
    }
}

public struct EquipmentItem: Identifiable, Codable {
    public var id: String
    public var code: String
    public var name: String
    public var type: EquipmentType
    public var poleNumber: String
    public var lineName: String
    public var voltageLevel: String
    public var ratedCurrent: String
    public var manufacturer: String
    public var installationDate: Date
    public var lastInspectionDate: Date
    public var nextInspectionDueDate: Date
    public var status: OperatingStatus
    public var notes: String
    
    public init(
        id: String = UUID().uuidString,
        code: String,
        name: String,
        type: EquipmentType,
        poleNumber: String,
        lineName: String,
        voltageLevel: String = "22kV",
        ratedCurrent: String = "630A",
        manufacturer: String = "Entec / Schneider",
        installationDate: Date = Date(),
        lastInspectionDate: Date = Date(),
        nextInspectionDueDate: Date = Calendar.current.date(byAdding: .month, value: 3, to: Date()) ?? Date(),
        status: OperatingStatus = .normal,
        notes: String = ""
    ) {
        self.id = id
        self.code = code
        self.name = name
        self.type = type
        self.poleNumber = poleNumber
        self.lineName = lineName
        self.voltageLevel = voltageLevel
        self.ratedCurrent = ratedCurrent
        self.manufacturer = manufacturer
        self.installationDate = installationDate
        self.lastInspectionDate = lastInspectionDate
        self.nextInspectionDueDate = nextInspectionDueDate
        self.status = status
        self.notes = notes
    }
}

public struct PeriodicInspectionRecord: Identifiable, Codable {
    public var id: String
    public var equipmentId: String
    public var inspectionDate: Date
    public var inspectorName: String
    public var checkResult: String
    public var findings: String
    public var correctiveActions: String
    
    public init(
        id: String = UUID().uuidString,
        equipmentId: String,
        inspectionDate: Date = Date(),
        inspectorName: String,
        checkResult: String = "Đạt tiêu chuẩn kỹ thuật vận hành SPC",
        findings: String = "",
        correctiveActions: String = ""
    ) {
        self.id = id
        self.equipmentId = equipmentId
        self.inspectionDate = inspectionDate
        self.inspectorName = inspectorName
        self.checkResult = checkResult
        self.findings = findings
        self.correctiveActions = correctiveActions
    }
}

public struct DefectRecord: Identifiable, Codable {
    public var id: String
    public var equipmentId: String
    public var defectDate: Date
    public var severity: DefectSeverity
    public var description: String
    public var reportedBy: String
    public var isResolved: Bool
    public var resolutionNotes: String
    
    public init(
        id: String = UUID().uuidString,
        equipmentId: String,
        defectDate: Date = Date(),
        severity: DefectSeverity = .medium,
        description: String,
        reportedBy: String,
        isResolved: Bool = false,
        resolutionNotes: String = ""
    ) {
        self.id = id
        self.equipmentId = equipmentId
        self.defectDate = defectDate
        self.severity = severity
        self.description = description
        self.reportedBy = reportedBy
        self.isResolved = isResolved
        self.resolutionNotes = resolutionNotes
    }
}

public struct InspectorProfile: Codable {
    public var inspectorName: String
    public var inspectorTitle: String
    public var teamName: String
    public var companyName: String
    public var managedArea: String
    public var phone: String
    
    public init(
        inspectorName: String = "Kỹ sư Nguyễn Văn Tuấn",
        inspectorTitle: String = "Cán bộ Kỹ thuật Vận hành",
        teamName: String = "Tổ Quản Lý Vận Hành Lưới Điện - PCAG",
        companyName: String = "CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)",
        managedArea: String = "Đường dây 471 An Giang",
        phone: String = "0912.345.678"
    ) {
        self.inspectorName = inspectorName
        self.inspectorTitle = inspectorTitle
        self.teamName = teamName
        self.companyName = companyName
        self.managedArea = managedArea
        self.phone = phone
    }
}

// MARK: - PHÂN HỆ VIỆC GIAO & THỐNG KÊ (ASSIGNED WORK TASKS)
public enum WorkTaskStatus: String, CaseIterable, Codable, Identifiable {
    case new = "NEW"
    case inProgress = "IN_PROGRESS"
    case completed = "COMPLETED"
    case submittedQLVH = "SUBMITTED_QLVH"
    
    public var id: String { rawValue }
    
    public var label: String {
        switch self {
        case .new: return "Mới phân công"
        case .inProgress: return "Đang thực hiện"
        case .completed: return "Đã thống kê xong"
        case .submittedQLVH: return "Đã gửi về QLVH"
        }
    }
}

public struct AssignedWorkTask: Identifiable, Codable {
    public var id: String
    public var title: String
    public var assignedBy: String
    public var assignee: String
    public var category: String
    public var lineName: String
    public var spanLocation: String
    public var targetScope: String
    public var recordedCount: Int
    public var unit: String
    public var description: String
    public var detailedStatistics: String
    public var proposedRemedy: String
    public var assignedDate: Date
    public var deadlineDate: Date?
    public var status: WorkTaskStatus
    public var submittedDate: Date?
    public var reportCode: String?
    public var qlvhRecipient: String
    public var priority: String
    
    public init(
        id: String = UUID().uuidString,
        title: String,
        assignedBy: String = "Tổ Kỹ thuật / Đội QLVH",
        assignee: String,
        category: String = "Tiếp địa & Nối đất",
        lineName: String,
        spanLocation: String = "",
        targetScope: String = "",
        recordedCount: Int = 0,
        unit: String = "vị trí",
        description: String = "",
        detailedStatistics: String = "",
        proposedRemedy: String = "",
        assignedDate: Date = Date(),
        deadlineDate: Date? = nil,
        status: WorkTaskStatus = .inProgress,
        submittedDate: Date? = nil,
        reportCode: String? = nil,
        qlvhRecipient: String = "Tổ Quản Lý Vận Hành Lưới Điện",
        priority: String = "Quan trọng"
    ) {
        self.id = id
        self.title = title
        self.assignedBy = assignedBy
        self.assignee = assignee
        self.category = category
        self.lineName = lineName
        self.spanLocation = spanLocation
        self.targetScope = targetScope
        self.recordedCount = recordedCount
        self.unit = unit
        self.description = description
        self.detailedStatistics = detailedStatistics
        self.proposedRemedy = proposedRemedy
        self.assignedDate = assignedDate
        self.deadlineDate = deadlineDate
        self.status = status
        self.submittedDate = submittedDate
        self.reportCode = reportCode
        self.qlvhRecipient = qlvhRecipient
        self.priority = priority
    }
}

// MARK: - PHÂN HỆ HÀNH LANG AN TOÀN LƯỚI ĐIỆN (SAFETY CORRIDOR)
public enum HazardType: String, CaseIterable, Codable, Identifiable {
    case tree = "TREE"
    case construction = "CONSTRUCTION"
    case equipmentOther = "EQUIPMENT_OTHER"
    
    public var id: String { rawValue }
    
    public var displayName: String {
        switch self {
        case .tree: return "Cây xanh vi phạm"
        case .construction: return "Nhà cửa / Công trình"
        case .equipmentOther: return "Vật thể / Khác"
        }
    }
}

public enum HazardRiskLevel: String, CaseIterable, Codable, Identifiable {
    case low = "LOW"
    case medium = "MEDIUM"
    case high = "HIGH"
    case critical = "CRITICAL"
    
    public var id: String { rawValue }
    
    public var displayName: String {
        switch self {
        case .low: return "Nguy cơ Thấp"
        case .medium: return "Nguy cơ Vừa"
        case .high: return "Nguy cơ Cao"
        case .critical: return "Khẩn cấp / Nguy hiểm"
        }
    }
}

public enum CorridorStatus: String, CaseIterable, Codable, Identifiable {
    case violationExisting = "VIOLATION_EXISTING"
    case handling = "HANDLING"
    case resolved = "RESOLVED"
    
    public var id: String { rawValue }
    
    public var displayName: String {
        switch self {
        case .violationExisting: return "Chưa xử lý"
        case .handling: return "Đang xử lý"
        case .resolved: return "Đã xử lý an toàn"
        }
    }
}

public struct SafetyCorridorRecord: Identifiable, Codable {
    public var id: String
    public var lineName: String
    public var spanLocation: String
    public var hazardType: HazardType
    public var description: String
    public var currentDistance: String
    public var riskLevel: HazardRiskLevel
    public var discoveredDate: Date
    public var status: CorridorStatus
    public var clearedDate: Date?
    public var clearedBy: String?
    public var clearanceActionTaken: String?
    
    public init(
        id: String = UUID().uuidString,
        lineName: String,
        spanLocation: String,
        hazardType: HazardType = .tree,
        description: String,
        currentDistance: String = "1.2m (yêu cầu >= 2.0m)",
        riskLevel: HazardRiskLevel = .high,
        discoveredDate: Date = Date(),
        status: CorridorStatus = .violationExisting,
        clearedDate: Date? = nil,
        clearedBy: String? = nil,
        clearanceActionTaken: String? = nil
    ) {
        self.id = id
        self.lineName = lineName
        self.spanLocation = spanLocation
        self.hazardType = hazardType
        self.description = description
        self.currentDistance = currentDistance
        self.riskLevel = riskLevel
        self.discoveredDate = discoveredDate
        self.status = status
        self.clearedDate = clearedDate
        self.clearedBy = clearedBy
        self.clearanceActionTaken = clearanceActionTaken
    }
}
