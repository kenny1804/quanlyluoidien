//
//  PDFReportGenerator.swift
//  GridInspectorPCAG
//
//  Tạo bởi: CÔNG TY ĐIỆN LỰC AN GIANG (PCAG) - TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM (SPC)
//  Tạo file PDF chuẩn iOS có dấu chìm (Watermark) Cty Điện lực An Giang (PCAG)
//

import UIKit
import PDFKit

public class PDFReportGenerator {
    
    public static func generateReport(
        equipments: [EquipmentItem],
        inspections: [PeriodicInspectionRecord],
        defects: [DefectRecord],
        profile: InspectorProfile,
        signatureImage: UIImage? = nil
    ) -> URL? {
        
        let pageWidth: CGFloat = 595.2 // A4 width at 72 dpi
        let pageHeight: CGFloat = 841.8 // A4 height at 72 dpi
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        
        let renderer = UIGraphicsPDFRenderer(bounds: pageRect)
        let tempURL = FileManager.default.temporaryDirectory.appendingPathComponent("BaoCao_ThietBi_LuoiDien_PCAG_\(Int(Date().timeIntervalSince1970)).pdf")
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy HH:mm"
        let dateStr = dateFormatter.string(from: Date())
        
        do {
            try renderer.writePDF(to: tempURL, withActions: { context in
                let itemsPerPage = max(1, equipments.count)
                
                for (index, equipment) in equipments.enumerated() {
                    context.beginPage()
                    let cgContext = context.cgContext
                    
                    // 1. VẼ DẤU CHÌM (WATERMARK) CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)
                    cgContext.saveGState()
                    cgContext.translateBy(x: pageWidth / 2, y: pageHeight / 2)
                    cgContext.rotate(by: -32.0 * .pi / 180.0)
                    
                    let watermarkAttrs1: [NSAttributedString.Key: Any] = [
                        .font: UIFont.systemFont(ofSize: 18, weight: .bold),
                        .foregroundColor: UIColor(red: 0/255, green: 51/255, blue: 102/255, alpha: 0.08)
                    ]
                    let str1 = NSAttributedString(string: "TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM - EVNSPC", attributes: watermarkAttrs1)
                    str1.draw(at: CGPoint(x: -str1.size().width / 2, y: -75))
                    
                    let watermarkAttrs2: [NSAttributedString.Key: Any] = [
                        .font: UIFont.systemFont(ofSize: 30, weight: .heavy),
                        .foregroundColor: UIColor(red: 0/255, green: 51/255, blue: 102/255, alpha: 0.12)
                    ]
                    let str2 = NSAttributedString(string: "CÔNG TY ĐIỆN LỰC AN GIANG", attributes: watermarkAttrs2)
                    str2.draw(at: CGPoint(x: -str2.size().width / 2, y: -25))
                    
                    let watermarkAttrs3: [NSAttributedString.Key: Any] = [
                        .font: UIFont.systemFont(ofSize: 52, weight: .black),
                        .foregroundColor: UIColor(red: 0/255, green: 51/255, blue: 102/255, alpha: 0.15)
                    ]
                    let str3 = NSAttributedString(string: "PCAG", attributes: watermarkAttrs3)
                    str3.draw(at: CGPoint(x: -str3.size().width / 2, y: 30))
                    
                    let watermarkAttrs4: [NSAttributedString.Key: Any] = [
                        .font: UIFont.systemFont(ofSize: 16, weight: .bold),
                        .foregroundColor: UIColor(red: 0/255, green: 51/255, blue: 102/255, alpha: 0.10)
                    ]
                    let str4 = NSAttributedString(string: "TẠO BỞI CTY ĐIỆN LỰC AN GIANG (PCAG)", attributes: watermarkAttrs4)
                    str4.draw(at: CGPoint(x: -str4.size().width / 2, y: 65))
                    
                    cgContext.restoreGState()
                    
                    // 2. HEADER BANNER SPC
                    let headerRect = CGRect(x: 0, y: 0, width: pageWidth, height: 64)
                    UIColor(red: 0/255, green: 51/255, blue: 102/255, alpha: 1.0).setFill()
                    cgContext.fill(headerRect)
                    
                    let headerTitleAttrs: [NSAttributedString.Key: Any] = [
                        .font: UIFont.boldSystemFont(ofSize: 10),
                        .foregroundColor: UIColor.white
                    ]
                    "TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM - EVNSPC".draw(at: CGPoint(x: 24, y: 14), withAttributes: headerTitleAttrs)
                    
                    let companyAttrs: [NSAttributedString.Key: Any] = [
                        .font: UIFont.boldSystemFont(ofSize: 11),
                        .foregroundColor: UIColor(red: 255/255, green: 249/255, blue: 196/255, alpha: 1.0)
                    ]
                    profile.companyName.draw(at: CGPoint(x: 24, y: 28), withAttributes: companyAttrs)
                    
                    let subAttrs: [NSAttributedString.Key: Any] = [
                        .font: UIFont.systemFont(ofSize: 8.5),
                        .foregroundColor: UIColor.white
                    ]
                    "HỆ THỐNG QUẢN LÝ VẬN HÀNH THIẾT BỊ LƯỚI ĐIỆN PHÂN PHỐI".draw(at: CGPoint(x: 24, y: 44), withAttributes: subAttrs)
                    
                    // 3. TIÊU ĐỀ BÁO CÁO
                    let titleAttrs: [NSAttributedString.Key: Any] = [
                        .font: UIFont.boldSystemFont(ofSize: 14),
                        .foregroundColor: UIColor(red: 13/255, green: 71/255, blue: 161/255, alpha: 1.0)
                    ]
                    let reportTitle = "BÁO CÁO KỸ THUẬT & KIỂM TRA ĐỊNH KỲ THIẾT BỊ"
                    let titleWidth = (reportTitle as NSString).size(withAttributes: titleAttrs).width
                    reportTitle.draw(at: CGPoint(x: (pageWidth - titleWidth)/2, y: 80), withAttributes: titleAttrs)
                    
                    let metaAttrs: [NSAttributedString.Key: Any] = [
                        .font: UIFont.systemFont(ofSize: 9),
                        .foregroundColor: UIColor.darkGray
                    ]
                    let metaText = "Người lập: \(profile.inspectorName) | Thời gian: \(dateStr) | Dấu chìm: PCAG"
                    let metaWidth = (metaText as NSString).size(withAttributes: metaAttrs).width
                    metaText.draw(at: CGPoint(x: (pageWidth - metaWidth)/2, y: 98), withAttributes: metaAttrs)
                    
                    // ĐƯỜNG KẺ NGANG
                    cgContext.setStrokeColor(UIColor(red: 0/255, green: 51/255, blue: 102/255, alpha: 1.0).cgColor)
                    cgContext.setLineWidth(1.5)
                    cgContext.move(to: CGPoint(x: 24, y: 114))
                    cgContext.addLine(to: CGPoint(x: pageWidth - 24, y: 114))
                    cgContext.strokePath()
                    
                    // 4. THÔNG TIN THIẾT BỊ
                    var currentY: CGFloat = 125
                    let sectionHeaderAttrs: [NSAttributedString.Key: Any] = [
                        .font: UIFont.boldSystemFont(ofSize: 11),
                        .foregroundColor: UIColor(red: 0/255, green: 51/255, blue: 102/255, alpha: 1.0)
                    ]
                    "I. THÔNG SỐ VẬN HÀNH THIẾT BỊ LƯỚI ĐIỆN".draw(at: CGPoint(x: 24, y: currentY), withAttributes: sectionHeaderAttrs)
                    currentY += 20
                    
                    let tableBorderRect = CGRect(x: 24, y: currentY, width: pageWidth - 48, height: 110)
                    UIColor(red: 245/255, green: 247/255, blue: 250/255, alpha: 1.0).setFill()
                    cgContext.fill(tableBorderRect)
                    UIColor.lightGray.setStroke()
                    cgContext.setLineWidth(0.5)
                    cgContext.stroke(tableBorderRect)
                    
                    let cellAttrsBold: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 9.5), .foregroundColor: UIColor.black]
                    let cellAttrsNormal: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 9.5), .foregroundColor: UIColor.darkGray]
                    
                    "Mã thiết bị:".draw(at: CGPoint(x: 32, y: currentY + 8), withAttributes: cellAttrsBold)
                    equipment.code.draw(at: CGPoint(x: 120, y: currentY + 8), withAttributes: cellAttrsNormal)
                    
                    "Loại thiết bị:".draw(at: CGPoint(x: 300, y: currentY + 8), withAttributes: cellAttrsBold)
                    equipment.type.displayName.draw(at: CGPoint(x: 380, y: currentY + 8), withAttributes: cellAttrsNormal)
                    
                    "Tên gọi:".draw(at: CGPoint(x: 32, y: currentY + 28), withAttributes: cellAttrsBold)
                    equipment.name.draw(at: CGPoint(x: 120, y: currentY + 28), withAttributes: cellAttrsNormal)
                    
                    "Vị trí cột:".draw(at: CGPoint(x: 300, y: currentY + 28), withAttributes: cellAttrsBold)
                    equipment.poleNumber.draw(at: CGPoint(x: 380, y: currentY + 28), withAttributes: cellAttrsNormal)
                    
                    "Tuyến đường dây:".draw(at: CGPoint(x: 32, y: currentY + 48), withAttributes: cellAttrsBold)
                    equipment.lineName.draw(at: CGPoint(x: 120, y: currentY + 48), withAttributes: cellAttrsNormal)
                    
                    "Cấp điện áp:".draw(at: CGPoint(x: 300, y: currentY + 48), withAttributes: cellAttrsBold)
                    "\(equipment.voltageLevel) - \(equipment.ratedCurrent)".draw(at: CGPoint(x: 380, y: currentY + 48), withAttributes: cellAttrsNormal)
                    
                    "Trạng thái:".draw(at: CGPoint(x: 32, y: currentY + 68), withAttributes: cellAttrsBold)
                    equipment.status.displayName.draw(at: CGPoint(x: 120, y: currentY + 68), withAttributes: cellAttrsNormal)
                    
                    "Hãng sản xuất:".draw(at: CGPoint(x: 300, y: currentY + 68), withAttributes: cellAttrsBold)
                    equipment.manufacturer.draw(at: CGPoint(x: 380, y: currentY + 68), withAttributes: cellAttrsNormal)
                    
                    currentY += 125
                    
                    // 5. KHIẾM KHUYẾT & LỊCH SỬ
                    "II. KẾT QUẢ KIỂM TRA & KHIẾM KHUYẾT GHI NHẬN".draw(at: CGPoint(x: 24, y: currentY), withAttributes: sectionHeaderAttrs)
                    currentY += 20
                    
                    let equipDefects = defects.filter { $0.equipmentId == equipment.id }
                    if equipDefects.isEmpty {
                        let okAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 9.5), .foregroundColor: UIColor(red: 46/255, green: 125/255, blue: 50/255, alpha: 1.0)]
                        "✓ Thiết bị đang vận hành ổn định, không có tồn đọng khiếm khuyết.".draw(at: CGPoint(x: 32, y: currentY), withAttributes: okAttrs)
                        currentY += 30
                    } else {
                        for d in equipDefects {
                            let defAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 9), .foregroundColor: UIColor.red]
                            "• [\(d.severity.displayName)] \(d.description) - \(d.isResolved ? "Đã xử lý" : "Chưa xử lý")".draw(at: CGPoint(x: 32, y: currentY), withAttributes: defAttrs)
                            currentY += 16
                        }
                        currentY += 14
                    }
                    
                    // 6. CHỮ KÝ CỦA CÁN BỘ & TỔ QLVH (CĂN GIỮA CHÍNH XÁC THEO TRỤC CỘT)
                    let signY = pageHeight - 160
                    let col1CenterX: CGFloat = 140
                    let col2CenterX: CGFloat = pageWidth - 140
                    
                    let inspectorSignAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 10), .foregroundColor: UIColor.black]
                    let title1 = "CÁN BỘ BÁO CÁO / THỰC HIỆN"
                    let title1W = (title1 as NSString).size(withAttributes: inspectorSignAttrs).width
                    title1.draw(at: CGPoint(x: col1CenterX - title1W/2, y: signY), withAttributes: inspectorSignAttrs)
                    
                    let sub1 = "(Ký và ghi rõ họ tên)"
                    let sub1W = (sub1 as NSString).size(withAttributes: metaAttrs).width
                    sub1.draw(at: CGPoint(x: col1CenterX - sub1W/2, y: signY + 14), withAttributes: metaAttrs)
                    
                    let title2 = "TỔ QUẢN LÝ VẬN HÀNH TIẾP NHẬN"
                    let title2W = (title2 as NSString).size(withAttributes: inspectorSignAttrs).width
                    title2.draw(at: CGPoint(x: col2CenterX - title2W/2, y: signY), withAttributes: inspectorSignAttrs)
                    
                    let sub2 = "(Ký duyệt và ghi ý kiến tiếp nhận)"
                    let sub2W = (sub2 as NSString).size(withAttributes: metaAttrs).width
                    sub2.draw(at: CGPoint(x: col2CenterX - sub2W/2, y: signY + 14), withAttributes: metaAttrs)
                    
                    // Vẽ hình chữ ký căn giữa tuyệt đối
                    let sigW: CGFloat = 130
                    let sigH: CGFloat = 55
                    if let sig = signatureImage {
                        let sigRect = CGRect(x: col1CenterX - sigW/2, y: signY + 28, width: sigW, height: sigH)
                        sig.draw(in: sigRect)
                    } else {
                        let eRect = CGRect(x: col1CenterX - sigW/2, y: signY + 34, width: sigW, height: 36)
                        UIColor(red: 227/255, green: 242/255, blue: 253/255, alpha: 1.0).setFill()
                        UIBezierPath(roundedRect: eRect, cornerRadius: 4).fill()
                        
                        let eAttrs: [NSAttributedString.Key: Any] = [
                            .font: UIFont.boldSystemFont(ofSize: 8),
                            .foregroundColor: UIColor(red: 13/255, green: 71/255, blue: 161/255, alpha: 1.0)
                        ]
                        let eText = "✓ ĐÃ KÝ ĐIỆN TỬ"
                        let eW = (eText as NSString).size(withAttributes: eAttrs).width
                        eText.draw(at: CGPoint(x: col1CenterX - eW/2, y: signY + 46), withAttributes: eAttrs)
                    }
                    
                    let nameAttrs: [NSAttributedString.Key: Any] = [
                        .font: UIFont.boldSystemFont(ofSize: 9.5),
                        .foregroundColor: UIColor(red: 27/255, green: 94/255, blue: 32/255, alpha: 1.0)
                    ]
                    let nameW = (profile.inspectorName as NSString).size(withAttributes: nameAttrs).width
                    profile.inspectorName.draw(at: CGPoint(x: col1CenterX - nameW/2, y: signY + 88), withAttributes: nameAttrs)
                    
                    // CHÂN TRANG
                    cgContext.setStrokeColor(UIColor.lightGray.cgColor)
                    cgContext.setLineWidth(0.5)
                    cgContext.move(to: CGPoint(x: 24, y: pageHeight - 30))
                    cgContext.addLine(to: CGPoint(x: pageWidth - 24, y: pageHeight - 30))
                    cgContext.strokePath()
                    
                    let footAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 8), .foregroundColor: UIColor.gray]
                    "Hệ Thống Lưới Điện SPC • Tạo bởi Cty Điện lực An Giang (PCAG) • Trang \(index + 1)/\(itemsPerPage)".draw(at: CGPoint(x: 24, y: pageHeight - 20), withAttributes: footAttrs)
                }
            })
            return tempURL
        } catch {
            print("Lỗi tạo PDF iOS: \(error.localizedDescription)")
            return nil
        }
    }
    
    // MARK: - BÁO CÁO KẾT QUẢ THỰC HIỆN CÔNG VIỆC ĐƯỢC GIAO
    public static func generateTaskReport(
        task: AssignedWorkTask,
        profile: InspectorProfile,
        signatureImage: UIImage? = nil
    ) -> URL? {
        let pageWidth: CGFloat = 595.2
        let pageHeight: CGFloat = 841.8
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        let renderer = UIGraphicsPDFRenderer(bounds: pageRect)
        let tempURL = FileManager.default.temporaryDirectory.appendingPathComponent("BaoCao_CongViec_\(task.id)_\(Int(Date().timeIntervalSince1970)).pdf")
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy HH:mm"
        let dateStr = dateFormatter.string(from: Date())
        
        do {
            try renderer.writePDF(to: tempURL, withActions: { context in
                context.beginPage()
                let cgContext = context.cgContext
                
                // Dấu chìm Watermark
                cgContext.saveGState()
                cgContext.translateBy(x: pageWidth / 2, y: pageHeight / 2)
                cgContext.rotate(by: -32.0 * .pi / 180.0)
                let wmAttrs: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: 44, weight: .black),
                    .foregroundColor: UIColor(red: 0/255, green: 51/255, blue: 102/255, alpha: 0.12)
                ]
                let str = NSAttributedString(string: "CÔNG TY ĐIỆN LỰC AN GIANG", attributes: wmAttrs)
                str.draw(at: CGPoint(x: -str.size().width / 2, y: 0))
                cgContext.restoreGState()
                
                // Header
                let headerRect = CGRect(x: 0, y: 0, width: pageWidth, height: 64)
                UIColor(red: 0/255, green: 51/255, blue: 102/255, alpha: 1.0).setFill()
                cgContext.fill(headerRect)
                
                let hAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 10), .foregroundColor: UIColor.white]
                "TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM - EVNSPC".draw(at: CGPoint(x: 24, y: 14), withAttributes: hAttrs)
                
                let compAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 11), .foregroundColor: UIColor(red: 255/255, green: 249/255, blue: 196/255, alpha: 1.0)]
                profile.companyName.draw(at: CGPoint(x: 24, y: 28), withAttributes: compAttrs)
                
                let subAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 8.5), .foregroundColor: UIColor.white]
                "HỆ THỐNG QUẢN LÝ VẬN HÀNH THIẾT BỊ LƯỚI ĐIỆN PHÂN PHỐI".draw(at: CGPoint(x: 24, y: 44), withAttributes: subAttrs)
                
                // Title
                let titleAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 13.5), .foregroundColor: UIColor(red: 13/255, green: 71/255, blue: 161/255, alpha: 1.0)]
                let reportTitle = "BÁO CÁO KẾT QUẢ THỰC HIỆN CÔNG VIỆC GIAO"
                let tw = (reportTitle as NSString).size(withAttributes: titleAttrs).width
                reportTitle.draw(at: CGPoint(x: (pageWidth - tw)/2, y: 78), withAttributes: titleAttrs)
                
                let metaAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 8.5), .foregroundColor: UIColor.darkGray]
                let metaText = "Mã phiếu: \(task.reportCode ?? "BC-NV-PCAG") • Ngày lập: \(dateStr)"
                let mw = (metaText as NSString).size(withAttributes: metaAttrs).width
                metaText.draw(at: CGPoint(x: (pageWidth - mw)/2, y: 96), withAttributes: metaAttrs)
                
                // Section I
                var curY: CGFloat = 118
                let secAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 10.5), .foregroundColor: UIColor(red: 0/255, green: 51/255, blue: 102/255, alpha: 1.0)]
                "I. THÔNG TIN PHÂN CÔNG CÔNG VIỆC".draw(at: CGPoint(x: 24, y: curY), withAttributes: secAttrs)
                curY += 18
                
                let bRect1 = CGRect(x: 24, y: curY, width: pageWidth - 48, height: 95)
                UIColor(red: 245/255, green: 247/255, blue: 250/255, alpha: 1.0).setFill()
                cgContext.fill(bRect1)
                UIColor.lightGray.setStroke()
                cgContext.setLineWidth(0.5)
                cgContext.stroke(bRect1)
                
                let bAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 9), .foregroundColor: UIColor.black]
                let nAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 9), .foregroundColor: UIColor.darkGray]
                
                "Tiêu đề:".draw(at: CGPoint(x: 32, y: curY + 8), withAttributes: bAttrs)
                task.title.draw(at: CGPoint(x: 130, y: curY + 8), withAttributes: nAttrs)
                
                "Đơn vị giao:".draw(at: CGPoint(x: 32, y: curY + 26), withAttributes: bAttrs)
                task.assignedBy.draw(at: CGPoint(x: 130, y: curY + 26), withAttributes: nAttrs)
                
                "Cán bộ thực hiện:".draw(at: CGPoint(x: 32, y: curY + 44), withAttributes: bAttrs)
                task.assignee.draw(at: CGPoint(x: 130, y: curY + 44), withAttributes: nAttrs)
                
                "Tuyến / Vị trí:".draw(at: CGPoint(x: 32, y: curY + 62), withAttributes: bAttrs)
                "\(task.lineName) - \(task.spanLocation)".draw(at: CGPoint(x: 130, y: curY + 62), withAttributes: nAttrs)
                
                curY += 110
                
                // Section II
                "II. KẾT QUẢ HIỆN TRƯỜNG & KIẾN NGHỊ".draw(at: CGPoint(x: 24, y: curY), withAttributes: secAttrs)
                curY += 18
                
                let bRect2 = CGRect(x: 24, y: curY, width: pageWidth - 48, height: 110)
                UIColor(red: 245/255, green: 247/255, blue: 250/255, alpha: 1.0).setFill()
                cgContext.fill(bRect2)
                cgContext.stroke(bRect2)
                
                "Khối lượng ghi nhận:".draw(at: CGPoint(x: 32, y: curY + 8), withAttributes: bAttrs)
                "\(task.recordedCount) \(task.unit)".draw(at: CGPoint(x: 150, y: curY + 8), withAttributes: bAttrs)
                
                "Chi tiết thống kê:".draw(at: CGPoint(x: 32, y: curY + 28), withAttributes: bAttrs)
                task.detailedStatistics.ifEmpty(default: "Đã hoàn thành đúng chỉ tiêu").draw(at: CGPoint(x: 150, y: curY + 28), withAttributes: nAttrs)
                
                "Đề xuất xử lý:".draw(at: CGPoint(x: 32, y: curY + 54), withAttributes: bAttrs)
                task.proposedRemedy.ifEmpty(default: "Không có đề xuất thêm").draw(at: CGPoint(x: 150, y: curY + 54), withAttributes: nAttrs)
                
                "Hiện trạng:".draw(at: CGPoint(x: 32, y: curY + 80), withAttributes: bAttrs)
                task.status.label.draw(at: CGPoint(x: 150, y: curY + 80), withAttributes: bAttrs)
                
                // Signatures (Căn giữa tuyệt đối)
                let signY = pageHeight - 150
                let col1CenterX: CGFloat = 140
                let col2CenterX: CGFloat = pageWidth - 140
                
                let signHeadAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 10), .foregroundColor: UIColor.black]
                let t1 = "CÁN BỘ BÁO CÁO / THỰC HIỆN"
                let w1 = (t1 as NSString).size(withAttributes: signHeadAttrs).width
                t1.draw(at: CGPoint(x: col1CenterX - w1/2, y: signY), withAttributes: signHeadAttrs)
                
                let s1 = "(Ký và ghi rõ họ tên)"
                let sw1 = (s1 as NSString).size(withAttributes: metaAttrs).width
                s1.draw(at: CGPoint(x: col1CenterX - sw1/2, y: signY + 14), withAttributes: metaAttrs)
                
                let t2 = "TỔ QUẢN LÝ VẬN HÀNH TIẾP NHẬN"
                let w2 = (t2 as NSString).size(withAttributes: signHeadAttrs).width
                t2.draw(at: CGPoint(x: col2CenterX - w2/2, y: signY), withAttributes: signHeadAttrs)
                
                let s2 = "(Ký duyệt và ghi ý kiến tiếp nhận)"
                let sw2 = (s2 as NSString).size(withAttributes: metaAttrs).width
                s2.draw(at: CGPoint(x: col2CenterX - sw2/2, y: signY + 14), withAttributes: metaAttrs)
                
                let sigW: CGFloat = 130
                let sigH: CGFloat = 55
                if let sig = signatureImage {
                    let sigRect = CGRect(x: col1CenterX - sigW/2, y: signY + 28, width: sigW, height: sigH)
                    sig.draw(in: sigRect)
                } else {
                    let eRect = CGRect(x: col1CenterX - sigW/2, y: signY + 34, width: sigW, height: 36)
                    UIColor(red: 227/255, green: 242/255, blue: 253/255, alpha: 1.0).setFill()
                    UIBezierPath(roundedRect: eRect, cornerRadius: 4).fill()
                    
                    let eAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 8), .foregroundColor: UIColor(red: 13/255, green: 71/255, blue: 161/255, alpha: 1.0)]
                    let eText = "✓ ĐÃ KÝ ĐIỆN TỬ"
                    let ew = (eText as NSString).size(withAttributes: eAttrs).width
                    eText.draw(at: CGPoint(x: col1CenterX - ew/2, y: signY + 46), withAttributes: eAttrs)
                }
                
                let nameAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 9.5), .foregroundColor: UIColor(red: 27/255, green: 94/255, blue: 32/255, alpha: 1.0)]
                let nw = (task.assignee as NSString).size(withAttributes: nameAttrs).width
                task.assignee.draw(at: CGPoint(x: col1CenterX - nw/2, y: signY + 88), withAttributes: nameAttrs)
                
                // Footer
                cgContext.setStrokeColor(UIColor.lightGray.cgColor)
                cgContext.setLineWidth(0.5)
                cgContext.move(to: CGPoint(x: 24, y: pageHeight - 30))
                cgContext.addLine(to: CGPoint(x: pageWidth - 24, y: pageHeight - 30))
                cgContext.strokePath()
                
                let footAttrs: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: 8), .foregroundColor: UIColor.gray]
                "Hệ Thống Lưới Điện SPC • Tạo bởi Cty Điện lực An Giang (PCAG) • Trang 1/1".draw(at: CGPoint(x: 24, y: pageHeight - 20), withAttributes: footAttrs)
            })
            return tempURL
        } catch {
            print("Lỗi tạo PDF iOS Task: \(error.localizedDescription)")
            return nil
        }
    }
}

extension String {
    func ifEmpty(default defaultVal: String) -> String {
        return self.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? defaultVal : self
    }
}
