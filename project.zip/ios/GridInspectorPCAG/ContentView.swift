//
//  ContentView.swift
//  GridInspectorPCAG
//
//  Tạo bởi: CÔNG TY ĐIỆN LỰC AN GIANG (PCAG) - TỔNG CÔNG TY ĐIỆN LỰC MIỀN NAM (SPC)
//  Giao diện Native 100% SwiftUI cho iPhone & iPad
//

import SwiftUI
import PDFKit

struct ContentView: View {
    @StateObject private var store = EquipmentStore()
    @State private var selectedTab = 0
    @State private var showSettingsSheet = false
    @State private var showAddEquipmentSheet = false
    
    var body: some View {
        TabView(selection: $selectedTab) {
            // Tab 1: Danh sách thiết bị
            NavigationStack {
                EquipmentListView(store: store)
                    .navigationTitle("Thiết Bị Lưới Điện")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .topBarLeading) {
                            Button(action: { showSettingsSheet = true }) {
                                Image(systemName: "person.crop.circle.badge.checkmark")
                                    .foregroundColor(.white)
                            }
                        }
                        ToolbarItem(placement: .topBarTrailing) {
                            Button(action: { showAddEquipmentSheet = true }) {
                                Image(systemName: "plus.circle.fill")
                                    .foregroundColor(.white)
                            }
                        }
                    }
                    .toolbarBackground(Color(red: 0/255, green: 51/255, blue: 102/255), for: .navigationBar)
                    .toolbarBackground(.visible, for: .navigationBar)
            }
            .tabItem {
                Label("Thiết bị", systemImage: "bolt.batteryblock.fill")
            }
            .tag(0)
            
            // Tab 2: Báo cáo kỹ thuật PDF
            NavigationStack {
                ReportsView(store: store)
                    .navigationTitle("Báo Cáo PCAG - SPC")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbarBackground(Color(red: 0/255, green: 51/255, blue: 102/255), for: .navigationBar)
                    .toolbarBackground(.visible, for: .navigationBar)
            }
            .tabItem {
                Label("Báo cáo", systemImage: "doc.text.fill")
            }
            .tag(1)
        }
        .accentColor(Color(red: 0/255, green: 51/255, blue: 102/255))
        .sheet(isPresented: $showSettingsSheet) {
            InspectorSettingsView(store: store)
        }
        .sheet(isPresented: $showAddEquipmentSheet) {
            AddEquipmentView(store: store)
        }
    }
}

// MARK: - EQUIPMENT STORE
class EquipmentStore: ObservableObject {
    @Published var equipments: [EquipmentItem] = []
    @Published var inspections: [PeriodicInspectionRecord] = []
    @Published var defects: [DefectRecord] = []
    @Published var tasks: [AssignedWorkTask] = []
    @Published var corridors: [SafetyCorridorRecord] = []
    @Published var profile: InspectorProfile = InspectorProfile()
    @Published var selectedAreaFilter: String? = nil
    
    init() {
        loadSampleData()
    }
    
    func clearAllData() {
        equipments.removeAll()
        inspections.removeAll()
        defects.removeAll()
        tasks.removeAll()
        corridors.removeAll()
    }
    
    func loadSampleData() {
        equipments = [
            EquipmentItem(
                code: "REC-471-01",
                name: "Recloser Tuyến 471 Cột 12",
                type: .recloser,
                poleNumber: "Cột 12/471",
                lineName: "Đường dây 471 An Giang",
                voltageLevel: "22kV",
                ratedCurrent: "630A",
                manufacturer: "Entec Korea",
                status: .normal
            ),
            EquipmentItem(
                code: "LBS-471-08",
                name: "LBS Phân Đoạn Nhánh Chợ Mới",
                type: .lbs,
                poleNumber: "Cột 45/471",
                lineName: "Đường dây 471 An Giang",
                voltageLevel: "22kV",
                ratedCurrent: "630A",
                manufacturer: "Schneider",
                status: .warning
            ),
            EquipmentItem(
                code: "FCO-472-15",
                name: "FCO Trạm Biến Áp Long Xuyên",
                type: .fco,
                poleNumber: "Cột 18/472",
                lineName: "Đường dây 472 An Giang",
                voltageLevel: "22kV",
                ratedCurrent: "100A",
                manufacturer: "Tuấn Ân",
                status: .normal
            )
        ]
        
        tasks = [
            AssignedWorkTask(
                title: "Thống kê phụ kiện tiếp địa bị rỉ sét / mất trộm",
                assignedBy: "Tổ Kỹ thuật / Đội QLVH",
                assignee: profile.inspectorName,
                category: "Tiếp địa & Nối đất",
                lineName: "Đường dây 471 An Giang",
                spanLocation: "Đoạn cột 12 đến 48",
                targetScope: "36 vị trí cột",
                recordedCount: 4,
                unit: "vị trí",
                description: "Kiểm tra toàn bộ hệ thống cọc tiếp địa, dây đồng tiếp đất cho bu-lông gông xà và chống sét van trên tuyến.",
                detailedStatistics: "- Cột 15: Mất 3.5m dây đồng tiếp địa néo\n- Cột 22: Bu-lông siết cọc tiếp đất rỉ sét nặng\n- Cột 31: Dây tiếp đất bị đứt gập tại mặt đất",
                proposedRemedy: "Cấp bổ sung 15m dây đồng M50 và 04 bộ kẹp đồng ép nguội để thay thế hoàn trả.",
                status: .completed,
                reportCode: "BC-NV-PCAG-042",
                qlvhRecipient: "Tổ Quản Lý Vận Hành Lưới Điện"
            )
        ]
        
        corridors = [
            SafetyCorridorRecord(
                lineName: "Đường dây 471 An Giang",
                spanLocation: "Khoảng cột 18 - 19",
                hazardType: .tree,
                description: "Cây tràm nước cao vượt tầm với, tán cây ngả về phía pha bìa",
                currentDistance: "1.2m (quy chuẩn >= 2.0m)",
                riskLevel: .high,
                status: .violationExisting
            )
        ]
    }
    
    func addEquipment(_ item: EquipmentItem) {
        equipments.insert(item, at: 0)
    }
}

// MARK: - EQUIPMENT LIST VIEW
struct EquipmentListView: View {
    @ObservedObject var store: EquipmentStore
    @State private var searchText = ""
    
    var filteredEquipments: [EquipmentItem] {
        store.equipments.filter { item in
            let matchesSearch = searchText.isEmpty || item.name.localizedCaseInsensitiveContains(searchText) || item.code.localizedCaseInsensitiveContains(searchText)
            let matchesArea = store.selectedAreaFilter == nil || item.lineName.contains(store.selectedAreaFilter!)
            return matchesSearch && matchesArea
        }
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header Info Bar
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(Color(red: 0/255, green: 51/255, blue: 102/255))
                    Text(store.selectedAreaFilter == nil ? "Tất cả các tuyến • SPC" : "Khu vực: \(store.selectedAreaFilter!)")
                        .font(.system(size: 10))
                        .foregroundColor(.secondary)
                }
                Spacer()
                Text("\(filteredEquipments.count) thiết bị")
                    .font(.system(size: 11, weight: .semibold))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color(red: 0/255, green: 51/255, blue: 102/255).opacity(0.1))
                    .cornerRadius(8)
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
            .background(Color(UIColor.secondarySystemBackground))
            
            if filteredEquipments.isEmpty {
                VStack(spacing: 16) {
                    Spacer()
                    Image(systemName: "tray")
                        .font(.system(size: 48))
                        .foregroundColor(.secondary)
                    Text("Dữ liệu đang trống hoặc đã làm trắng")
                        .font(.headline)
                    Text("Cán bộ có thể tạo mới thiết bị theo khu vực quản lý hoặc khôi phục dữ liệu mẫu SPC.")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 32)
                    Button(action: { store.loadSampleData() }) {
                        Label("Nạp Dữ Liệu Mẫu SPC", systemImage: "arrow.clockwise")
                            .font(.system(size: 14, weight: .semibold))
                            .padding(.horizontal, 16)
                            .padding(.vertical, 10)
                            .background(Color(red: 0/255, green: 51/255, blue: 102/255))
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                    Spacer()
                }
            } else {
                List(filteredEquipments) { item in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text(item.type.shortName)
                                .font(.system(size: 10, weight: .bold))
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(Color(hex: item.type.tagColorHex).opacity(0.15))
                                .foregroundColor(Color(hex: item.type.tagColorHex))
                                .cornerRadius(4)
                            
                            Text(item.code)
                                .font(.system(size: 14, weight: .bold))
                            
                            Spacer()
                            
                            Circle()
                                .fill(Color(hex: item.status.colorHex))
                                .frame(width: 8, height: 8)
                            Text(item.status.displayName)
                                .font(.system(size: 11, weight: .medium))
                                .foregroundColor(Color(hex: item.status.colorHex))
                        }
                        
                        Text(item.name)
                            .font(.system(size: 13, weight: .semibold))
                        
                        HStack(spacing: 12) {
                            Label(item.poleNumber, systemImage: "mappin.and.ellipse")
                            Label(item.lineName, systemImage: "bolt.fill")
                        }
                        .font(.system(size: 11))
                        .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 4)
                }
                .searchable(text: $searchText, prompt: "Tìm theo tên, mã hoặc vị trí cột...")
            }
        }
    }
}

// MARK: - REPORTS VIEW
struct ReportsView: View {
    @ObservedObject var store: EquipmentStore
    @State private var pdfURL: URL? = nil
    @State private var isSharing = false
    @State private var showSignatureModal = false
    @State private var signatureImage: UIImage? = nil
    
    var body: some View {
        VStack(spacing: 16) {
            // Header card
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: "checkmark.seal.fill")
                        .foregroundColor(Color(red: 0/255, green: 51/255, blue: 102/255))
                        .font(.title2)
                    VStack(alignment: .leading) {
                        Text("BÁO CÁO KỸ THUẬT LƯỚI ĐIỆN")
                            .font(.headline)
                            .foregroundColor(Color(red: 0/255, green: 51/255, blue: 102/255))
                        Text("Dấu chìm: CÔNG TY ĐIỆN LỰC AN GIANG (PCAG)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                Divider()
                
                Text("• Đơn vị: \(store.profile.companyName)")
                    .font(.caption)
                Text("• Tổ QLVH tiếp nhận: \(store.profile.teamName)")
                    .font(.caption)
                Text("• Cán bộ lập: \(store.profile.inspectorName) (\(store.profile.inspectorTitle))")
                    .font(.caption)
                Text("• Tổng số thiết bị xuất: \(store.equipments.count)")
                    .font(.caption)
            }
            .padding()
            .background(Color(UIColor.secondarySystemBackground))
            .cornerRadius(12)
            .padding(.horizontal)
            
            // Signature preview
            HStack {
                VStack(alignment: .leading) {
                    Text("Chữ Ký Điện Tử")
                        .font(.subheadline)
                        .fontWeight(.bold)
                    Text(signatureImage != nil ? "Đã ký xác nhận" : "Chưa có chữ ký tay")
                        .font(.caption)
                        .foregroundColor(signatureImage != nil ? .green : .secondary)
                }
                Spacer()
                Button(action: { showSignatureModal = true }) {
                    Label(signatureImage != nil ? "Ký lại" : "Ký Ngay", systemImage: "signature")
                        .font(.system(size: 13, weight: .semibold))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(Color(red: 0/255, green: 51/255, blue: 102/255))
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
            }
            .padding()
            .background(Color(UIColor.secondarySystemBackground))
            .cornerRadius(12)
            .padding(.horizontal)
            
            Spacer()
            
            // Action Buttons
            VStack(spacing: 12) {
                Button(action: {
                    pdfURL = PDFReportGenerator.generateReport(
                        equipments: store.equipments,
                        inspections: store.inspections,
                        defects: store.defects,
                        profile: store.profile,
                        signatureImage: signatureImage
                    )
                    if pdfURL != nil {
                        isSharing = true
                    }
                }) {
                    HStack {
                        Image(systemName: "doc.badge.arrow.up.fill")
                        Text("Báo Cáo Thiết Bị & Khiếm Khuyết (PDF)")
                            .fontWeight(.bold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(red: 0/255, green: 51/255, blue: 102/255))
                    .foregroundColor(.white)
                    .cornerRadius(12)
                }
                
                if let firstTask = store.tasks.first {
                    Button(action: {
                        pdfURL = PDFReportGenerator.generateTaskReport(
                            task: firstTask,
                            profile: store.profile,
                            signatureImage: signatureImage
                        )
                        if pdfURL != nil {
                            isSharing = true
                        }
                    }) {
                        HStack {
                            Image(systemName: "paperplane.fill")
                            Text("Báo Cáo Công Việc Được Giao (PDF)")
                                .fontWeight(.bold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(red: 46/255, green: 125/255, blue: 50/255))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                }
            }
            .padding(.horizontal)
            .padding(.bottom)
        }
        .sheet(isPresented: $isSharing) {
            if let url = pdfURL {
                ShareSheet(activityItems: [url, "Kính gửi Tổ QLVH báo cáo kỹ thuật thiết bị lưới điện có dấu chìm PCAG."])
            }
        }
        .sheet(isPresented: $showSignatureModal) {
            SignatureCaptureView { img in
                self.signatureImage = img
                self.showSignatureModal = false
            }
        }
    }
}

// MARK: - INSPECTOR SETTINGS VIEW
struct InspectorSettingsView: View {
    @ObservedObject var store: EquipmentStore
    @Environment(\.dismiss) var dismiss
    @State private var showConfirmClear = false
    
    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Hồ Sơ Cán Bộ Kiểm Tra")) {
                    TextField("Họ và tên cán bộ", text: $store.profile.inspectorName)
                    TextField("Chức danh", text: $store.profile.inspectorTitle)
                    TextField("Tổ QLVH tiếp nhận", text: $store.profile.teamName)
                    TextField("Đơn vị điện lực", text: $store.profile.companyName)
                    TextField("Khu vực phụ trách", text: $store.profile.managedArea)
                    TextField("Số điện thoại liên hệ", text: $store.profile.phone)
                }
                
                Section(header: Text("Bộ Lọc Tuyến / Khu Vực")) {
                    Picker("Lọc theo tuyến", selection: $store.selectedAreaFilter) {
                        Text("Tất cả tuyến").tag(String?.none)
                        Text("Tuyến 471").tag(String?("471"))
                        Text("Tuyến 472").tag(String?("472"))
                        Text("Tuyến 473").tag(String?("473"))
                    }
                }
                
                Section(header: Text("Quản Trị Dữ Liệu")) {
                    Button(role: .destructive, action: { showConfirmClear = true }) {
                        Label("Làm Trắng Dữ Liệu (Reset)", systemImage: "trash.fill")
                    }
                    
                    Button(action: { store.loadSampleData() }) {
                        Label("Nạp Dữ Liệu Mẫu SPC (10 thiết bị)", systemImage: "arrow.counterclockwise")
                    }
                }
            }
            .navigationTitle("Cán Bộ & Dữ Liệu")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Xong") { dismiss() }
                }
            }
            .alert("Làm trắng toàn bộ dữ liệu?", isPresented: $showConfirmClear) {
                Button("Xóa Hết", role: .destructive) {
                    store.clearAllData()
                    dismiss()
                }
                Button("Hủy", role: .cancel) { }
            } message: {
                Text("Toàn bộ thiết bị, lịch sử kiểm tra và khiếm khuyết sẽ bị xóa để cán bộ tự nhập danh mục mới.")
            }
        }
    }
}

// MARK: - ADD EQUIPMENT VIEW
struct AddEquipmentView: View {
    @ObservedObject var store: EquipmentStore
    @Environment(\.dismiss) var dismiss
    
    @State private var code = ""
    @State private var name = ""
    @State private var type = EquipmentType.recloser
    @State private var poleNumber = ""
    @State private var lineName = "Đường dây 471 An Giang"
    @State private var voltageLevel = "22kV"
    @State private var ratedCurrent = "630A"
    @State private var manufacturer = "Entec Korea"
    
    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Thông Tin Thiết Bị Mới")) {
                    Picker("Loại thiết bị", selection: $type) {
                        ForEach(EquipmentType.allCases) { t in
                            Text(t.shortName).tag(t)
                        }
                    }
                    TextField("Mã thiết bị (ví dụ: REC-471-09)", text: $code)
                    TextField("Tên gọi thiết bị", text: $name)
                    TextField("Vị trí cột (ví dụ: Cột 30/471)", text: $poleNumber)
                    TextField("Tuyến đường dây", text: $lineName)
                    TextField("Cấp điện áp", text: $voltageLevel)
                    TextField("Dòng định mức", text: $ratedCurrent)
                    TextField("Hãng sản xuất", text: $manufacturer)
                }
            }
            .navigationTitle("Thêm Thiết Bị Mới")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Hủy") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Lưu") {
                        let item = EquipmentItem(
                            code: code.isEmpty ? "TB-\(Int.random(in: 100...999))" : code,
                            name: name.isEmpty ? type.displayName : name,
                            type: type,
                            poleNumber: poleNumber.isEmpty ? "Chưa xác định" : poleNumber,
                            lineName: lineName,
                            voltageLevel: voltageLevel,
                            ratedCurrent: ratedCurrent,
                            manufacturer: manufacturer
                        )
                        store.addEquipment(item)
                        dismiss()
                    }
                }
            }
        }
    }
}

// MARK: - SIGNATURE CAPTURE VIEW
struct SignatureCaptureView: View {
    var onComplete: (UIImage) -> Void
    @Environment(\.dismiss) var dismiss
    @State private var lines: [[CGPoint]] = []
    
    var body: some View {
        NavigationStack {
            VStack {
                Text("Ký tên vào ô bên dưới:")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .padding(.top)
                
                Canvas { context, size in
                    for line in lines {
                        var path = Path()
                        if let first = line.first {
                            path.move(to: first)
                            for pt in line.dropFirst() {
                                path.addLine(to: pt)
                            }
                        }
                        context.stroke(path, with: .color(Color(red: 0/255, green: 51/255, blue: 102/255)), lineWidth: 3)
                    }
                }
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            let newPoint = value.location
                            if value.translation == .zero {
                                lines.append([newPoint])
                            } else {
                                guard let lastIdx = lines.indices.last else { return }
                                lines[lastIdx].append(newPoint)
                            }
                        }
                )
                .background(Color(UIColor.systemGray6))
                .cornerRadius(12)
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                )
                .padding()
                
                HStack(spacing: 20) {
                    Button("Xóa Ký Lại") {
                        lines.removeAll()
                    }
                    .foregroundColor(.red)
                    
                    Button("Xác Nhận Chữ Ký") {
                        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 300, height: 120))
                        let img = renderer.image { ctx in
                            if lines.isEmpty {
                                let attrs: [NSAttributedString.Key: Any] = [
                                    .font: UIFont.boldSystemFont(ofSize: 13.5),
                                    .foregroundColor: UIColor(red: 13/255, green: 71/255, blue: 161/255, alpha: 1.0)
                                ]
                                let text = "✓ ĐÃ XÁC THỰC KÝ ĐIỆN TỬ - PCAG"
                                let tw = (text as NSString).size(withAttributes: attrs).width
                                text.draw(at: CGPoint(x: (300 - tw)/2, y: 48), withAttributes: attrs)
                            } else {
                                let cgCtx = ctx.cgContext
                                cgCtx.setStrokeColor(UIColor(red: 0/255, green: 33/255, blue: 113/255, alpha: 1.0).cgColor)
                                cgCtx.setLineWidth(3.0)
                                cgCtx.setLineCap(.round)
                                cgCtx.setLineJoin(.round)
                                for line in lines {
                                    guard let first = line.first else { continue }
                                    cgCtx.beginPath()
                                    cgCtx.move(to: first)
                                    for pt in line.dropFirst() {
                                        cgCtx.addLine(to: pt)
                                    }
                                    cgCtx.strokePath()
                                }
                            }
                        }
                        onComplete(img)
                        dismiss()
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                    .background(Color(red: 0/255, green: 51/255, blue: 102/255))
                    .foregroundColor(.white)
                    .cornerRadius(8)
                }
                .padding(.bottom)
            }
            .navigationTitle("Ký Tên Điện Tử")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Đóng") { dismiss() }
                }
            }
        }
    }
}

// MARK: - SHARE SHEET FOR IOS
struct ShareSheet: UIViewControllerRepresentable {
    var activityItems: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

// MARK: - COLOR EXTENSION
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue:  Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}
